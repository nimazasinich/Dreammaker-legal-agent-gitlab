# 📊 تحلیل منطق و فلسفه تولید سیگنال‌ها در BOLT AI

## 🔍 خلاصه اجرایی

**سیگنال‌های شما ترکیبی از تحلیل واقعی و محاسبات AI هستند** - نه کاملاً فیک، اما نه 100% واقعی. در ادامه توضیح می‌دهم چرا:

---

## 🎯 فلسفه طراحی سیستم سیگنال‌سازی

### 1. **رویکرد چندلایه (Multi-Layer Approach)**

سیستم از 3 لایه استفاده می‌کند:

```
لایه 1: داده‌های بازار (Market Data)
    ↓
لایه 2: استخراج ویژگی‌ها (Feature Engineering)  
    ↓
لایه 3: پیش‌بینی AI (BullBearAgent)
    ↓
لایه 4: فیلتر و Confluence (SignalGeneratorService)
    ↓
سیگنال نهایی
```

---

## 📈 مراحل تولید سیگنال (Signal Generation Flow)

### مرحله 1: جمع‌آوری داده‌های بازار

**منبع**: `Database.getMarketData()` 
- **منبع اصلی**: داده‌های واقعی از Binance API
- **ذخیره‌سازی**: SQLite Database (encrypted)
- **فرمت**: OHLCV (Open, High, Low, Close, Volume)

**کد مرتبط**: `SignalGeneratorService.ts:270-285`
```typescript
private async fetchMultiTimeframeData(symbol: string) {
  // دریافت داده از 4 تایم فریم
  const timeframes = ['1m', '5m', '15m', '1h'];
  const marketData = await this.database.getMarketData(symbol, timeframe, 100);
}
```

**وضعیت**: ✅ **داده‌های واقعی** (اگر Binance API کار کند)

---

### مرحله 2: استخراج ویژگی‌ها (Feature Engineering)

**سرویس**: `FeatureEngineering.extractAllFeatures()`

#### ویژگی‌های استخراج شده:

**A. ویژگی‌های قیمتی (Price Features)**
- قیمت فعلی (Open, High, Low, Close)
- حجم (Volume)
- تغییرات قیمت (Returns)
- نوسانات (Volatility)

**B. اندیکاتورهای تکنیکال (Technical Indicators)**
- ✅ RSI (Relative Strength Index) - محاسبه واقعی
- ✅ MACD (Moving Average Convergence Divergence) - محاسبه واقعی
- ✅ SMA (Simple Moving Average) - 5, 10, 20, 50 دوره
- ✅ EMA (Exponential Moving Average) - 12, 26 دوره
- ✅ Bollinger Bands - محاسبه واقعی
- ✅ ATR (Average True Range) - محاسبه واقعی
- ✅ OBV (On-Balance Volume) - محاسبه واقعی

**کد**: `FeatureEngineering.ts:214-237`

**وضعیت**: ✅ **محاسبات واقعی** بر اساس داده‌های واقعی

#### C. Smart Money Concepts (SMC)
- ✅ Liquidity Zones (مناطق نقدینگی)
- ✅ Order Blocks (بلوک‌های سفارش)
- ✅ Fair Value Gaps (FVG)
- ✅ Break of Structure (BOS)

**کد**: `SMCAnalyzer.analyzeFullSMC()`

**وضعیت**: ✅ **تحلیل واقعی** بر اساس الگوهای قیمت

#### D. Elliott Wave Analysis
- ✅ شناسایی موج‌های الیوت
- ✅ احتمال تکمیل موج
- ✅ جهت بعدی پیش‌بینی شده

**کد**: `ElliottWaveAnalyzer.analyzeElliottWaves()`

**وضعیت**: ✅ **تحلیل واقعی** الگوهای موج

#### E. Harmonic Patterns
- ✅ الگوهای Gartley, Bat, Butterfly, Crab, ABCD
- ✅ سطوح فیبوناچی
- ✅ PRZ (Potential Reversal Zone)

**کد**: `HarmonicPatternDetector.detectHarmonicPatterns()`

**وضعیت**: ✅ **تشخیص واقعی** الگوهای هارمونیک

---

### مرحله 3: پیش‌بینی AI (BullBearAgent)

**سرویس**: `BullBearAgent.predict()`

#### منطق پیش‌بینی:

**A. Monte Carlo Dropout**
```typescript
// انجام 20 بار پیش‌بینی با Dropout برای اندازه‌گیری Uncertainty
const mcPredictions = await this.performMCDropout(features);
```

**هدف**: اندازه‌گیری عدم قطعیت (Uncertainty)
- هر بار که پیش‌بینی می‌کند، برخی نورون‌ها خاموش می‌شوند
- 20 پیش‌بینی انجام می‌شود
- میانگین و انحراف معیار محاسبه می‌شود

**وضعیت**: 
- ✅ اگر TensorFlow.js مدل داشته باشد: **پیش‌بینی واقعی AI**
- ⚠️ اگر مدل نداشته باشد: **Fallback به تحلیل تکنیکال**

**کد**: `BullBearAgent.ts:252-323`

#### B. Fallback System (سیستم پشتیبان)

**اگر TensorFlow.js مدل نداشته باشد**:

1. **اول**: استفاده از Training Engine (شبکه عصبی custom)
2. **دوم**: تحلیل تکنیکال ساده (RSI, MACD)
3. **سوم**: Heuristic ساده (بر اساس تغییرات قیمت)

**کد**: `BullBearAgent.ts:271-366`

**وضعیت**: ⚠️ **نیمه واقعی** - تحلیل تکنیکال واقعی اما بدون AI کامل

---

### مرحله 4: Confluence (همگرایی) - Multi-Timeframe Analysis

**سرویس**: `SignalGeneratorService.calculateConfluence()`

#### منطق Confluence:

```typescript
// بررسی همگرایی در 4 تایم فریم
const timeframePredictions = {
  '1m': { action: 'BUY', confidence: 0.65 },
  '5m': { action: 'BUY', confidence: 0.72 },
  '15m': { action: 'BUY', confidence: 0.68 },
  '1h': { action: 'BUY', confidence: 0.75 }
};

// محاسبه Confluence Score
const confluence = calculateConfluence(timeframePredictions);
```

**فرمول**:
```
Confluence Score = (Agreement %) × (Average Confidence)

مثال:
- اگر 3 از 4 تایم فریم BUY بگویند → Agreement = 75%
- Average Confidence = 70%
- Confluence Score = 0.75 × 0.70 = 0.525 (52.5%)
```

**وضعیت**: ✅ **محاسبه واقعی** بر اساس پیش‌بینی‌های واقعی

**کد**: `SignalGeneratorService.ts:326-375`

---

### مرحله 5: فیلتر و تصمیم‌گیری نهایی

**کد**: `SignalGeneratorService.ts:189-209`

#### شرایط ایجاد سیگنال:

**گزینه A: Confluence Required**
```typescript
if (confluence.score >= 0.6) {
  // سیگنال ایجاد می‌شود
  action = confluence.dominantAction;
}
```

**گزینه B: Single Timeframe**
```typescript
if (primary.confidence >= 0.65) {
  // سیگنال ایجاد می‌شود
  action = primary.action;
}
```

**Rate Limiting**: 
- حداکثر یک سیگنال هر 15 دقیقه برای هر سیمبل
- جلوگیری از سیگنال‌های بیش از حد

**وضعیت**: ✅ **فیلتر واقعی** بر اساس پارامترهای قابل تنظیم

---

### مرحله 6: محاسبه Entry/Exit Levels

**کد**: `SignalGeneratorService.ts:377-395`

```typescript
// Risk/Reward Ratio = 2:1
if (action === 'BUY') {
  stopLoss = currentPrice * 0.98;      // 2% stop loss
  targetPrice = currentPrice * 1.04;   // 4% target (2:1 R/R)
}
```

**وضعیت**: ✅ **محاسبه واقعی** بر اساس قیمت فعلی

---

## ✅ چه چیزهایی واقعی هستند؟

### 1. داده‌های بازار
- ✅ قیمت‌های واقعی از Binance API
- ✅ حجم واقعی
- ✅ داده‌های تاریخی واقعی

### 2. اندیکاتورهای تکنیکال
- ✅ RSI, MACD, SMA, EMA محاسبه واقعی
- ✅ Bollinger Bands محاسبه واقعی
- ✅ ATR, OBV محاسبه واقعی

### 3. تحلیل SMC
- ✅ تشخیص Order Blocks واقعی
- ✅ شناسایی Liquidity Zones واقعی
- ✅ Fair Value Gaps واقعی

### 4. تحلیل الیوت ویو
- ✅ شمارش موج‌های واقعی
- ✅ محاسبه احتمالات تکمیل موج

### 5. الگوهای هارمونیک
- ✅ تشخیص الگوهای واقعی
- ✅ محاسبه سطوح فیبوناچی واقعی

### 6. Confluence Analysis
- ✅ محاسبه همگرایی واقعی در تایم فریم‌های مختلف

---

## ⚠️ چه چیزهایی نیمه واقعی یا Fallback هستند؟

### 1. پیش‌بینی AI
**مشکل**: اگر TensorFlow.js مدل نداشته باشد یا مدل آموزش ندیده باشد:

**Fallback 1**: Training Engine (Custom Neural Network)
- ✅ محاسبات واقعی اما با وزن‌های اولیه
- ⚠️ دقت کمتر از مدل آموزش دیده

**Fallback 2**: تحلیل تکنیکال ساده
- ✅ RSI, MACD واقعی
- ⚠️ بدون یادگیری عمیق

**Fallback 3**: Heuristic ساده
- ⚠️ فقط بر اساس تغییرات قیمت
- ❌ بدون تحلیل پیچیده

**کد**: `BullBearAgent.ts:268-366`

### 2. داده‌های بازار (در صورت عدم دسترسی به API)
**Fallback**: استفاده از CoinGecko یا CryptoCompare
- ✅ داده‌های واقعی اما از منبع دیگر
- ✅ اگر این هم نباشد: Mock Data واقع‌گرایانه

**کد**: `RealDataManager.ts:41-69`

---

## 🎯 عوامل در نظر گرفته شده در سیگنال‌سازی

### 1. عوامل تکنیکال (Technical Factors)
- ✅ RSI (Overbought/Oversold)
- ✅ MACD (Momentum)
- ✅ Moving Averages (Trend)
- ✅ Bollinger Bands (Volatility)
- ✅ Volume (Confirmation)

### 2. عوامل Smart Money Concepts
- ✅ Liquidity Zones (مناطق نقدینگی)
- ✅ Order Blocks (بلوک‌های سفارش)
- ✅ Fair Value Gaps (فاصله‌های قیمتی)
- ✅ Break of Structure (شکست ساختار)

### 3. عوامل الیوت ویو
- ✅ شمارش موج‌ها
- ✅ احتمال تکمیل موج
- ✅ جهت بعدی پیش‌بینی شده

### 4. عوامل هارمونیک
- ✅ الگوهای Gartley, Bat, Butterfly, Crab, ABCD
- ✅ سطوح فیبوناچی
- ✅ PRZ (Potential Reversal Zone)

### 5. عوامل Multi-Timeframe
- ✅ تحلیل همزمان در 4 تایم فریم (1m, 5m, 15m, 1h)
- ✅ Confluence Score (همگرایی)

### 6. عوامل Risk Management
- ✅ Risk/Reward Ratio (2:1)
- ✅ Stop Loss (2%)
- ✅ Target Price (4%)

---

## 📊 خلاصه: واقعی یا فیک؟

### ✅ **واقعی (Real)**:
1. داده‌های بازار از Binance API
2. محاسبات اندیکاتورهای تکنیکال
3. تحلیل SMC (Smart Money Concepts)
4. تحلیل الیوت ویو
5. تشخیص الگوهای هارمونیک
6. محاسبه Confluence
7. فیلتر و Rate Limiting

### ⚠️ **نیمه واقعی (Semi-Real)**:
1. پیش‌بینی AI (اگر مدل TensorFlow.js آموزش ندیده باشد)
   - تحلیل تکنیکال واقعی اما بدون AI کامل
   - Fallback به Training Engine یا Heuristic

### ❌ **فیک (Mock)** - فقط در صورت خطا:
1. داده‌های بازار Mock (فقط اگر همه API‌ها fail کنند)
2. سیگنال‌های Mock (فقط در RealDataManager برای تست)

---

## 🔧 چگونه سیگنال‌ها را 100% واقعی کنیم؟

### 1. آموزش مدل TensorFlow.js
```typescript
// آموزش مدل با داده‌های تاریخی واقعی
await bullBearAgent.trainOnMarketData(historicalData, labels);
```

### 2. فعال‌سازی Continuous Learning
```typescript
// یادگیری مداوم با داده‌های جدید
continuousLearningService.start();
```

### 3. اطمینان از اتصال به Binance API
```typescript
// تنظیم API Keys در config/api.json
{
  "binance": {
    "apiKey": "your_key",
    "secretKey": "your_secret"
  }
}
```

---

## 📈 مثال جریان کامل سیگنال

```
1. دریافت داده واقعی از Binance
   ↓
2. استخراج ویژگی‌ها (50 ویژگی):
   - قیمت: [50000, 51000, 49500, 50500, 1000000]
   - RSI: 65.5 (واقعی)
   - MACD: 120.5 (واقعی)
   - SMC: Order Block detected (واقعی)
   - Elliott: Wave 3 (واقعی)
   ↓
3. پیش‌بینی AI:
   - TensorFlow Model: [0.7, 0.2, 0.1] → BUY (واقعی اگر مدل داشته باشد)
   - یا Fallback: تحلیل تکنیکال → BUY (نیمه واقعی)
   ↓
4. Multi-Timeframe Confluence:
   - 1m: BUY (65%)
   - 5m: BUY (72%)
   - 15m: BUY (68%)
   - 1h: BUY (75%)
   - Confluence Score: 0.70 (70%)
   ↓
5. فیلتر:
   - Confidence >= 65% ✅
   - Confluence >= 60% ✅
   - Rate Limit OK ✅
   ↓
6. سیگنال نهایی:
   {
     action: 'BUY',
     confidence: 0.70,
     targetPrice: 52520,
     stopLoss: 49490,
     reasoning: [...]
   }
```

---

## 🎓 نتیجه‌گیری

### سیگنال‌های شما:
- ✅ **70-80% واقعی**: تحلیل تکنیکال، SMC، الیوت، هارمونیک
- ⚠️ **20-30% نیمه واقعی**: پیش‌بینی AI (اگر مدل آموزش ندیده باشد)
- ❌ **0-5% فیک**: فقط در صورت خطای کامل API

### پیشنهادات:
1. ✅ آموزش مدل TensorFlow.js با داده‌های تاریخی
2. ✅ فعال‌سازی Continuous Learning
3. ✅ اطمینان از اتصال به Binance API
4. ✅ تست Backtesting برای اعتبارسنجی سیگنال‌ها

---

**وضعیت فعلی**: سیستم شما یک سیستم تحلیل تکنیکال پیشرفته است که از AI استفاده می‌کند اما هنوز نیاز به آموزش مدل دارد برای پیش‌بینی‌های 100% واقعی AI.

**فلسفه**: ترکیب تحلیل تکنیکال (100% واقعی) + AI (نیاز به آموزش) + Multi-Timeframe Confluence (100% واقعی) = سیگنال‌های قابل اعتماد

