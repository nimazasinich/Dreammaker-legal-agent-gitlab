# 🎯 پیشنهادات بهبود پروژه BOLT AI

## 📋 خلاصه اجرایی

پس از بررسی دقیق کد پروژه، چندین مشکل **بحرانی** شناسایی شد که مانع از عملکرد واقعی سیستم یادگیری و پیش‌بینی می‌شود. این سند راهکارهای عملی برای حل این مشکلات ارائه می‌دهد.

---

## ⚠️ مشکلات بحرانی شناسایی‌شده

### 1. ❌ مشکل اصلی: شبیه‌سازی به جای یادگیری واقعی

#### مشکل در `TrainingEngine.ts`
- **خط 226-242**: متد `simulateForwardBackward` فقط داده‌های تصادفی تولید می‌کند
- **خط 228**: `predictions = experiences.map(() => Math.random())` - پیش‌بینی‌ها کاملاً تصادفی هستند!
- **خط 237**: گرادیان‌ها هم تصادفی هستند: `(Math.random() - 0.5) * 0.01`

**تأثیر**: سیستم هرگز یاد نمی‌گیرد و فقط اعداد تصادفی تولید می‌کند.

#### مشکل در `BullBearAgent.ts`
- **خط 271-284**: متد `simulateForwardPass` فقط نویز تصادفی تولید می‌کند
- پیش‌بینی‌ها بر اساس `Math.random()` هستند نه مدل واقعی

**تأثیر**: حتی اگر TensorFlow.js در دسترس باشد، در حالت fallback پیش‌بینی‌ها بی‌معنی هستند.

### 2. ❌ باگ در `ContinuousLearningService.ts`
- **خط 225**: استفاده از `prediction.decision` که در interface وجود ندارد
- باید `prediction.action` باشد

**تأثیر**: خطای runtime هنگام اجرای یادگیری مداوم

### 3. ⚠️ مشکل در اندازه‌گیری دقت
- در `ContinuousLearningService.ts` خط 220-226، مقایسه `prediction.decision` با `exp.action` وجود دارد
- اما `exp.action` به صورت رشته است (`'BULLISH'` یا `'BEARISH'`) در حالی که prediction باید `'LONG'` یا `'SHORT'` برگرداند

---

## 🔧 راهکارهای پیشنهادی

### راهکار 1: پیاده‌سازی یادگیری واقعی (اولویت بالا)

#### گام 1: اصلاح `TrainingEngine.ts`

```typescript
// به جای simulateForwardBackward واقعی، باید از شبکه عصبی واقعی استفاده کنیم
private async forwardPass(experiences: Experience[]): Promise<{ predictions: number[]; loss: number }> {
  // استفاده از پارامترهای شبکه برای پیش‌بینی واقعی
  const predictions: number[] = [];
  
  for (const exp of experiences) {
    // استخراج features از state
    const features = this.extractFeaturesFromState(exp.state);
    
    // پیش‌بینی با استفاده از پارامترهای شبکه
    const prediction = this.forwardPassThroughNetwork(features, this.parameters);
    predictions.push(prediction);
  }
  
  // محاسبه loss واقعی
  const targets = experiences.map(exp => exp.reward > 0 ? 1 : 0);
  const loss = this.calculateLoss(predictions, targets);
  
  return { predictions, loss };
}

private forwardPassThroughNetwork(features: number[], parameters: number[][][]): number {
  // پیاده‌سازی forward pass واقعی بر اساس معماری شبکه
  let output = features;
  
  for (let layerIdx = 0; layerIdx < parameters.length; layerIdx++) {
    const layerWeights = parameters[layerIdx];
    output = this.matrixMultiply(output, layerWeights);
    output = this.applyActivation(output, 'leakyReLU');
  }
  
  return output[0]; // خروجی نهایی
}

private async backwardPass(
  predictions: number[],
  targets: number[],
  features: number[][]
): Promise<number[][][]> {
  // محاسبه گرادیان‌های واقعی با backpropagation
  const gradients: number[][][] = [];
  
  // محاسبه gradient loss نسبت به خروجی
  const outputGradients = predictions.map((pred, i) => pred - targets[i]);
  
  // محاسبه گرادیان‌های لایه‌ها (backpropagation)
  // اینجا باید الگوریتم backpropagation واقعی پیاده‌سازی شود
  
  return gradients;
}
```

#### گام 2: اصلاح `BullBearAgent.ts`

```typescript
private async performMCDropout(features: number[]): Promise<number[][]> {
  if (this.useTensorFlow && this.tensorFlowModel.isLoaded()) {
    try {
      return await this.tensorFlowModel.predictWithMCDropout(features, this.mcDropoutSamples);
    } catch (error) {
      this.logger.warn('TensorFlow prediction failed', {}, error as Error);
      // به جای fallback به random، از مدل training engine استفاده کنیم
      return await this.fallbackToTrainingEngine(features);
    }
  }
  
  // استفاده از training engine به جای random
  return await this.fallbackToTrainingEngine(features);
}

private async fallbackToTrainingEngine(features: number[]): Promise<number[][]> {
  const predictions: number[][] = [];
  
  // استفاده از پارامترهای آموزش‌دیده شده
  const parameters = this.trainingEngine.getParameters();
  
  for (let i = 0; i < this.mcDropoutSamples; i++) {
    // اعمال dropout برای Monte Carlo
    const maskedFeatures = this.applyDropout(features, 0.3);
    const prediction = this.trainingEngine.predict(maskedFeatures);
    predictions.push(prediction);
  }
  
  return predictions;
}
```

### راهکار 2: رفع باگ `ContinuousLearningService.ts`

```typescript
// اصلاح خط 220-226
const predictedDirection = prediction.action === 'LONG' ? 'BULLISH' : 
                           prediction.action === 'SHORT' ? 'BEARISH' : 'NEUTRAL';
const actualDirection = exp.action; // 'BULLISH' یا 'BEARISH'

if (predictedDirection === actualDirection) {
  correct++;
}
```

### راهکار 3: پیاده‌سازی واقعی Backpropagation

#### ایجاد فایل جدید: `src/ai/Backpropagation.ts`

```typescript
export class Backpropagation {
  /**
   * محاسبه گرادیان‌های واقعی با الگوریتم backpropagation
   */
  static calculateGradients(
    networkOutput: number[],
    targets: number[],
    activations: number[][],
    weights: number[][][],
    lossFunction: 'mse' | 'crossEntropy' = 'mse'
  ): number[][][] {
    const gradients: number[][][] = [];
    
    // محاسبه gradient loss نسبت به خروجی
    let outputGradients: number[];
    if (lossFunction === 'mse') {
      outputGradients = networkOutput.map((out, i) => out - targets[i]);
    } else {
      // cross-entropy
      outputGradients = networkOutput.map((out, i) => {
        const target = targets[i];
        return (out - target) / (out * (1 - out) + 1e-8); // جلوگیری از تقسیم بر صفر
      });
    }
    
    // Backpropagation از لایه آخر به اول
    let currentGradients = outputGradients;
    
    for (let layerIdx = weights.length - 1; layerIdx >= 0; layerIdx--) {
      const layerWeights = weights[layerIdx];
      const layerActivations = activations[layerIdx];
      
      // محاسبه gradient وزن‌ها
      const weightGradients: number[][] = [];
      for (let i = 0; i < layerWeights.length; i++) {
        const row: number[] = [];
        for (let j = 0; j < layerWeights[i].length; j++) {
          const gradient = currentGradients[j] * layerActivations[i];
          row.push(gradient);
        }
        weightGradients.push(row);
      }
      
      gradients.unshift(weightGradients); // اضافه کردن به ابتدا
      
      // محاسبه gradient برای لایه قبلی
      if (layerIdx > 0) {
        currentGradients = this.backwardPassThroughLayer(
          currentGradients,
          layerWeights,
          layerActivations
        );
      }
    }
    
    return gradients;
  }
  
  private static backwardPassThroughLayer(
    gradients: number[],
    weights: number[][],
    activations: number[]
  ): number[] {
    // محاسبه gradient لایه قبلی
    const prevGradients: number[] = new Array(weights.length).fill(0);
    
    for (let i = 0; i < weights.length; i++) {
      for (let j = 0; j < gradients.length; j++) {
        prevGradients[i] += gradients[j] * weights[i][j];
      }
      // اعمال gradient activation function
      prevGradients[i] *= this.activationGradient(activations[i], 'leakyReLU');
    }
    
    return prevGradients;
  }
  
  private static activationGradient(value: number, activation: string): number {
    switch (activation) {
      case 'leakyReLU':
        return value > 0 ? 1 : 0.01;
      case 'sigmoid':
        return value * (1 - value);
      case 'tanh':
        return 1 - value * value;
      default:
        return 1;
    }
  }
}
```

### راهکار 4: بهبود سیستم اندازه‌گیری دقت

#### ایجاد فایل جدید: `src/ai/AccuracyMetrics.ts`

```typescript
export class AccuracyMetrics {
  /**
   * محاسبه دقت واقعی مدل بر اساس داده‌های تست
   */
  static async measureModelAccuracy(
    agent: BullBearAgent,
    testData: MarketData[],
    lookbackWindow: number = 50
  ): Promise<{
    directionalAccuracy: number;
    classificationAccuracy: number;
    mse: number;
    predictions: Array<{ actual: string; predicted: string; confidence: number }>;
  }> {
    const predictions: Array<{ actual: string; predicted: string; confidence: number }> = [];
    let correctDirectional = 0;
    let correctClassification = 0;
    let totalSquaredError = 0;
    
    for (let i = lookbackWindow; i < testData.length; i++) {
      const window = testData.slice(i - lookbackWindow, i);
      const nextBar = testData[i];
      const prevBar = testData[i - 1];
      
      // پیش‌بینی
      const prediction = await agent.predict(window);
      
      // محاسبه جهت واقعی
      const actualDirection = nextBar.close > prevBar.close ? 'LONG' : 
                             nextBar.close < prevBar.close ? 'SHORT' : 'HOLD';
      
      // مقایسه با پیش‌بینی
      const predictedDirection = prediction.action;
      
      // دقت جهت‌دار
      if (predictedDirection === actualDirection) {
        correctDirectional++;
      }
      
      // دقت طبقه‌بندی (Bull/Bear/Neutral)
      const actualClass = actualDirection === 'LONG' ? 'BULL' :
                         actualDirection === 'SHORT' ? 'BEAR' : 'NEUTRAL';
      const predictedClass = predictedDirection === 'LONG' ? 'BULL' :
                            predictedDirection === 'SHORT' ? 'BEAR' : 'NEUTRAL';
      
      if (predictedClass === actualClass) {
        correctClassification++;
      }
      
      // محاسبه خطای مربعی
      const actualPriceChange = (nextBar.close - prevBar.close) / prevBar.close;
      const predictedPriceChange = prediction.probabilities.bull - prediction.probabilities.bear;
      totalSquaredError += Math.pow(actualPriceChange - predictedPriceChange, 2);
      
      predictions.push({
        actual: actualDirection,
        predicted: predictedDirection,
        confidence: prediction.confidence
      });
    }
    
    const total = testData.length - lookbackWindow;
    
    return {
      directionalAccuracy: correctDirectional / total,
      classificationAccuracy: correctClassification / total,
      mse: totalSquaredError / total,
      predictions
    };
  }
}
```

### راهکار 5: بهبود سیستم ذخیره و بارگذاری مدل

```typescript
// در TrainingEngine.ts
async saveModelCheckpoint(path: string): Promise<void> {
  const checkpoint = {
    parameters: this.parameters,
    optimizerState: this.optimizerState,
    schedulerState: this.schedulerState,
    trainingState: this.trainingState,
    config: this.config,
    networkConfig: this.networkConfig,
    timestamp: Date.now()
  };
  
  await fs.promises.writeFile(path, JSON.stringify(checkpoint, null, 2));
  this.logger.info('Model checkpoint saved', { path });
}

async loadModelCheckpoint(path: string): Promise<boolean> {
  try {
    const data = await fs.promises.readFile(path, 'utf-8');
    const checkpoint = JSON.parse(data);
    
    this.parameters = checkpoint.parameters;
    this.optimizerState = checkpoint.optimizerState;
    this.schedulerState = checkpoint.schedulerState;
    this.trainingState = checkpoint.trainingState;
    this.config = checkpoint.config;
    this.networkConfig = checkpoint.networkConfig;
    
    this.logger.info('Model checkpoint loaded', { path, timestamp: checkpoint.timestamp });
    return true;
  } catch (error) {
    this.logger.error('Failed to load checkpoint', {}, error as Error);
    return false;
  }
}
```

---

## 📊 برنامه اجرایی (اولویت‌بندی شده)

### فاز 1: رفع مشکلات بحرانی (هفته 1-2)

1. ✅ **روز 1-2**: اصلاح `TrainingEngine.ts` - حذف `simulateForwardBackward` و پیاده‌سازی forward/backward pass واقعی
2. ✅ **روز 3-4**: اصلاح `BullBearAgent.ts` - حذف `simulateForwardPass` و استفاده از مدل واقعی
3. ✅ **روز 5**: رفع باگ `ContinuousLearningService.ts`
4. ✅ **روز 6-7**: پیاده‌سازی `Backpropagation.ts`

### فاز 2: بهبود سیستم اندازه‌گیری (هفته 3)

5. ✅ **روز 1-2**: پیاده‌سازی `AccuracyMetrics.ts`
6. ✅ **روز 3-4**: بهبود سیستم ذخیره/بارگذاری مدل
7. ✅ **روز 5**: تست‌های واحد برای همه تغییرات

### فاز 3: بهینه‌سازی و تست (هفته 4)

8. ✅ **روز 1-3**: تست روی داده‌های واقعی و بررسی نتایج
9. ✅ **روز 4-5**: بهینه‌سازی عملکرد و رفع مشکلات

---

## 🎯 انتظارات پس از پیاده‌سازی

### نتایج مورد انتظار:

1. **یادگیری واقعی**: مدل باید قادر به یادگیری از داده‌های تاریخی باشد
2. **پیش‌بینی‌های معنادار**: پیش‌بینی‌ها باید بر اساس الگوهای واقعی بازار باشند نه تصادفی
3. **بهبود تدریجی**: دقت مدل باید با تمرین بیشتر بهبود یابد
4. **Backtesting دقیق**: نتایج backtest باید بازتاب واقعی عملکرد استراتژی باشد

### معیارهای موفقیت:

- ✅ دقت جهت‌دار > 55% (بهتر از random 50%)
- ✅ کاهش تدریجی loss در طول آموزش
- ✅ بهبود دقت در validation set
- ✅ نتایج backtest منطقی و قابل تفسیر

---

## 🔍 بررسی‌های اضافی توصیه‌شده

### 1. بررسی Feature Engineering
- اطمینان از اینکه features واقعاً مفید هستند
- اضافه کردن features جدید (مثلاً volatility clustering، momentum indicators)

### 2. بهبود سیستم Validation
- پیاده‌سازی walk-forward validation
- استفاده از time-series cross-validation
- جداسازی صحیح train/validation/test sets

### 3. اضافه کردن Regularization
- L1/L2 regularization برای جلوگیری از overfitting
- Dropout layers در شبکه
- Early stopping با patience

### 4. بهبود سیستم Monitoring
- ردیابی loss و accuracy در real-time
- هشدار در صورت divergence
- Dashboard برای مشاهده پیشرفت آموزش

---

## 📝 نتیجه‌گیری

پروژه BOLT AI دارای ساختار خوبی است اما **مشکلات بحرانی** در لایه یادگیری دارد که مانع از عملکرد واقعی می‌شود. با پیاده‌سازی راهکارهای پیشنهادی، سیستم قادر خواهد بود:

1. ✅ از داده‌های واقعی یاد بگیرد
2. ✅ پیش‌بینی‌های معنادار تولید کند
3. ✅ با گذشت زمان بهبود یابد
4. ✅ نتایج واقعی در backtesting نشان دهد

**اولویت**: رفع مشکلات فاز 1 برای شروع یادگیری واقعی ضروری است.

---

**تاریخ ایجاد**: 2025-11-02  
**وضعیت**: آماده برای پیاده‌سازی  
**اولویت**: 🔴 بالا
