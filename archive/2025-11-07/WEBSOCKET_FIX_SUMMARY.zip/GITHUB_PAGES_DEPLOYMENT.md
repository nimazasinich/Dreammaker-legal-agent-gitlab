# GitHub Pages Deployment Guide

This guide explains how to deploy the BOLT AI frontend to GitHub Pages.

## ✅ What's Already Configured

1. **GitHub Actions Workflow** (`.github/workflows/deploy-pages.yml`)
   - Automatically builds and deploys on push to `main`/`master`
   - Uses the latest GitHub Actions Pages deployment method

2. **Vite Configuration** (`vite.config.ts`)
   - Automatically detects GitHub Pages environment
   - Sets correct base path based on repository name

3. **Build Scripts** (`package.json`)
   - `npm run build:pages` - Builds for GitHub Pages
   - `npm run build:frontend` - Regular build
   - `npm run preview` - Preview built site locally

4. **`.nojekyll` file**
   - Prevents Jekyll processing on GitHub Pages
   - Ensures all files are served correctly

## 🚀 Quick Start Deployment

### Step 1: Enable GitHub Pages

1. Go to your repository on GitHub
2. Navigate to **Settings** → **Pages**
3. Under **Source**, select **GitHub Actions**
4. Save the settings

### Step 2: Push to Main Branch

```bash
git add .
git commit -m "Configure GitHub Pages deployment"
git push origin main
```

### Step 3: Verify Deployment

1. Go to the **Actions** tab in your repository
2. Wait for the workflow to complete (usually 2-5 minutes)
3. Once complete, your site will be available at:
   ```
   https://[your-username].github.io/[repo-name]/
   ```

## 🔧 Manual Deployment Steps

If you prefer to deploy manually:

```bash
# 1. Build for GitHub Pages
npm run build:pages

# 2. Copy dist folder contents to gh-pages branch
# (Use gh-pages package or manual git commands)
```

## 📝 Repository Name Configuration

The base path is automatically determined from your repository name:
- **Project page**: `https://username.github.io/repo-name/` → base path: `/repo-name/`
- **User page**: `https://username.github.io/` → base path: `/`

To customize the base path, edit `vite.config.ts` and modify the `getBasePath()` function.

## 🌐 Custom Domain Setup

1. Create a `CNAME` file in your repository root:
   ```
   yourdomain.com
   ```

2. The GitHub Actions workflow will automatically copy it to the dist folder

3. Configure DNS:
   - Add a CNAME record pointing to `[username].github.io`
   - Or add A records for GitHub Pages IPs

## 🔍 Troubleshooting

### Build Fails

- Check the Actions tab for error messages
- Ensure Node.js version is compatible (20.x recommended)
- Verify all dependencies are in `package.json`

### Site Not Loading

- Verify GitHub Pages is enabled in repository settings
- Check the base path matches your repository name
- Ensure `.nojekyll` file exists in the dist folder

### API Endpoints Not Working

- GitHub Pages only serves static files
- Backend API must be deployed separately
- Consider using environment variables to point to your API URL

## 📊 Deployment Status

Check deployment status:
- **Actions tab**: See workflow runs and status
- **Pages tab**: View deployment history and settings
- **Repository URL**: Test if site is live

## 🔄 Continuous Deployment

The workflow automatically deploys on:
- Push to `main` or `master` branch
- Manual workflow dispatch (Actions → Deploy to GitHub Pages → Run workflow)

## 🎯 Next Steps

1. **Backend Deployment**: Deploy the backend API to a cloud service
2. **Environment Variables**: Configure API endpoints for production
3. **Custom Domain**: Set up your custom domain (optional)
4. **Monitoring**: Set up monitoring for your deployed site

## 📚 Additional Resources

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html#github-pages)
