# ⚡ QUICK START - Run Locally in 30 Seconds

## The Easiest Way:

### Linux/Mac:
```bash
./start.sh
```

### Windows:
```bash
start.bat
```

**Done!** The app will be running at:
- Frontend: http://localhost:5173
- Backend: http://localhost:3001

---

## Manual Start (if scripts don't work):

```bash
# 1. Install dependencies (first time only)
npm install

# 2. Start the app
npm run dev
```

---

## What's Already Configured:

✅ **Redis**: Disabled (no Redis needed!)  
✅ **Database**: SQLite (auto-created)  
✅ **API Keys**: Pre-configured  
✅ **Ports**: Frontend 5173, Backend 3001  
✅ **Environment**: `.env` file ready  

---

## Troubleshooting:

**Port already in use?**
- Change `PORT=3001` in `.env`

**Dependencies missing?**
- Run `npm install`

**Still having issues?**
- See `LOCAL_SETUP.md` for detailed guide

---

**That's it!** No Redis, no PostgreSQL, no complex setup. Just run and go! 🚀
