# 🔑 راهنمای کامل تنظیم API Keys و حل مشکل CORS

## 📋 خلاصه مشکلات

1. **CORS Error (451)** - Binance API مستقیماً از frontend قابل دسترسی نیست
2. **401 Unauthorized** - CoinGecko API نیاز به API key دارد
3. **Geo-blocking** - Binance در بعضی کشورها محدود است

---

## ✅ راه‌حل‌های پیاده‌سازی شده

### 1️⃣ **Backend Proxy Routes** (پیاده‌سازی شده)

Proxy endpoints برای حل مشکل CORS ایجاد شده‌اند:

#### **Binance Proxy:**
- `GET /api/proxy/binance/klines` - دریافت candle data
- `GET /api/proxy/binance/ticker/24hr` - دریافت قیمت 24 ساعته

#### **CoinGecko Proxy:**
- `GET /api/proxy/coingecko/market_chart` - دریافت historical data
- `GET /api/proxy/coingecko/simple/price` - دریافت قیمت‌های فعلی

### 2️⃣ **به‌روزرسانی marketDataService.ts**

- استفاده خودکار از proxy endpoints
- Fallback به mock data در صورت خطا
- Error handling بهتر برای 451 و 401

---

## 🔧 تنظیم API Keys

### مرحله 1: دریافت CoinGecko API Key

1. **ثبت‌نام در CoinGecko:**
   - برو به: https://www.coingecko.com/en/api
   - ثبت‌نام کنید (رایگان)

2. **دریافت API Key:**
   - بعد از ثبت‌نام، به Dashboard بروید
   - از بخش API، یک Demo API Key بگیرید
   - (برای استفاده رایگان، Demo API کافی است)

### مرحله 2: تنظیم Environment Variables

#### **برای Development (.env):**

```bash
# CoinGecko API Key (اختیاری - برای rate limit بهتر)
COINGECKO_API_KEY=your_coingecko_api_key_here

# Backend Port
PORT=3001
BACKEND_PORT=3001
```

#### **برای Production:**

```bash
# در production environment (Vercel, Railway, etc.)
# Environment Variables را تنظیم کنید:
COINGECKO_API_KEY=your_production_key_here
```

### مرحله 3: بررسی فایل .env

```bash
# بررسی کنید که فایل .env وجود دارد
ls -la .env

# اگر وجود ندارد، از env.example کپی کنید
cp env.example .env

# سپس API key را اضافه کنید
```

---

## 🚀 استفاده از Proxy

### در Frontend (marketDataService.ts)

کد به صورت خودکار از proxy استفاده می‌کند:

```typescript
// ✅ استفاده از proxy (پیش‌فرض)
const url = '/api/proxy/binance/klines?symbol=BTCUSDT&interval=1h&limit=100';

// ❌ استفاده مستقیم (غیرفعال شده)
// const url = 'https://api.binance.com/api/v3/klines?...';
```

### تست کردن Proxy

```bash
# شروع backend server
npm run dev:server  # یا node src/server.ts

# تست Binance proxy
curl http://localhost:3001/api/proxy/binance/klines?symbol=BTCUSDT&interval=1h&limit=10

# تست CoinGecko proxy (با API key)
curl http://localhost:3001/api/proxy/coingecko/market_chart?coinId=bitcoin&days=7
```

---

## 🎯 Fallback Strategy

سیستم به صورت خودکار fallback می‌کند:

```
1. سعی می‌کند از Binance API استفاده کند (via proxy)
   ↓ (اگر 451 یا خطا)
2. سعی می‌کند از CoinGecko API استفاده کند (via proxy)
   ↓ (اگر 401 یا خطا)
3. از Mock Data استفاده می‌کند (generateMockChartData)
```

---

## 📊 Error Handling

### Status Codes:

| Code | معنی | راه‌حل |
|------|------|-------|
| **451** | Binance blocked | استفاده از VPN یا mock data |
| **401** | CoinGecko API key missing | اضافه کردن COINGECKO_API_KEY |
| **429** | Rate limit exceeded | کاهش درخواست‌ها یا upgrade plan |
| **500** | Server error | بررسی logs و proxy routes |

### Console Messages:

```
✅ Success:
  "✅ Generated 100 candles for BTC"

⚠️ Warning:
  "⚠️ Binance API blocked (451) - Geo restriction. Using mock data fallback."
  "⚠️ CoinGecko API key missing or invalid (401). Using mock data fallback."

❌ Error:
  "❌ Error loading chart data: ..."
```

---

## 🔍 Troubleshooting

### مشکل: هنوز CORS error می‌بینم

**راه‌حل:**
```bash
# 1. مطمئن شوید که backend server اجرا می‌شود
npm run dev:server

# 2. بررسی کنید که proxy routes loaded شده‌اند
# باید در console ببینید:
# "✅ CORS Proxy routes initialized"

# 3. بررسی کنید که از proxy استفاده می‌شود
# در marketDataService.ts:
# private useProxy = true; // باید true باشد
```

### مشکل: CoinGecko هنوز 401 می‌دهد

**راه‌حل:**
```bash
# 1. بررسی کنید که API key در .env موجود است
cat .env | grep COINGECKO

# 2. restart backend server
npm run dev:server

# 3. بررسی کنید که proxy route به درستی کار می‌کند
curl http://localhost:3001/api/proxy/coingecko/simple/price?ids=bitcoin
```

### مشکل: Binance 451 می‌دهد (Geo-blocked)

**راه‌حل:**
```bash
# 1. استفاده از VPN
# 2. یا استفاده از mock data (که به صورت خودکار فعال می‌شود)
# 3. یا استفاده از CoinGecko به عنوان جایگزین
```

---

## 📝 فایل‌های تغییر یافته

### ✅ ایجاد شده:

1. **`src/services/ProxyRoutes.ts`**
   - Proxy endpoints برای Binance و CoinGecko
   - Error handling کامل
   - Support برای API keys

2. **`API_KEYS_SETUP_GUIDE.md`**
   - این فایل - راهنمای کامل

### ✅ به‌روزرسانی شده:

1. **`src/services/marketDataService.ts`**
   - استفاده از proxy endpoints
   - Fallback به mock data
   - Error handling بهتر

2. **`src/server.ts`**
   - Import و setup ProxyRoutes

---

## 🎨 Flow Diagram

```
Frontend Request
    ↓
marketDataService.ts
    ↓
/api/proxy/binance/klines (via proxy)
    ↓
Backend Proxy (ProxyRoutes.ts)
    ↓
Binance API (https://api.binance.com)
    ↓
Response → Frontend
```

**اگر خطا:**
```
Binance API Error (451)
    ↓
Fallback to CoinGecko Proxy
    ↓
CoinGecko API Error (401)
    ↓
Fallback to Mock Data
    ↓
✅ Chart displays with mock data
```

---

## ⚙️ Configuration Options

### در marketDataService.ts:

```typescript
// Enable/Disable proxy
private useProxy = true; // true = use proxy, false = direct API

// Proxy URLs
private proxyUrl = '/api/proxy/binance';
private proxyUrl = '/api/proxy/coingecko';
```

### در vite.config.ts (برای development):

```typescript
proxy: {
  '/api/proxy': {
    target: 'http://localhost:3001',
    changeOrigin: true,
  }
}
```

---

## 📚 منابع بیشتر

- **CoinGecko API Docs:** https://www.coingecko.com/en/api/documentation
- **Binance API Docs:** https://binance-docs.github.io/apidocs/
- **CORS Guide:** `CORS_FIX_GUIDE.md`

---

## ✅ Checklist

- [x] Proxy routes ایجاد شد
- [x] marketDataService به‌روزرسانی شد
- [x] Error handling اضافه شد
- [x] Fallback به mock data
- [ ] CoinGecko API key اضافه شد (در .env)
- [ ] Backend server restart شد
- [ ] تست شد که proxy کار می‌کند

---

## 🚀 مراحل بعدی

1. **اضافه کردن API Key:**
   ```bash
   echo "COINGECKO_API_KEY=your_key_here" >> .env
   ```

2. **Restart Backend:**
   ```bash
   npm run dev:server
   ```

3. **Test:**
   ```bash
   # باز کردن browser
   http://localhost:5173
   
   # بررسی console - نباید CORS error باشد
   ```

---

**🎉 با این راهنما، مشکلات CORS و API errors باید حل شوند!**

---

*آخرین به‌روزرسانی: 2 نوامبر 2025*

