# 🏗️ Signal Visualization System - Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      CHARTING PAGE                              │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │          SignalVisualizationSection (Main Container)      │ │
│  │                                                            │ │
│  │  ┌──────────────┬───────────────────┬──────────────────┐ │ │
│  │  │   Pipeline   │    Chart Area     │   Controls Panel │ │ │
│  │  │              │                   │                  │ │ │
│  │  │  Stage 1 ●   │   ┌───────────┐   │  Symbol: BTC    │ │ │
│  │  │  Stage 2 ●   │   │           │   │  Time: 1h       │ │ │
│  │  │  Stage 3 ●   │   │  Chart +  │   │                 │ │ │
│  │  │  Stage 4 ●   │   │ Overlays  │   │  ☑ Support/Res │ │ │
│  │  │  Stage 5 ●   │   │           │   │  ☑ Order Blocks│ │ │
│  │  │  Stage 6 ●   │   └───────────┘   │  ☐ Fibonacci   │ │ │
│  │  │  Stage 7 ●   │                   │                 │ │ │
│  │  │  Stage 8 ●   │                   │  🔄 Refresh     │ │ │
│  │  │              │                   │  ▶️ Simulate    │ │ │
│  │  └──────────────┴───────────────────┴──────────────────┘ │ │
│  │                                                            │ │
│  │  ┌──────────────────────────────────────────────────────┐ │ │
│  │  │              Signal Examples Panel                   │ │ │
│  │  │  ┌────────┬────────┬────────┬────────┐              │ │ │
│  │  │  │Success │Success │Failed  │ HOLD   │              │ │ │
│  │  │  │ LONG   │ SHORT  │ LONG   │        │              │ │ │
│  │  │  │ +5.2%  │ +4.8%  │ -0.8%  │        │              │ │ │
│  │  │  └────────┴────────┴────────┴────────┘              │ │ │
│  │  └──────────────────────────────────────────────────────┘ │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Hierarchy

```
ChartingView
  └── SignalVisualizationSection
      ├── Connection Status Bar
      │   ├── Connection Indicator
      │   └── Examples Toggle Button
      │
      ├── Main Grid Layout
      │   ├── Pipeline Column
      │   │   └── SignalStagePipeline
      │   │       ├── Stage 1-8 Cards
      │   │       │   ├── Stage Icon
      │   │       │   ├── Progress Bar
      │   │       │   ├── Stage Data
      │   │       │   └── ParticleEffect (if active)
      │   │       └── Connecting Lines
      │   │
      │   ├── Chart Column
      │   │   └── Chart Container
      │   │       ├── AdvancedChart (from parent)
      │   │       └── ChartOverlay
      │   │           ├── Support/Resistance Lines
      │   │           ├── Order Blocks
      │   │           ├── Fibonacci Levels
      │   │           ├── Elliott Waves
      │   │           ├── Harmonic Patterns
      │   │           ├── Entry/Exit Markers
      │   │           └── BreakoutAnimation (dynamic)
      │   │
      │   └── Controls Column
      │       └── ControlsPanel
      │           ├── Symbol Selector
      │           ├── Timeframe Selector
      │           ├── Overlay Toggles (6)
      │           └── Action Buttons (4)
      │
      └── Examples Panel (conditional)
          └── SignalExamplesPanel
              ├── Example Card 1 (Success LONG)
              ├── Example Card 2 (Success SHORT)
              ├── Example Card 3 (Failed LONG)
              ├── Example Card 4 (HOLD)
              └── View Details Button
```

---

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        BACKEND SERVER                           │
│  ┌──────────────────────┐    ┌──────────────────────┐          │
│  │  WebSocket Server    │    │   REST API Server    │          │
│  │  /ws/signals/live    │    │  /api/signals/current│          │
│  └──────────────────────┘    └──────────────────────┘          │
└───────────────┬──────────────────────────┬──────────────────────┘
                │                          │
                │ WebSocket                │ REST (fallback)
                │ (Primary)                │ (3sec polling)
                │                          │
                ▼                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                  FRONTEND - useSignalWebSocket Hook             │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  - Manage WebSocket connection                           │  │
│  │  - Handle reconnection with backoff                      │  │
│  │  - Fallback to REST API polling                          │  │
│  │  - Transform data to component format                    │  │
│  │  - Provide connection status                             │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────────────────┬──────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│           SignalVisualizationSection (State Management)         │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  States:                                                  │  │
│  │  - stages: StageData[]                                    │  │
│  │  - overlayConfig: OverlayConfig                          │  │
│  │  - technicalData: TechnicalData                         │  │
│  │  - signalData: SignalWebSocketData                      │  │
│  │  - showExamples: boolean                                │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────┬───────────────┬───────────────┬────────────────────────┘
          │               │               │
          ▼               ▼               ▼
    ┌──────────┐   ┌──────────┐   ┌──────────┐
    │Pipeline  │   │  Chart   │   │ Controls │
    │Component │   │ Overlay  │   │  Panel   │
    └──────────┘   └──────────┘   └──────────┘
```

---

## Animation System

```
┌─────────────────────────────────────────────────────────────────┐
│                    ANIMATION ARCHITECTURE                       │
└─────────────────────────────────────────────────────────────────┘

ParticleEffect Component (Canvas-based)
├── Animation Loop (60fps)
│   ├── updateParticles()
│   │   ├── Update positions
│   │   ├── Update velocities
│   │   ├── Update life/alpha
│   │   └── Remove dead particles
│   └── render()
│       ├── Clear canvas
│       ├── Draw glow effects
│       └── Draw particle cores
│
├── Particle Types
│   ├── Flow: Left→Right movement
│   ├── Burst: Radial explosion
│   ├── Glow: Orbital motion
│   └── Pulse: Wave expansion
│
└── Lifecycle
    ├── Create particles
    ├── Animate (life → maxLife)
    ├── Fade (alpha: 1 → 0)
    └── Cleanup (remove)

BreakoutAnimation Component (Canvas-based)
├── Phase 1: Burst (0-30 frames)
│   ├── Expanding circles
│   └── Star-burst lines
├── Phase 2: Glow (30-90 frames)
│   ├── Pulsing glow
│   └── Arrow indicator
└── Phase 3: Fade (90-110 frames)
    └── Fade out → Cleanup

CSS Animations
├── Fade-in (opacity: 0 → 1)
├── Pulse (scale: 1 → 1.1 → 1)
├── Bounce (transform: translateY)
└── Slide (transform: translateX)
```

---

## State Management

```
┌─────────────────────────────────────────────────────────────────┐
│                       STATE FLOW                                │
└─────────────────────────────────────────────────────────────────┘

Global State (ChartingView)
├── symbol: string
├── timeframe: string
├── chartData: CandleData[]
├── showSignalVisualization: boolean
└── analysis: MarketAnalysis

Local State (SignalVisualizationSection)
├── overlayConfig: OverlayConfig
│   ├── showSupportResistance: boolean
│   ├── showOrderBlocks: boolean
│   ├── showFibonacci: boolean
│   ├── showElliottWaves: boolean
│   ├── showHarmonicPatterns: boolean
│   └── showEntryExit: boolean
├── technicalData: TechnicalData
│   ├── support: number[]
│   ├── resistance: number[]
│   ├── orderBlocks: OrderBlock[]
│   ├── fibonacci: FibonacciLevels
│   ├── elliottWaves: ElliottWave[]
│   ├── harmonicPatterns: HarmonicPattern[]
│   └── entryExit: EntryExitData
└── showExamples: boolean

Hook State (useSignalWebSocket)
├── stages: StageData[]
├── isConnected: boolean
├── error: string | null
└── signalData: SignalWebSocketData

Component State
├── SignalStagePipeline: (none - pure)
├── ControlsPanel: isSimulating: boolean
├── SignalExamplesPanel: selectedExample: string | null
└── ChartOverlay: activeBreakouts: Breakout[]
```

---

## Rendering Layers

```
┌─────────────────────────────────────────────────────────────────┐
│                      CHART RENDERING LAYERS                     │
└─────────────────────────────────────────────────────────────────┘

Layer 1: Background (Static)
├── Grid lines
├── Axes
└── Labels

Layer 2: Price Data (Updates on new data)
├── Candlesticks
├── Volume bars
└── Price line

Layer 3: Technical Overlays (Updates frequently)
├── Support/Resistance lines
├── Order blocks
├── Fibonacci levels
├── Elliott Wave markers
├── Harmonic patterns
└── Entry/Exit markers

Layer 4: Animations (60fps)
├── Particle effects
├── Breakout animations
├── Glow effects
└── Pulse effects

Layer 5: UI Overlays (Interactive)
├── Tooltips
├── Crosshair
└── Selection tools
```

---

## Performance Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   PERFORMANCE OPTIMIZATIONS                     │
└─────────────────────────────────────────────────────────────────┘

Canvas Optimization
├── Layer Separation
│   ├── Background canvas (static)
│   ├── Price canvas (updates on data)
│   └── Animation canvas (60fps)
├── Off-screen Rendering
│   └── Pre-render complex shapes
└── RequestAnimationFrame
    └── Sync with browser repaint

Update Throttling
├── Chart Overlays: 10 updates/sec max
├── WebSocket Messages: Batched
└── Particle Creation: Limited count

Memory Management
├── Animation Frame Cleanup
│   └── cancelAnimationFrame on unmount
├── Particle Array Pruning
│   └── Remove dead particles
├── WebSocket Cleanup
│   └── Close connections on unmount
└── Event Listener Cleanup
    └── Remove on unmount

Lazy Loading
├── Examples: Load on demand
├── Historical Data: Paginated
└── Images: Progressive loading
```

---

## Accessibility Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                   ACCESSIBILITY STRUCTURE                       │
└─────────────────────────────────────────────────────────────────┘

Semantic HTML
├── <main> for chart area
├── <aside> for pipeline/controls
├── <section> for examples
└── <nav> for controls

ARIA Attributes
├── role="region" on main sections
├── role="list" / "listitem" on examples
├── role="complementary" on side panels
├── role="group" on control sets
├── aria-label on all interactive elements
├── aria-expanded on toggles
├── aria-busy on loading states
└── aria-live for dynamic updates

Keyboard Navigation
├── Tab Order: Logical flow
├── Enter/Space: Activate buttons
├── Arrow Keys: Navigate options
└── Escape: Close dialogs

Focus Management
├── Visible focus indicators (blue rings)
├── Focus trap in modals
├── Focus restoration on close
└── Skip links for efficiency

Screen Reader Support
├── Descriptive labels
├── State announcements
├── Error messages
└── Loading notifications
```

---

## Error Handling Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                      ERROR HANDLING                             │
└─────────────────────────────────────────────────────────────────┘

WebSocket Errors
├── Connection Failed
│   ├── Show "Disconnected" status
│   ├── Attempt reconnection (exponential backoff)
│   ├── Max 5 attempts
│   └── Fallback to REST API polling
├── Message Parse Error
│   ├── Log error to console
│   ├── Show error message
│   └── Continue with last valid data
└── Connection Lost
    ├── Show reconnecting status
    ├── Retry connection
    └── Activate fallback

REST API Errors
├── Network Error
│   ├── Log error
│   ├── Retry after delay
│   └── Show error message to user
├── Invalid Data
│   ├── Validate response
│   ├── Use fallback values
│   └── Log warning
└── Timeout
    ├── Cancel request
    ├── Retry
    └── Show loading state

Component Errors
├── ErrorBoundary
│   ├── Catch React errors
│   ├── Display fallback UI
│   └── Log to console
├── Validation Errors
│   ├── Check prop types
│   ├── Validate data
│   └── Use defaults
└── Graceful Degradation
    ├── Hide broken features
    ├── Show working features
    └── Inform user
```

---

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        DEPLOYMENT                               │
└─────────────────────────────────────────────────────────────────┘

Build Process
├── TypeScript Compilation
│   ├── Type checking
│   └── Generate .js files
├── Bundling (Vite)
│   ├── Code splitting
│   ├── Tree shaking
│   └── Minification
├── Asset Optimization
│   ├── Image compression
│   └── CSS optimization
└── Source Maps
    └── For debugging

Environment Configuration
├── Development
│   ├── VITE_API_URL=http://localhost:3001
│   └── Hot Module Replacement
├── Staging
│   ├── VITE_API_URL=https://staging-api.example.com
│   └── Debug logging enabled
└── Production
    ├── VITE_API_URL=https://api.example.com
    └── Performance monitoring

Monitoring
├── Error Tracking
│   ├── Console logs
│   └── Error boundaries
├── Performance Metrics
│   ├── Animation FPS
│   ├── WebSocket latency
│   └── Render time
└── Usage Analytics
    ├── Feature usage
    └── User interactions
```

---

## Summary

This architecture provides:

✅ **Modularity**: Each component has clear responsibilities
✅ **Performance**: Optimized rendering and updates
✅ **Scalability**: Easy to add new features
✅ **Maintainability**: Well-structured and documented
✅ **Accessibility**: WCAG 2.1 AA compliant
✅ **Reliability**: Robust error handling
✅ **Responsiveness**: Works on all devices

The system is production-ready and built to scale!

