# Railway Deployment Configuration

## Quick Start

1. Install Railway CLI:
```bash
npm i -g @railway/cli
```

2. Login:
```bash
railway login
```

3. Initialize project:
```bash
railway init
```

4. Add PostgreSQL database:
```bash
railway add postgresql
```

5. Add Redis (optional):
```bash
railway add redis
```

6. Set environment variables:
```bash
railway variables set NODE_ENV=production
railway variables set PORT=3001
```

7. Deploy:
```bash
railway up
```

## Environment Variables

Set these in Railway dashboard:

- `NODE_ENV=production`
- `PORT=3001` (Railway sets this automatically)
- `DATABASE_URL` (set automatically when you add PostgreSQL)
- `REDIS_URL` (set automatically when you add Redis)
- `BINANCE_API_KEY=your_key`
- `BINANCE_SECRET_KEY=your_secret`

## Custom Domain

1. Go to Railway dashboard
2. Select your service
3. Go to Settings > Networking
4. Add custom domain

SSL is automatically configured!
