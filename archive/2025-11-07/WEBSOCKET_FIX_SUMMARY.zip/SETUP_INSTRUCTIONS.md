# 🚀 دستورالعمل راه‌اندازی و اجرای پروژه

## ✅ وضعیت پروژه
**همه مشکلات بحرانی رفع شد!** 🎉

- ✅ مشکل اسپم Redis کاملا حل شد
- ✅ Rate limiting و fallback برای API providers اضافه شد
- ✅ Caching برای کاهش API calls پیاده شد
- ✅ Error logging throttled شد

---

## 📦 پیش‌نیازها

```bash
# Node.js version
node --version  # باید 18+ باشد

# وابستگی‌ها
npm install
```

---

## ⚙️ تنظیمات محیط

### گزینه 1: بدون Redis (توصیه می‌شود برای تست اولیه)

```bash
# Windows PowerShell
$env:DISABLE_REDIS="true"; npm start

# یا در Linux/Mac
DISABLE_REDIS=true npm start

# یا برای development mode
DISABLE_REDIS=true npm run dev
```

### گزینه 2: با API Keys (اختیاری)

فایل `env.example` را به `.env` کپی کنید و کلیدهای API را اضافه کنید:

```bash
# ساخت فایل env
cp env.example .env

# ویرایش فایل env و اضافه کردن کلیدهای API
# CMC_API_KEY=your_key_here
# CRYPTOCOMPARE_KEY=your_key_here
```

**توجه**: بدون API keys هم پروژه کار می‌کند، اما فقط از CoinGecko و CryptoCompare رایگان استفاده می‌شود.

---

## 🏃 اجرای پروژه

### گزینه 1: Development Mode (توصیه می‌شود)

```bash
# در PowerShell
$env:DISABLE_REDIS="true"; npm run dev

# در Bash/Zsh
DISABLE_REDIS=true npm run dev
```

این دستور دو سرور را همزمان اجرا می‌کند:
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:3001

### گزینه 2: Production Mode

```bash
# Build پروژه
npm run build

# اجرای production
npm start

# یا بدون Redis
$env:DISABLE_REDIS="true"; npm start
```

---

## 🧪 تست API Endpoints

پس از اجرای پروژه:

### 1. Health Check
```bash
curl http://localhost:3001/api/health
```

### 2. تست قیمت‌های زنده
```bash
curl "http://localhost:3001/api/market/prices?symbols=BTC,ETH,USDT"
```

### 3. تست Sentiment
```bash
curl http://localhost:3001/api/market/sentiment
```

### 4. تست Real Data Mode
```bash
curl http://localhost:3001/api/test/real-data
```

---

## 🐛 عیب‌یابی

### مشکل: پورت 3001 درگیر است

```bash
# Windows
netstat -ano | findstr ":3001"
taskkill /PID <PID_NUMBER> /F

# Linux/Mac
lsof -ti:3001 | xargs kill -9
```

### مشکل: Build errors

```bash
# پاک کردن و build مجدد
npm run clean 2>$null; npm run build
```

### مشکل: Cannot find module

```bash
# نصب مجدد وابستگی‌ها
rm -rf node_modules package-lock.json
npm install
```

### مشکل: Redis errors

```bash
# خاموش کردن Redis
$env:DISABLE_REDIS="true"; npm start
```

---

## 📊 لاگ‌ها

لاگ‌ها در پوشه `logs/` ذخیره می‌شوند:

```bash
# مشاهده آخرین لاگ
Get-Content logs/bolt-ai-*.log -Tail 50

# یا در Linux/Mac
tail -f logs/bolt-ai-*.log
```

---

## ⚡ بهبودهای اعمال شده

### 1. Redis
- **قبل**: اسپم لاگ هر ثانیه
- **بعد**: لاگ فقط هر 60 ثانیه + حالت no-op

### 2. API Providers
- **قبل**: Rate limit errors و خرابی کامل
- **بعد**: Rate limiting + fallback chain

### 3. Performance
- **قبل**: هر request = API call جدید
- **بعد**: Caching (5-60s) + batching

### 4. Error Handling
- **قبل**: لاگ اسپم برای هر خطا
- **بعد**: Throttled logging (هر 10-60s یکبار)

---

## 🎯 وضعیت فعلی

```
✅ Redis: No-op mode کار می‌کند
✅ API Providers: Rate limited + cached
✅ Fallbacks: CoinGecko → CryptoCompare → ...
✅ Logging: Throttled (no spam)
✅ Server: Stable و آماده production
```

---

## 📝 نکات مهم

1. **Redis اختیاری است**: می‌توانید بدون آن کار کنید
2. **API Keys اختیاری هستند**: فقط CoinGecko رایگان کافی است
3. **Rate Limiting فعال است**: حداکثر 1-2 request/second per provider
4. **Caching فعال است**: داده‌ها 5-60 ثانیه cache می‌شوند
5. **Error Handling**: همه خطاها gracefully handle می‌شوند

---

## 🔧 تنظیمات پیشرفته

ویرایش `src/config/flags.ts`:

```typescript
// Cache TTL
PRICE_CACHE_TTL_MS = 5000      // 5 ثانیه
PROVIDER_TTL_MS = 60000        // 60 ثانیه

// Rate Limits
CMC: 5 capacity, 1 req/sec
CoinGecko: 10 capacity, 2 req/sec
CryptoCompare: 10 capacity, 2 req/sec
```

---

## ✅ چک‌لیست نهایی

- [ ] Node.js 18+ نصب شده
- [ ] `npm install` اجرا شده
- [ ] `DISABLE_REDIS=true` تنظیم شده
- [ ] `npm run dev` یا `npm start` اجرا می‌شود
- [ ] API `/health` پاسخ می‌دهد
- [ ] لاگ‌ها بدون اسپم هستند
- [ ] قیمت‌ها از API های واقعی می‌آیند

---

**پروژه آماده استفاده است! 🎉**

برای سوالات یا مشکلات بیشتر به فایل `STABILIZATION_COMPLETE.md` مراجعه کنید.

