# GitHub CLI Installation and Usage Guide

## Installation

### macOS
```bash
brew install gh
```

### Linux
```bash
# Debian/Ubuntu
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh

# Fedora/RHEL
sudo dnf install gh
```

### Windows
```powershell
# Using winget
winget install GitHub.cli

# Using Chocolatey
choco install gh

# Using Scoop
scoop install gh
```

### Manual Installation
Download from: https://cli.github.com/

## Authentication

```bash
# Login to GitHub
gh auth login

# Check authentication status
gh auth status

# Logout
gh auth logout
```

## Available Scripts

All scripts are located in `scripts/github/`:

### 1. **gh-status.sh** - View Project Status
```bash
./scripts/github/gh-status.sh
# or
npm run gh:status
```
Shows:
- Repository information
- Open/closed issues and PRs
- Recent releases
- Workflow run status

### 2. **gh-release.sh** - Create Release
```bash
# Create release from package.json version
./scripts/github/gh-release.sh
# or
npm run gh:release

# Create release with specific version
./scripts/github/gh-release.sh 1.2.3

# Create draft release
./scripts/github/gh-release.sh 1.2.3 --draft

# Create prerelease
./scripts/github/gh-release.sh 1.2.3 --prerelease
```

### 3. **gh-issue.sh** - Create Issue
```bash
# Create issue interactively
./scripts/github/gh-issue.sh
# or
npm run gh:issue

# Create bug report
./scripts/github/gh-issue.sh "Bug description" --bug

# Create feature request
./scripts/github/gh-issue.sh "Feature description" --feature
```

### 4. **gh-pr.sh** - Create Pull Request
```bash
# Create PR interactively
./scripts/github/gh-pr.sh
# or
npm run gh:pr

# Create PR with title
./scripts/github/gh-pr.sh "PR Title"

# Create PR to specific branch
./scripts/github/gh-pr.sh "PR Title" develop
```

### 5. **gh-sync.sh** - Sync with GitHub
```bash
# Pull and push
./scripts/github/gh-sync.sh
# or
npm run gh:sync

# Push only
./scripts/github/gh-sync.sh --push

# Pull only
./scripts/github/gh-sync.sh --pull
```

### 6. **gh-setup.sh** - Setup Repository
```bash
./scripts/github/gh-setup.sh
# or
npm run gh:setup
```
Configures:
- GitHub Pages
- GitHub Discussions
- GitHub Projects
- Dependabot
- Repository topics

## Common GitHub CLI Commands

### Repository Management
```bash
# View repository
gh repo view --web

# Clone repository
gh repo clone owner/repo

# Fork repository
gh repo fork owner/repo

# Create repository
gh repo create my-repo --public --clone
```

### Issues
```bash
# List issues
gh issue list

# View issue
gh issue view 123

# Create issue
gh issue create --title "Title" --body "Description"

# Close issue
gh issue close 123

# Add labels
gh issue edit 123 --add-label "bug"
```

### Pull Requests
```bash
# List PRs
gh pr list

# View PR
gh pr view 123

# Create PR
gh pr create --title "Title" --body "Description"

# Checkout PR
gh pr checkout 123

# Merge PR
gh pr merge 123 --squash
```

### Releases
```bash
# List releases
gh release list

# View release
gh release view v1.0.0

# Create release
gh release create v1.0.0 --title "Release" --notes "Notes"

# Download release assets
gh release download v1.0.0
```

### Workflows
```bash
# List workflow runs
gh run list

# View workflow run
gh run view 1234567890

# Rerun workflow
gh run rerun 1234567890

# Watch workflow
gh run watch 1234567890
```

### Projects
```bash
# List projects
gh project list

# View project
gh project view 123

# Create project
gh project create --title "My Project"
```

## Resources

- [GitHub CLI Documentation](https://cli.github.com/manual/)
- [GitHub CLI Examples](https://cli.github.com/manual/examples)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
