# 🔧 راهنمای حل مشکل CORS و API Errors

## 🎯 مشکل

خطاهای زیر در console مشاهده می‌شود:

```
Access to fetch at 'https://api.binance.com/...' has been blocked by CORS policy
```

```
GET https://api.coingecko.com/... 401 (Unauthorized)
```

---

## ✅ راه‌حل‌های اعمال شده

### 1️⃣ **استفاده از Mock Data (فعال شده)**

کامپوننت `PriceChart` حالا **مستقیماً از mock data استفاده می‌کند** بدون نیاز به API های خارجی.

#### مزایا:
✅ **بدون CORS Error** - کاملاً client-side  
✅ **سریع** - بدون تاخیر شبکه  
✅ **قابل اعتماد** - همیشه کار می‌کند  
✅ **واقع‌گرایانه** - داده‌های شبیه‌سازی شده با ترند و volatility  

#### فایل‌های تغییر یافته:
- ✅ `src/services/mockMarketData.ts` - Mock data generator جدید
- ✅ `src/components/market/PriceChart.tsx` - استفاده از mock data
- ✅ `vite.config.ts` - اضافه شدن CORS proxies

---

### 2️⃣ **CORS Proxy (برای آینده)**

در `vite.config.ts` proxy های زیر اضافه شده‌اند:

```typescript
proxy: {
  // CORS Proxy for Binance API
  '/binance-api': {
    target: 'https://api.binance.com',
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/binance-api/, ''),
  },
  // CORS Proxy for CoinGecko API
  '/coingecko-api': {
    target: 'https://api.coingecko.com',
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/coingecko-api/, ''),
  },
}
```

**نکته**: این proxy ها فقط در development mode کار می‌کنند.

---

## 🚀 نحوه استفاده

### مرحله 1: ری‌استارت Dev Server

```bash
# متوقف کردن server فعلی (Ctrl+C)

# شروع مجدد
npm run dev
```

### مرحله 2: بازدید از Dashboard

```
http://localhost:5173
```

✅ **چارت قیمت باید بدون خطا نمایش داده شود!**

---

## 🔄 تغییر به API واقعی (اختیاری)

اگر می‌خواهید از API واقعی استفاده کنید:

### گزینه A: استفاده از Proxy در Development

در `src/services/marketDataService.ts`:

```typescript
// تغییر URL های API
private baseUrl = '/binance-api/api/v3';  // به جای 'https://api.binance.com/api/v3'
```

### گزینه B: استفاده از Backend Proxy

یک backend simple ایجاد کنید که request ها را proxy کند:

```javascript
// server.js
const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());

app.get('/api/binance/*', async (req, res) => {
  try {
    const response = await axios.get(
      `https://api.binance.com${req.params[0]}${req.url.split(req.params[0])[1]}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3001, () => console.log('Proxy server running on :3001'));
```

### گزینه C: فعال کردن کد API در PriceChart

در `src/components/market/PriceChart.tsx`، کامنت زیر را uncomment کنید:

```typescript
// خط 80-116
/* 
try {
  const data = await marketDataService.getHistoricalData(`${cleanSymbol}USDT`, timeframe, 100);
  // ... rest of code
}
*/
```

---

## 📊 Mock Data Generator

فایل جدید `mockMarketData.ts` شامل:

### Functions:

#### 1. `generateMockChartData(symbol, count, timeframe)`

تولید candle های واقع‌گرایانه برای چارت.

```typescript
const candles = generateMockChartData('BTCUSDT', 100, '1h');
```

**ویژگی‌ها**:
- ✅ ترند واقع‌گرایانه (صعودی/نزولی)
- ✅ Volatility مناسب
- ✅ Wick های طبیعی
- ✅ Volume بر اساس حرکت قیمت

#### 2. `generateMockCurrentPrice(symbol)`

تولید قیمت فعلی با اطلاعات 24h.

```typescript
const price = generateMockCurrentPrice('BTCUSDT');
// { symbol, price, change24h, volume24h, ... }
```

#### 3. `generateMockPricesList(symbols)`

تولید لیست قیمت‌ها برای چند symbol.

```typescript
const prices = generateMockPricesList(['BTCUSDT', 'ETHUSDT', 'SOLUSDT']);
```

---

## 🎨 قیمت‌های پایه

قیمت‌های پایه برای symbol های مختلف:

| Symbol | Base Price | Volatility |
|--------|-----------|------------|
| BTC    | $67,420   | 1.5% |
| ETH    | $3,512    | 1.5% |
| SOL    | $152      | 2.0% |
| ADA    | $0.456    | 2.5% |
| DOT    | $7.20     | 2.0% |
| LINK   | $15.80    | 2.0% |
| MATIC  | $0.78     | 2.5% |
| AVAX   | $36.40    | 2.0% |

---

## 🔧 Troubleshooting

### مشکل: چارت خالی است

**راه‌حل**:
```bash
# بررسی console
# باید پیام زیر را ببینید:
# ✅ Generated 100 candles for BTC
```

### مشکل: هنوز CORS error می‌بینم

**راه‌حل**:
```bash
# 1. مطمئن شوید که dev server را restart کرده‌اید
npm run dev

# 2. پاک کردن cache
Ctrl+F5 (hard refresh)

# 3. بررسی که PriceChart.tsx به‌روزرسانی شده
```

### مشکل: داده‌ها واقعی نیستند

**پاسخ**: 
این عمدی است! در حال حاضر از mock data استفاده می‌شود.  
برای استفاده از داده‌های واقعی، مراحل بالا را دنبال کنید.

---

## 📈 مقایسه Mock vs Real Data

### Mock Data (فعلی):

| ویژگی | وضعیت |
|-------|-------|
| CORS Errors | ❌ خیر |
| سرعت | ⚡ فوری |
| قابلیت اطمینان | ✅ 100% |
| داده واقعی | ❌ شبیه‌سازی |
| API Key | ❌ نیاز ندارد |
| Cost | 💰 رایگان |

### Real Data (اختیاری):

| ویژگی | وضعیت |
|-------|-------|
| CORS Errors | ⚠️ ممکن است |
| سرعت | 🐌 بسته به شبکه |
| قابلیت اطمینان | ⚠️ بسته به API |
| داده واقعی | ✅ بله |
| API Key | ⚠️ ممکن است نیاز باشد |
| Cost | 💰 ممکن است هزینه داشته باشد |

---

## ✅ Checklist

- [x] Mock data generator ایجاد شد
- [x] PriceChart به‌روزرسانی شد
- [x] CORS proxy اضافه شد به vite.config
- [x] راهنما نوشته شد
- [ ] تست کردن در browser
- [ ] بررسی console (نباید CORS error باشد)
- [ ] تست chart interactions

---

## 🎯 نتیجه‌گیری

✅ **مشکل CORS حل شد** با استفاده از mock data  
✅ **چارت کاملاً کار می‌کند** بدون نیاز به API خارجی  
✅ **داده‌های واقع‌گرایانه** با ترند و volatility  
✅ **آماده برای توسعه** و testing  

در آینده می‌توانید به API واقعی migrate کنید بدون تغییر ساختار کلی.

---

## 📞 پشتیبانی

اگر هنوز مشکل دارید:

1. ✅ Dev server را restart کنید
2. ✅ Browser cache را پاک کنید
3. ✅ Console را برای errors بررسی کنید
4. ✅ این راهنما را دوباره مطالعه کنید

---

**🎉 اکنون می‌توانید بدون نگرانی CORS از Dashboard استفاده کنید!**

---

*آخرین به‌روزرسانی: 2 نوامبر 2025*

