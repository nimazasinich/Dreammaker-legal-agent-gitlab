# Quick Start Guide - Backend Server & WebSocket

## 🚀 Starting the Backend Server

To enable WebSocket connections and real-time features, you need to start the backend server on port 3001.

### Option 1: Run Both Frontend & Backend Together (Recommended)

```bash
# Windows PowerShell
npm run dev

# This runs:
# - Frontend (Vite): http://localhost:5173
# - Backend (Server): http://localhost:3001
```

### Option 2: Run Backend Separately

```bash
# Windows PowerShell
npm run dev:backend:real

# Or for simple server
npm run dev:backend
```

### Option 3: Production Mode

```bash
# Build first
npm run build

# Then start
npm start
```

## ✅ Verifying Backend is Running

### Check Backend Health
Open in browser or use curl:
```
http://localhost:3001/health
```

### Check WebSocket Connection
Open browser console and run:
```javascript
const ws = new WebSocket('ws://localhost:3001/ws');
ws.onopen = () => console.log('✅ WebSocket connected!');
ws.onerror = (e) => console.error('❌ WebSocket error:', e);
ws.onclose = (e) => console.log('WebSocket closed:', e.code);
```

## 🔍 Troubleshooting

### WebSocket "Invalid frame header" Error
- **Cause**: Backend server is not running or not configured for WebSocket
- **Solution**: Start the backend server using one of the options above
- **Note**: The app will work without WebSocket, but real-time features won't be available

### Backend Port Already in Use
If port 3001 is already in use:
```bash
# Windows - Find and kill process on port 3001
netstat -ano | findstr :3001
taskkill /PID <PID> /F

# Or use the provided script
.\kill-port-3001.bat
```

### Environment Variables
Create a `.env` file (copy from `env.example`) if you need:
- API keys for external services
- Redis configuration
- Custom port settings

## 📝 Current Status

✅ **Fixed Issues:**
- WebSocket error handling improved (quieter logs)
- MarketView dynamic import issues resolved
- Vite environment variable compatibility fixed
- Graceful degradation when backend is unavailable

✅ **App Behavior:**
- Works without backend (uses fallback data)
- Real-time features enabled when backend is running
- Helpful console messages in development mode

## 🎯 Next Steps

1. **If you need WebSocket**: Start backend with `npm run dev`
2. **If you don't need WebSocket**: App works fine without it
3. **Check console**: Look for informative messages, not errors

The app is now resilient and will work in both scenarios!

