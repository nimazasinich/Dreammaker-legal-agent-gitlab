# 🚀 BOLT AI - Local Development Guide

## Quick Start (Easiest Way)

### For Linux/Mac:
```bash
./start.sh
```

### For Windows:
```bash
start.bat
```

**That's it!** The script will:
- ✅ Check Node.js installation
- ✅ Create necessary directories
- ✅ Install dependencies (if needed)
- ✅ Create `.env` file (if missing)
- ✅ Start both frontend and backend

---

## Manual Setup (Step by Step)

### 1. Prerequisites

- **Node.js 18+** (LTS recommended)
  - Download: https://nodejs.org/
  - Verify: `node -v` (should show v18 or higher)

- **npm** (comes with Node.js)
  - Verify: `npm -v`

### 2. Install Dependencies

```bash
npm install
```

This installs all required packages (might take 2-3 minutes).

### 3. Environment Setup

The `.env` file is already created for you with:
- ✅ Redis **disabled** by default (no Redis needed!)
- ✅ All API keys pre-configured
- ✅ Development mode enabled

**No changes needed** - it works out of the box!

### 4. Start Development Server

```bash
npm run dev
```

This starts:
- **Frontend**: http://localhost:5173 (Vite dev server)
- **Backend**: http://localhost:3001 (Express API)

---

## What's Included

### ✅ Zero Configuration Required
- Database: SQLite (auto-created in `data/boltai.db`)
- Redis: Disabled by default (no Redis installation needed)
- API Keys: Pre-configured with demo keys
- Config: Auto-generated from `config/api.json`

### ✅ Error-Free Setup
- All dependencies managed
- Database auto-initializes
- Redis gracefully disabled if not available
- Fallback mechanisms for all external APIs

### ✅ Development Features
- Hot reload (frontend + backend)
- TypeScript compilation
- Error boundaries
- Development logging

---

## Troubleshooting

### Problem: "Cannot find module"
**Solution:** Run `npm install` again

### Problem: Port already in use
**Solution:** 
- Change `PORT=3001` in `.env` to another port
- Or kill the process using port 3001:
  ```bash
  # Linux/Mac
  lsof -ti:3001 | xargs kill -9
  
  # Windows
  netstat -ano | findstr :3001
  taskkill /PID <PID> /F
  ```

### Problem: Database errors
**Solution:** 
- Delete `data/boltai.db` and restart
- The database will be recreated automatically

### Problem: Redis connection errors
**Solution:** 
- Redis is disabled by default (`DISABLE_REDIS=true` in `.env`)
- If you see Redis errors, ensure `.env` has `DISABLE_REDIS=true`

### Problem: Build errors
**Solution:**
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
```

---

## Project Structure

```
.
├── src/              # Source code
│   ├── components/   # React components
│   ├── services/     # Business logic
│   ├── views/        # Page views
│   ├── ai/           # AI/ML modules
│   └── server*.ts    # Backend servers
├── config/           # Configuration files
├── data/             # SQLite database
├── .env              # Environment variables
├── start.sh          # Linux/Mac startup script
├── start.bat         # Windows startup script
└── package.json      # Dependencies and scripts
```

---

## Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development (frontend + backend) |
| `npm run dev:frontend` | Start only frontend |
| `npm run dev:backend` | Start only backend |
| `npm run build` | Build for production |
| `npm start` | Run production build |
| `npm test` | Run tests |
| `npm run setup` | Quick setup (install + create dirs) |
| `npm run check` | Check Node.js version |

---

## Configuration Files

### `.env` (Environment Variables)
- Controls Redis, API keys, ports
- Already configured - **no changes needed**

### `config/api.json` (API Configuration)
- Database path: `./data/boltai.db` (relative path)
- API providers configuration
- Auto-created if missing

---

## Features That Work Out of the Box

✅ **Market Data**: Real-time cryptocurrency prices  
✅ **Charting**: Professional charts with analysis  
✅ **AI Predictions**: Bull/Bear predictions  
✅ **Technical Analysis**: SMC, Elliott Wave, Harmonic Patterns  
✅ **Sentiment Analysis**: Fear & Greed Index  
✅ **Portfolio Tracking**: Real-time P&L  
✅ **Signal Generation**: Automated signals  
✅ **Backtesting**: Strategy validation  

---

## Default URLs

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3001
- **Health Check**: http://localhost:3001/api/health
- **Market Data**: http://localhost:3001/api/market/prices?symbols=BTCUSDT,ETHUSDT

---

## Need Help?

1. **Check logs**: Look in `logs/` directory
2. **Console output**: Check terminal for errors
3. **Database**: Check `data/boltai.db` exists
4. **Dependencies**: Run `npm install` again

---

## Next Steps

1. ✅ Run `./start.sh` (or `start.bat` on Windows)
2. ✅ Open http://localhost:5173
3. ✅ Start using BOLT AI!

**That's it!** Everything is configured to work locally without any setup issues. 🎉
