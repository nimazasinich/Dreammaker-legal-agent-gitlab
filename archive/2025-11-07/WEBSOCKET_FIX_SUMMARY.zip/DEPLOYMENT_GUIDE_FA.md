# 🚀 راهنمای استقرار BOLT AI

## ⚠️ چرا Hugging Face Spaces مناسب نیست؟

این پروژه **نمی‌تواند** روی Hugging Face Spaces اجرا شود به دلایل زیر:

### مشکلات اصلی:
1. ❌ **بک‌اند Node.js**: Spaces عمدتاً برای Python/Streamlit/Gradio طراحی شده
2. ❌ **دو بک‌اند**: هم Node.js/Express و هم Python FastAPI دارید
3. ❌ **ذخیره‌سازی موقت**: SQLite داده‌ها را از دست می‌دهد
4. ❌ **WebSocket محدود**: پشتیبانی کامل از WebSocket ندارند
5. ❌ **Redis**: نیاز به سرویس خارجی دارید
6. ❌ **پردازش پس‌زمینه**: محدودیت در اجرای فرآیندهای طولانی

---

## ✅ گزینه‌های مناسب برای استقرار

### 1. 🚂 Railway.app (پیشنهاد اصلی)

**مزایا:**
- ✅ پشتیبانی کامل از Node.js و Python
- ✅ پایگاه داده PostgreSQL رایگان
- ✅ Redis داخلی
- ✅ SSL خودکار
- ✅ استقرار از Git
- ✅ 5 دلار اعتبار رایگان

**راه‌اندازی:**
```bash
# 1. نصب Railway CLI
npm i -g @railway/cli

# 2. لاگین
railway login

# 3. ایجاد پروژه
railway init

# 4. اضافه کردن PostgreSQL
railway add postgresql

# 5. اضافه کردن Redis
railway add redis

# 6. استقرار
railway up
```

**فایل تنظیمات:**
فایل `railway.json` را در ریشه پروژه ایجاد کنید.

---

### 2. 🌐 Render.com (رایگان)

**مزایا:**
- ✅ پلن رایگان
- ✅ پشتیبانی Node.js و Python
- ✅ PostgreSQL رایگان
- ✅ Redis رایگان
- ✅ Auto-deploy از Git

**راه‌اندازی:**
1. ثبت‌نام در [render.com](https://render.com)
2. اتصال به GitHub/GitLab
3. ایجاد Web Service برای بک‌اند Node.js
4. ایجاد Web Service برای بک‌اند Python
5. اضافه کردن PostgreSQL و Redis

**نکته:** Render.com در پلن رایگان ممکن است بعد از 15 دقیقه غیرفعال شود.

---

### 3. ✈️ Fly.io

**مزایا:**
- ✅ پشتیبانی کامل از Docker
- ✅ اجرای چندین سرویس
- ✅ پایگاه داده Postgres
- ✅ 3 ماشین مجازی رایگان

**راه‌اندازی:**
```bash
# 1. نصب Fly CLI
curl -L https://fly.io/install.sh | sh

# 2. لاگین
fly auth login

# 3. ایجاد پروژه
fly launch

# 4. استقرار
fly deploy
```

---

### 4. 💻 Vercel + Railway (هیبریدی)

**مزایا:**
- ✅ Frontend روی Vercel (بهینه)
- ✅ Backend روی Railway (قدرتمند)
- ✅ CDN خودکار
- ✅ پشتیبانی از Edge Functions

**راه‌اندازی:**
1. Frontend را در Vercel استقرار دهید
2. Backend را در Railway استقرار دهید
3. متغیرهای محیطی را تنظیم کنید

---

### 5. 🐳 Docker + Cloud Provider

**گزینه‌های Cloud:**
- AWS (EC2, ECS, Elastic Beanstalk)
- Google Cloud Platform (Cloud Run, Compute Engine)
- Azure (App Service, Container Instances)
- DigitalOcean (App Platform, Droplets)

---

## 📋 آماده‌سازی پروژه برای استقرار

### مرحله 1: ایجاد Dockerfile

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

# کپی package files
COPY package*.json ./

# نصب dependencies
RUN npm ci --only=production

# کپی کد
COPY . .

# Build
RUN npm run build

# Port
EXPOSE 3001

# Start
CMD ["npm", "start"]
```

### مرحله 2: تنظیم متغیرهای محیطی

```env
# .env.production
NODE_ENV=production
PORT=3001
DATABASE_URL=postgresql://...
REDIS_URL=redis://...
BINANCE_API_KEY=your_key
BINANCE_SECRET_KEY=your_secret
```

### مرحله 3: تنظیمات Railway

```json
// railway.json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS",
    "buildCommand": "npm install && npm run build"
  },
  "deploy": {
    "startCommand": "npm start",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}
```

---

## 🔧 تنظیمات پایگاه داده

### مهاجرت از SQLite به PostgreSQL

برای Railway یا Render نیاز به PostgreSQL دارید:

```typescript
// src/data/Database.ts
// تغییر از better-sqlite3 به pg یا Prisma
```

---

## 📊 مقایسه گزینه‌ها

| پلتفرم | هزینه | PostgreSQL | Redis | Node.js | Python | پشتیبانی |
|--------|-------|------------|-------|---------|--------|----------|
| Railway | 5$ رایگان | ✅ | ✅ | ✅ | ✅ | عالی |
| Render | رایگان | ✅ | ✅ | ✅ | ✅ | خوب |
| Fly.io | 3 VM رایگان | ✅ | ✅ | ✅ | ✅ | عالی |
| Vercel | رایگان | ❌ | ❌ | ✅ | ❌ | خوب |
| DigitalOcean | از 5$ | ✅ | ✅ | ✅ | ✅ | عالی |

---

## 🚀 پیشنهاد نهایی

**برای شروع سریع:** Railway.app
- نصب آسان
- پشتیبانی کامل
- پایگاه داده رایگان
- SSL خودکار

**برای استفاده رایگان:** Render.com
- پلن رایگان
- اما ممکن است بعد از 15 دقیقه sleep شود

**برای تولید (Production):** Railway + Vercel
- Frontend روی Vercel
- Backend روی Railway
- بهترین عملکرد

---

## 📝 مراحل بعدی

1. ✅ انتخاب پلتفرم
2. ✅ ایجاد Dockerfile (اختیاری)
3. ✅ تنظیم متغیرهای محیطی
4. ✅ مهاجرت به PostgreSQL (اگر نیاز باشد)
5. ✅ تست استقرار
6. ✅ تنظیم Domain و SSL

---

## 🆘 پشتیبانی

اگر مشکلی داشتید:
- مستندات Railway: https://docs.railway.app
- مستندات Render: https://render.com/docs
- مستندات Fly.io: https://fly.io/docs

---

**نکته مهم:** Hugging Face Spaces فقط برای دموهای ساده ML مناسب است. برای این پروژه از گزینه‌های بالا استفاده کنید.
