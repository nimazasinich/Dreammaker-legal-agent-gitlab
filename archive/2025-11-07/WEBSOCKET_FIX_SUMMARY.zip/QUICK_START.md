# ⚡ BOLT AI - Quick Start Guide

## 🚀 Get Started in 3 Minutes!

---

## ✅ Prerequisites

Before starting, make sure you have:
- [ ] **Node.js 18+** installed ([Download](https://nodejs.org/))
- [ ] **npm** (comes with Node.js)
- [ ] **Git** (optional, for cloning)

Check your versions:
```bash
node --version  # Should be v18.0.0 or higher
npm --version   # Should be 8.0.0 or higher
```

---

## 🎯 Quick Start (3 Simple Steps)

### Step 1: Install Dependencies
```bash
npm install
```
This will install all required packages. Takes about 2-3 minutes.

### Step 2: Start the Application
**Windows**:
```batch
start-fixed.bat
```

**Linux/Mac**:
```bash
chmod +x start-fixed.sh
./start-fixed.sh
```

### Step 3: Open Your Browser
The application will automatically open at:
```
http://localhost:5173
```

**That's it!** 🎉 You're ready to use BOLT AI!

---

## 🔧 Manual Start (Alternative)

If the automatic script doesn't work, follow these steps:

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Backend Server
Open a terminal and run:
```bash
npm run server
```
Keep this terminal open. You should see:
```
✅ Backend API running on http://localhost:3001
✅ WebSocket server running on ws://localhost:3001/ws
```

### 3. Start Frontend (in a new terminal)
Open a **new** terminal and run:
```bash
npm run dev
```
You should see:
```
  VITE v5.4.x  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

### 4. Open Browser
Navigate to:
```
http://localhost:5173
```

---

## 📱 Application Overview

### Main Pages (All Connected ✅)

1. **📊 Dashboard**
   - Overview of your portfolio
   - Key market statistics
   - Recent signals
   - System status

2. **📈 Charting**
   - Interactive price charts
   - Technical indicators
   - Drawing tools
   - Multiple timeframes

3. **💹 Market**
   - Live crypto prices
   - 24h changes
   - Trading volumes
   - Market analysis

4. **🔍 Scanner**
   - AI-powered signals
   - Technical pattern detection
   - Smart money analysis
   - News sentiment
   - Whale activity tracking

5. **🎓 Training**
   - AI model training
   - Training metrics
   - Learning progress
   - Model management

6. **⚠️ Risk**
   - Portfolio risk analysis
   - Stop-loss calculator
   - Position sizing
   - Risk/reward ratios

7. **🧪 Backtest**
   - Strategy testing
   - Trade simulation
   - Performance statistics
   - Parameter optimization

8. **🏥 Health**
   - API status
   - WebSocket connection
   - Resource usage
   - System logs

9. **⚙️ Settings**
   - API keys configuration
   - Display preferences
   - Notifications
   - Advanced settings

---

## 🎮 First Steps

### 1. Check System Health
- Click on **Health** tab
- Verify all systems are "Connected" ✅
- Check for any errors

### 2. Configure API Keys (Optional)
- Go to **Settings** tab
- Enter your Binance API keys (for live trading)
- Or use sample data for testing

### 3. Explore the Scanner
- Click on **Scanner** tab
- View AI-generated signals
- Explore different scanner types:
  - AI Signals
  - Technical Patterns
  - Smart Money
  - News Sentiment
  - Whale Activity

### 4. View Charts
- Click on **Charting** tab
- Select a cryptocurrency
- Choose timeframe
- Analyze with technical indicators

---

## 🐛 Troubleshooting

### Backend Won't Start

**Error**: `Port 3001 is already in use`

**Solution**:
```bash
# Windows
netstat -ano | findstr :3001
# Kill the process using the PID shown

# Linux/Mac
lsof -i :3001
kill -9 <PID>
```

Then restart:
```bash
npm run server
```

### Frontend Won't Connect

**Error**: `Failed to fetch` or `Network Error`

**Solutions**:
1. Make sure backend is running on port 3001
2. Check `.env` file exists with:
   ```
   VITE_API_URL=http://localhost:3001/api
   VITE_WS_URL=ws://localhost:3001/ws
   ```
3. Clear browser cache (Ctrl+F5)
4. Restart both backend and frontend

### Charts Not Loading

**Solutions**:
1. Check browser console (Press F12)
2. Verify market data is loading
3. Refresh the page (Ctrl+F5)
4. Restart backend server

### Installation Errors

**Error**: `npm install` fails

**Solutions**:
1. Clear npm cache:
   ```bash
   npm cache clean --force
   ```

2. Delete and reinstall:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

3. Use Node.js LTS version (18.x)

---

## 📊 System Requirements

### Minimum:
- **OS**: Windows 10, Linux (Ubuntu 20.04+), macOS 11+
- **CPU**: 2 cores, 2.0 GHz
- **RAM**: 4 GB
- **Disk**: 2 GB free space
- **Browser**: Chrome 90+, Firefox 90+, Edge 90+

### Recommended:
- **OS**: Windows 11, Linux (Ubuntu 22.04+), macOS 12+
- **CPU**: 4 cores, 3.0 GHz
- **RAM**: 8 GB
- **Disk**: 5 GB free space (SSD preferred)
- **Browser**: Latest Chrome or Edge

---

## 🔐 Security Notes

### API Keys:
- **Never** share your API keys
- Use **testnet** keys for testing
- Enable **IP whitelist** on Binance
- Use **read-only** keys when possible

### Best Practices:
- Keep the application updated
- Use strong passwords
- Enable 2FA on your Binance account
- Regular backups of settings

---

## 📚 Learning Resources

### For Beginners:
1. Start with the **Dashboard** to get familiar
2. Explore the **Scanner** to see AI signals
3. Use the **Charting** page for technical analysis
4. Read the full documentation: `README_FIXES_FA.md` (Persian) or `FIXES_APPLIED_DETAILED.md` (English)

### For Advanced Users:
1. Configure custom strategies in **Settings**
2. Run backtests with your strategies
3. Train custom AI models in **Training**
4. Integrate with Telegram for alerts

---

## 🎯 Quick Tips

### 1. Use Keyboard Shortcuts
- `Ctrl+R`: Refresh data
- `Ctrl+S`: Save settings
- `Esc`: Close modals
- Arrow keys: Navigate charts

### 2. Optimize Performance
- Close unused browser tabs
- Use Chrome/Edge for best performance
- Enable hardware acceleration
- Keep only necessary views open

### 3. Stay Safe
- **Never** invest more than you can afford to lose
- **Always** use stop-loss orders
- **Diversify** your portfolio
- **Research** before trading

---

## ✅ Success Checklist

After starting the application, verify:

- [ ] Backend running on http://localhost:3001
- [ ] Frontend running on http://localhost:5173
- [ ] All 9 pages accessible from sidebar
- [ ] Market data loading correctly
- [ ] Charts displaying properly
- [ ] WebSocket connected (check Health page)
- [ ] No errors in browser console (F12)

If all checked, you're good to go! ✅

---

## 🆘 Need Help?

### Quick Fixes:
1. **Restart everything**: Close terminals, restart scripts
2. **Clear cache**: Browser cache + npm cache
3. **Check ports**: Make sure 3001 and 5173 are free
4. **Update Node**: Use Node.js 18 LTS

### Documentation:
- **Persian**: `README_FIXES_FA.md` - راهنمای فارسی کامل
- **English**: `FIXES_APPLIED_DETAILED.md` - Detailed technical documentation
- **API Docs**: `API_KEYS_SETUP_GUIDE.md` - API configuration guide

---

## 🎉 You're All Set!

Congratulations! You now have a fully functional AI-powered cryptocurrency trading system.

**What's Next?**
1. Explore all 9 pages
2. Configure your preferences in Settings
3. Watch AI-generated signals in Scanner
4. Analyze charts with technical indicators
5. Test strategies with Backtesting

**Happy Trading! 🚀📈**

---

**Version**: 1.0.1  
**Status**: Production Ready ✅  
**Support**: Check documentation files for help
