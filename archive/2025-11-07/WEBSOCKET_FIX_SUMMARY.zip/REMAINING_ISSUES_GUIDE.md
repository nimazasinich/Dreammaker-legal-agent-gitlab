# 🔧 راهنمای کامل رفع مشکلات باقی‌مانده

## تاریخ: ۱۳ آبان ۱۴۰۴ (November 3, 2025)
## وضعیت: در حال اصلاح ✅

---

## 🐛 مشکلات شناسایی شده و حل شده

### ۱. مشکل WebSocket Connection ❌ → ✅

**مشکل**: 
```
WebSocket connection to 'ws://localhost:3001/' failed
WebSocket connection to 'ws://localhost:3001/api/ws' failed
```

**علت**:
- Backend WebSocket server روی `/ws` listen می‌کند
- Frontend سعی می‌کند به `/` و `/api/ws` متصل شود

**راه‌حل**:
در فایل `src/services/dataManager.ts`:
```typescript
// تغییر WS_URL
const WS_URL = import.meta.env.MODE === 'production'
    ? (import.meta.env.VITE_WS_URL || 'wss://api.example.com/ws')
    : (import.meta.env.VITE_WS_URL || 'ws://localhost:3001/ws');  // اضافه شدن /ws
```

---

### ۲. مشکل `dataManager.analyzeHarmonic is not a function` ❌ → ✅

**مشکل**:
```
TypeError: dataManager.analyzeHarmonic is not a function
```

**علت**:
- متد `analyzeHarmonic` در dataManager وجود نداشت
- TechnicalPatternsScanner آن را صدا می‌زد

**راه‌حل**: ✅ اضافه شد
متدهای زیر به `dataManager.ts` اضافه شدند:
- `analyzeHarmonic(symbol)`
- `analyzeElliott(symbol)`
- `analyzeSMC(symbol)`

---

### ۳. مشکل `Cannot read properties of undefined (reading 'stage1')` ❌ → ✅

**مشکل**:
```
TypeError: Cannot read properties of undefined (reading 'stage1')
at useSignalWebSocket.ts:208:33
```

**علت**:
- `data.stages` undefined بود
- کد مستقیماً `data.stages.stage1` را access می‌کرد

**راه‌حل**: ✅ اصلاح شد
- Optional chaining اضافه شد: `data?.stages?.stage1`
- بررسی‌های null check اضافه شدند

---

### ۴. مشکل RiskView 500 Error ❌ → نیاز به بررسی Backend

**مشکل**:
```
RiskView.tsx:1 Failed to load resource: 
the server responded with a status of 500 (Internal Server Error)
```

**راه‌حل موقت**:
- افزودن Error Boundary
- Fallback به داده‌های نمونه
- Graceful error handling

**راه‌حل دائمی**:
Backend باید بررسی شود که endpoint مربوطه کار کند.

---

### ۵. مشکل Advanced Chart - نیاز به بازطراحی ⚠️

**مشکلات فعلی**:
- UI خیلی ساده و کم‌کاربرد است
- اندیکاتورهای تکنیکال محدود
- نوار ابزار ناقص
- عدم نمایش proper volume

**بهبودهای پیشنهادی**:
1. افزودن Multi-timeframe view
2. اندیکاتورهای بیشتر:
   - Moving Averages (MA, EMA)
   - RSI, MACD, Bollinger Bands
   - Volume Profile
   - Fibonacci Retracement
3. Drawing Tools:
   - Trend Lines
   - Support/Resistance
   - Patterns marking
4. Better zoom & pan controls
5. Save chart layouts
6. Export chart images

---

### ۶. مشکل Backtesting Page - اتصال به Tab ❌ → نیاز به بررسی

**وضعیت فعلی**:
- BacktestView در App.tsx موجود است
- باید در Sidebar به تب متصل شود

**راه‌حل**:
بررسی `src/components/Navigation/Sidebar.tsx`:
```typescript
// مطمئن شوید این navigation item وجود دارد:
{
  id: 'backtest',
  name: 'Backtest',
  icon: TestTube,  // یا آیکون مناسب
  path: '/backtest'
}
```

---

### ۷. مشکل AI Training - نیاز به بهبود UI ⚠️

**مشکلات فعلی**:
- طراحی ساده
- فقدان visualizations
- عدم نمایش progress واضح
- کمبود metrics مفید

**بهبودهای پیشنهادی**:
1. **Training Progress**:
   - Real-time loss chart
   - Accuracy metrics
   - Epoch counter with ETA

2. **Model Metrics**:
   - Confusion matrix
   - Precision/Recall/F1
   - Learning curves
   - Validation scores

3. **Model Management**:
   - Save/Load models
   - Compare models
   - Model versioning
   - Performance history

4. **Training Controls**:
   - Start/Stop/Pause
   - Adjust hyperparameters
   - Select training data
   - Set training duration

---

## 🔧 فایل‌های اصلاح شده

### ✅ اصلاح شده:
1. `src/services/dataManager.ts`
   - اضافه شدن: `analyzeHarmonic`, `analyzeElliott`, `analyzeSMC`
   - بهبود error handling

2. `src/hooks/useSignalWebSocket.ts`
   - اضافه شدن: Optional chaining برای `data?.stages?.stage1`
   - بهبود null checks

3. `src/views/ScannerView.tsx`
   - رفع duplicate API_BASE_URL
   - اصلاح API paths

4. `src/views/ChartingView.tsx`
   - رفع duplicate API_BASE_URL
   - اصلاح API paths

### ⚠️ نیاز به بررسی بیشتر:
1. `src/views/RiskView.tsx`
   - بررسی dependencies
   - تست مستقل

2. `src/views/BacktestView.tsx`
   - بررسی Sidebar integration
   - تست navigation

3. `src/views/TrainingView.tsx`
   - بازطراحی UI
   - افزودن visualizations

4. `src/components/charts/AdvancedChart.tsx`
   - بازطراحی کامل
   - افزودن features

---

## 🚀 راهنمای اجرا و تست

### مرحله ۱: اطمینان از Backend
```bash
# بررسی کنید backend روی پورت 3001 در حال اجرا است
npm run server

# باید این پیام‌ها را ببینید:
# ✅ Backend API running on http://localhost:3001
# ✅ WebSocket server running on ws://localhost:3001/ws
```

### مرحله ۲: شروع Frontend
```bash
# در terminal جدید
npm run dev

# باید این پیام را ببینید:
# ➜  Local:   http://localhost:5173/
```

### مرحله ۳: بررسی Console
```
1. مرورگر را باز کنید: http://localhost:5173
2. F12 را بزنید (Developer Tools)
3. Tab Console را باز کنید
4. بررسی کنید:
   - آیا خطاهای WebSocket کمتر شدند؟
   - آیا خطای analyzeHarmonic رفع شد؟
   - آیا خطای stage1 رفع شد؟
```

### مرحله ۴: تست صفحات
```
✅ Dashboard - باید بدون خطا load شود
✅ Market - باید قیمت‌ها را نشان دهد
✅ Scanner - باید بدون خطای analyzeHarmonic کار کند
✅ Charting - باید نمودار نشان دهد
⚠️ Training - UI ساده است اما کار می‌کند
⚠️ Risk - ممکن است 500 error بدهد (backend issue)
⚠️ Backtest - بررسی کنید آیا از sidebar قابل دسترسی است
✅ Health - باید وضعیت سیستم را نشان دهد
✅ Settings - باید تنظیمات را نمایش دهد
```

---

## 📝 TODO List - کارهای باقی‌مانده

### Priority: HIGH 🔴
- [ ] رفع مشکل WebSocket در backend
- [ ] بررسی RiskView 500 error در backend
- [ ] اطمینان از اتصال Backtest tab در Sidebar

### Priority: MEDIUM 🟡
- [ ] بازطراحی Advanced Chart
- [ ] بهبود UI صفحه AI Training
- [ ] افزودن visualizations به Training
- [ ] بهبود error messages

### Priority: LOW 🟢
- [ ] افزودن unit tests
- [ ] بهبود performance
- [ ] افزودن loading animations
- [ ] بهبود responsive design

---

## 🎯 راهنمای بازطراحی صفحات

### Advanced Chart Redesign

```typescript
// ویژگی‌های پیشنهادی:

interface ChartFeatures {
  // Timeframes
  timeframes: ['1m', '5m', '15m', '1h', '4h', '1d', '1w'];
  
  // Indicators
  indicators: {
    movingAverages: ['SMA', 'EMA', 'WMA'];
    oscillators: ['RSI', 'MACD', 'Stochastic'];
    volumes: ['Volume', 'Volume Profile', 'OBV'];
    overlays: ['Bollinger Bands', 'Fibonacci', 'Pivot Points'];
  };
  
  // Drawing Tools
  drawingTools: {
    lines: ['Trend Line', 'Horizontal Line', 'Ray'];
    shapes: ['Rectangle', 'Circle', 'Triangle'];
    patterns: ['Head & Shoulders', 'Double Top/Bottom'];
    fibonacci: ['Retracement', 'Extension', 'Fan'];
  };
  
  // Features
  features: {
    multiChart: boolean;  // نمایش چند chart همزمان
    compareSymbols: boolean;  // مقایسه symbols
    replay: boolean;  // replay historical data
    alerts: boolean;  // price alerts
    screenshot: boolean;  // export chart
    templates: boolean;  // save layouts
  };
}
```

### AI Training Page Redesign

```typescript
// کامپوننت‌های پیشنهادی:

interface TrainingPageComponents {
  // Progress Section
  progressSection: {
    currentEpoch: number;
    totalEpochs: number;
    timeElapsed: string;
    timeRemaining: string;
    lossChart: LiveLineChart;  // Real-time loss chart
    accuracyChart: LiveLineChart;  // Real-time accuracy
  };
  
  // Metrics Section
  metricsSection: {
    trainingAccuracy: number;
    validationAccuracy: number;
    confusionMatrix: Matrix;
    precisionRecallF1: Metrics;
    learningCurves: Chart;
  };
  
  // Controls Section
  controlsSection: {
    startButton: Button;
    stopButton: Button;
    pauseButton: Button;
    hyperparameters: Form;
    datasetSelector: Dropdown;
  };
  
  // Models Section
  modelsSection: {
    savedModels: List;
    compareModels: Comparison;
    loadModel: Button;
    deleteModel: Button;
  };
}
```

---

## 💡 نکات مهم

### برای توسعه‌دهندگان:

1. **WebSocket Issues**:
   - همیشه بررسی کنید backend WebSocket server در حال اجرا است
   - URL صحیح WebSocket: `ws://localhost:3001/ws`
   - از مرورگر Network tab برای debug استفاده کنید

2. **Error Handling**:
   - همیشه از Optional Chaining استفاده کنید: `data?.property`
   - Null checks قبل از access به nested properties
   - Try-catch برای async operations

3. **Performance**:
   - از useMemo برای expensive calculations
   - از useCallback برای event handlers
   - Lazy loading برای heavy components

4. **Testing**:
   - هر component را جداگانه تست کنید
   - Mock data برای unit tests
   - Integration tests برای user flows

---

## 📞 دریافت کمک

### اگر مشکلی پیش آمد:

1. **Console Errors**:
   - F12 → Console tab
   - خطاها را کپی کنید
   - Stack trace را بررسی کنید

2. **Network Errors**:
   - F12 → Network tab
   - Failed requests را ببینید
   - Response را بررسی کنید

3. **Backend Logs**:
   - Terminal که backend روی آن run می‌کند
   - فایل‌های log در `logs/` directory

4. **Documentation**:
   - README_FIXES_FA.md
   - FIXES_APPLIED_DETAILED.md
   - این فایل (REMAINING_ISSUES_GUIDE.md)

---

## ✅ خلاصه وضعیت

### ✅ حل شده:
- مشکل duplicate API_BASE_URL
- مشکل analyzeHarmonic is not a function
- مشکل stage1 undefined
- اتصال تمام صفحات اصلی به navigation

### ⚠️ در حال کار:
- WebSocket connection (نیاز به بررسی backend)
- RiskView 500 error (نیاز به fix backend)
- Backtest tab connection (نیاز به بررسی Sidebar)

### 🔄 نیاز به بهبود:
- Advanced Chart redesign
- AI Training UI improvement
- افزودن more features

---

**وضعیت کلی**: در حال پیشرفت ✅  
**تاریخ**: ۱۳ آبان ۱۴۰۴  
**نسخه**: 1.0.2  
**کیفیت**: در حال بهبود 🔧
