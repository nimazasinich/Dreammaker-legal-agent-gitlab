import { MemoryDatabase } from './MemoryDatabase';

export class Database {
  private static instance: Database;
  private db: MemoryDatabase;

  private constructor() {
    this.db = new MemoryDatabase();
    console.log('Database initialized with memory storage');
  }

  static getInstance(): Database {
    if (!Database.instance) {
      Database.instance = new Database();
    }
    return Database.instance;
  }

  async initialize(): Promise<void> {
    // Memory database doesn't need async initialization
    console.log('Database initialization complete');
    return Promise.resolve();
  }

  prepare(query: string) {
    return this.db.prepare(query);
  }

  exec(query: string) {
    return this.db.exec(query);
  }

  close() {
    return this.db.close();
  }

  insert(table: string, data: any) {
    return this.db.insert(table, data);
  }

  select(table: string, where?: any) {
    return this.db.select(table, where);
  }

  update(table: string, data: any, where?: any) {
    return this.db.update(table, data, where);
  }

  delete(table: string, where?: any) {
    return this.db.delete(table, where);
  }
}

export default Database.getInstance();
