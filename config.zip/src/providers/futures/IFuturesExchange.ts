/**
 * Futures Exchange Interface
 * Provider-agnostic interface for futures trading operations
 */
import {
  FuturesPosition,
  FuturesOrder,
  LeverageSettings,
  FundingRate,
  FuturesAccountBalance,
  FuturesOrderbook
} from '../../types/futures.js';

export interface IFuturesExchange {
  /**
   * Get all open positions
   */
  getPositions(): Promise<FuturesPosition[]>;

  /**
   * Place a futures order
   */
  placeOrder(order: FuturesOrder): Promise<any>;

  /**
   * Cancel an order by ID
   */
  cancelOrder(orderId: string): Promise<any>;

  /**
   * Cancel all orders (optionally filtered by symbol)
   */
  cancelAllOrders(symbol?: string): Promise<any>;

  /**
   * Get open orders (optionally filtered by symbol)
   */
  getOpenOrders(symbol?: string): Promise<any[]>;

  /**
   * Set leverage for a symbol
   */
  setLeverage(symbol: string, leverage: number, marginMode?: string): Promise<any>;

  /**
   * Get account balance and equity
   */
  getAccountBalance(): Promise<FuturesAccountBalance>;

  /**
   * Get orderbook for a symbol
   */
  getOrderbook(symbol: string, depth?: number): Promise<FuturesOrderbook>;

  /**
   * Get funding rate for a symbol
   */
  getFundingRate(symbol: string): Promise<FundingRate>;

  /**
   * Get funding rate history
   */
  getFundingRateHistory(symbol: string, startTime?: number, endTime?: number, limit?: number): Promise<FundingRate[]>;
}
