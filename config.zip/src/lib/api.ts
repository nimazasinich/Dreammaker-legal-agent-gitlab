// Import centralized API configuration
// API_BASE should NOT include /api suffix - routes already have /api/ prefix
// Example: API_BASE='http://localhost:8000' + path='/api/health' = 'http://localhost:8000/api/health'
import { API_BASE } from '@/config/env';
export { API_BASE };

export async function apiGet<T = unknown>(
  path: string,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(`${API_BASE}/${path}`, init);
  if (!res.ok) console.error(`${res.status} ${res.statusText}`);
  return res.json() as Promise<T>;
}

export async function apiPost<T = unknown>(
  path: string,
  body?: unknown,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(`${API_BASE}/${path}`, {
    ...init,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...init?.headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) console.error(`${res.status} ${res.statusText}`);
  return res.json() as Promise<T>;
}

export async function apiPut<T = unknown>(
  path: string,
  body?: unknown,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(`${API_BASE}/${path}`, {
    ...init,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...init?.headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) console.error(`${res.status} ${res.statusText}`);
  return res.json() as Promise<T>;
}

export async function apiDelete<T = unknown>(
  path: string,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(`${API_BASE}/${path}`, {
    ...init,
    method: 'DELETE',
  });
  if (!res.ok) console.error(`${res.status} ${res.statusText}`);
  return res.json() as Promise<T>;
}

