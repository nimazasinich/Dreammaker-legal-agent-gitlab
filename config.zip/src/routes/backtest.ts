import { Router, Request, Response } from 'express';
import { Logger } from '../core/Logger.js';
import fetch from 'node-fetch';
import { runStrategyPipeline } from '../engine/pipeline.js';
import { Bar } from '../types/signals.js';

const router = Router();
const logger = Logger.getInstance();

async function loadOHLC(symbol: string, timeframe: string, limit: number): Promise<Bar[]> {
  // Prefer internal service if present; otherwise loopback to existing HF route:
  const port = process.env.PORT || '8000';
  const base = process.env.API_BASE || `http://localhost:${port}/api`;
  const url = `${base}/hf/ohlcv?symbol=${encodeURIComponent(symbol)}&timeframe=${encodeURIComponent(timeframe)}&limit=${limit}`;
  const r = await fetch(url, { mode: "cors", headers: { "Content-Type": "application/json" } });
  if (!r.ok) console.error(`ohlc_fetch_${r.status}`);
  const json: any = await r.json();
  return json?.data || json; // harmonize
}

function computeBacktestMetrics(bars: Bar[], decision: any) {
  // Simple backtest simulation: buy on 'buy' signal, sell on 'sell' signal
  // This is a placeholder - extend with proper backtest logic
  const trades: any[] = [];
  let position: 'long' | 'short' | null = null;
  let entryPrice = 0;
  let pnl = 0;
  let wins = 0;
  let losses = 0;

  const action = decision?.action || 'hold';
  const score = decision?.finalScore || 0;

  // Very simple logic: if score > 0.6 buy, if score < 0.4 sell
  if (score > 0.6 && !position) {
    position = 'long';
    entryPrice = bars[bars.length - 1]?.close || 0;
  } else if (score < 0.4 && position === 'long') {
    const exitPrice = bars[bars.length - 1]?.close || 0;
    const tradePnl = exitPrice - entryPrice;
    pnl += tradePnl;
    if (tradePnl > 0) wins++; else losses++;
    position = null;
  }

  const totalTrades = wins + losses;
  const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;

  // Placeholder metrics
  return {
    winRate,
    pnl,
    maxDD: 0, // compute from equity curve in real implementation
    sharpe: 0, // compute from returns in real implementation
    totalTrades,
    wins,
    losses,
    finalScore: score,
    action
  };
}

router.post('/backtest/run', async (req: Request, res: Response) => {
  try {
    const { symbol = 'BTCUSDT', timeframe = '1h', limit = 500 } = req.body || {};
    const bars = await loadOHLC(symbol, timeframe, Math.max(200, limit));
    const decision = await runStrategyPipeline(bars, symbol);
    const metrics = computeBacktestMetrics(bars, decision);
    return res.json({ ok: true, symbol, timeframe, metrics });
  } catch (e: any) {
    logger.warn('backtest_run_error', { e: e?.message });
    return res.status(500).json({ error: e?.message || 'backtest_failed' });
  }
});

export default router;
