/**
 * Futures Routes
 * Express routes for futures trading endpoints
 */
import { Router } from 'express';
import { FuturesController } from '../controllers/FuturesController.js';
import { FEATURE_FUTURES } from '../config/flags.js';

const router = Router();
const futuresController = new FuturesController();

// Middleware to check feature flag
router.use((req, res, next) => {
  if (!FEATURE_FUTURES) {
    res.status(404).json({
      error: 'Futures trading is disabled',
      message: 'Set FEATURE_FUTURES=true to enable futures trading'
    });
    return;
  }
  next();
});

// Positions
router.get('/positions', (req, res) => futuresController.getPositions(req, res));

// Orders
router.post('/orders', (req, res) => futuresController.placeOrder(req, res));
router.get('/orders', (req, res) => futuresController.getOpenOrders(req, res));
router.delete('/orders/:id', (req, res) => futuresController.cancelOrder(req, res));
router.delete('/orders', (req, res) => futuresController.cancelAllOrders(req, res));

// Leverage
router.put('/leverage', (req, res) => futuresController.setLeverage(req, res));

// Account
router.get('/account/balance', (req, res) => futuresController.getAccountBalance(req, res));

// Market Data
router.get('/orderbook/:symbol', (req, res) => futuresController.getOrderbook(req, res));

// Funding Rates
router.get('/funding/:symbol', (req, res) => futuresController.getFundingRate(req, res));
router.get('/funding/:symbol/history', (req, res) => futuresController.getFundingRateHistory(req, res));

// Position Management
router.delete('/positions/:symbol', (req, res) => futuresController.closePosition(req, res));

export default router;
