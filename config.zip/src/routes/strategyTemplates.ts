import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

const router = Router();
const TEMPLATES_DIR = path.join(process.cwd(), 'config', 'templates');
if (!fs.existsSync(TEMPLATES_DIR)) fs.mkdirSync(TEMPLATES_DIR, { recursive: true });

const listTemplates = () =>
  fs.readdirSync(TEMPLATES_DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => ({ id: path.basename(f, '.json'), file: f }));

router.get('/strategy/templates', (_: Request, res: Response) => {
  const list = listTemplates();
  return res.json({ templates: list });
});

router.get('/strategy/templates/:id', (req: Request, res: Response) => {
  const file = path.join(TEMPLATES_DIR, `${req.params.id}.json`);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'template_not_found' });
  const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  return res.json({ template: data });
});

router.post('/strategy/templates', (req: Request, res: Response) => {
  try {
    const { id, template } = req.body || {};
    if (!id || !template) return res.status(400).json({ error: 'id_and_template_required' });
    const file = path.join(TEMPLATES_DIR, `${id}.json`);
    fs.writeFileSync(file, JSON.stringify(template, null, 2));
    return res.json({ ok: true, id });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'write_failed' });
  }
});

router.delete('/strategy/templates/:id', (req: Request, res: Response) => {
  const file = path.join(TEMPLATES_DIR, `${req.params.id}.json`);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'template_not_found' });
  fs.unlinkSync(file);
  return res.json({ ok: true });
});

export default router;
