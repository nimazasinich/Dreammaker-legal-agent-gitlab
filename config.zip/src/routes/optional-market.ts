/**
 * Optional Market Data Routes
 * Test routes for CoinMarketCap and CryptoCompare services
 * These are OPTIONAL alternative market data sources
 */
import { Router } from "express";
import { CoinMarketCapService } from "../services/optional/CoinMarketCapService.js";
import { CryptoCompareService } from "../services/optional/CryptoCompareService.js";

export const optionalMarketRouter = Router();

// CoinMarketCap endpoints
optionalMarketRouter.get("/cmc/listings", async (req, res) => {
  try {
    const limit = Number(req.query.limit || 10);
    const convert = String(req.query.convert || "USD");
    const data = await CoinMarketCapService.listings(limit, convert);

    res.json({
      ok: true,
      count: data.length,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "CMC listings failed"
    });
  }
});

optionalMarketRouter.get("/cmc/quote", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "BTC");
    const convert = String(req.query.convert || "USD");
    const data = await CoinMarketCapService.quote(symbol, convert);

    res.json({
      ok: true,
      symbol,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "CMC quote failed"
    });
  }
});

optionalMarketRouter.get("/cmc/info", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "BTC");
    const data = await CoinMarketCapService.info(symbol);

    res.json({
      ok: true,
      symbol,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "CMC info failed"
    });
  }
});

// CryptoCompare endpoints
optionalMarketRouter.get("/cc/pricemulti", async (req, res) => {
  try {
    const fsyms = String(req.query.fsyms || "BTC,ETH");
    const tsyms = String(req.query.tsyms || "USD");
    const data = await CryptoCompareService.priceMulti(fsyms, tsyms);

    res.json({
      ok: true,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "CryptoCompare priceMulti failed"
    });
  }
});

optionalMarketRouter.get("/cc/histohour", async (req, res) => {
  try {
    const fsym = String(req.query.fsym || "BTC");
    const tsym = String(req.query.tsym || "USD");
    const limit = Number(req.query.limit || 168);
    const data = await CryptoCompareService.histoHour(fsym, tsym, limit);

    res.json({
      ok: true,
      count: data.length,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "CryptoCompare histoHour failed"
    });
  }
});
