import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

const router = Router();
const CFG_DIR = path.join(process.cwd(), 'config');

function normalizeWeights(weights: Record<string, number>) {
  const sum = Object.values(weights).reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0);
  if (sum <= 0) return weights;
  const norm: Record<string, number> = {};
  for (const k of Object.keys(weights)) norm[k] = Number(weights[k]) / sum;
  return norm;
}

router.post('/strategy/apply', (req: Request, res: Response) => {
  try {
    const { template } = req.body || {};
    if (!template) return res.status(400).json({ error: 'template_required' });

    // 1) Apply scoring weights
    const scoringPath = path.join(CFG_DIR, 'scoring.config.json');
    const scoring = fs.existsSync(scoringPath) ? JSON.parse(fs.readFileSync(scoringPath, 'utf-8')) : { weights: {} };
    scoring.weights = normalizeWeights({ ...(scoring.weights || {}), ...(template.weights || {}) });
    fs.writeFileSync(scoringPath, JSON.stringify(scoring, null, 2));

    // 2) Apply strategy config (thresholds, timeframes, confluence, risk)
    const strategyPath = path.join(CFG_DIR, 'strategy.config.json');
    const strategyCfg = fs.existsSync(strategyPath) ? JSON.parse(fs.readFileSync(strategyPath, 'utf-8')) : {};
    const applied = {
      ...strategyCfg,
      ...(template.strategy || {}),
      timeframes: template.timeframes || strategyCfg.timeframes || ['1h'],
      thresholds: { ...(strategyCfg.thresholds || {}), ...(template.thresholds || {}) },
      confluence: template.confluence ?? strategyCfg.confluence ?? 0.6,
      risk: { ...(strategyCfg.risk || {}), ...(template.risk || {}) },
    };
    fs.writeFileSync(strategyPath, JSON.stringify(applied, null, 2));

    return res.json({ ok: true, scoring, strategy: applied });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'apply_failed' });
  }
});

export default router;
