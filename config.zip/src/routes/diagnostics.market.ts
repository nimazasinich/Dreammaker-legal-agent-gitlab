import { Router, Request, Response } from 'express';
import fetch from 'node-fetch';

const router = Router();

// GET /api/diagnostics/market?symbol=BTCUSDT&tf=1h
router.get('/diagnostics/market', async (req: Request, res: Response) => {
  const symbol = String(req.query.symbol || 'BTCUSDT').toUpperCase();
  const tf = String(req.query.tf || '1h');
  const port = process.env.PORT || '8000';
  const apiBase = process.env.API_BASE || `http://localhost:${port}/api`;

  const results: Record<string, any> = {
    symbol,
    timeframe: tf,
    providers: {},
  };

  // Check HuggingFace OHLCV endpoint
  try {
    const r1 = await fetch(
      `${apiBase}/hf/ohlcv?symbol=${symbol}&timeframe=${tf}&limit=50`,
      { signal: AbortSignal.timeout(3000) }
    );
    results.providers.huggingface = {
      status: r1.status,
      ok: r1.ok,
      endpoint: '/api/hf/ohlcv',
    };
  } catch (e: any) {
    results.providers.huggingface = {
      status: 'error',
      error: e?.message || 'fetch_failed',
      endpoint: '/api/hf/ohlcv',
    };
  }

  // Check OHLCV readiness
  try {
    const r2 = await fetch(
      `${apiBase}/market/ohlcv/ready?symbol=${symbol}&tf=${tf}&min=50`,
      { method: 'HEAD', signal: AbortSignal.timeout(3000) }
    );
    results.providers.readiness = {
      status: r2.status,
      ok: r2.ok,
      endpoint: '/api/market/ohlcv/ready',
    };
  } catch (e: any) {
    results.providers.readiness = {
      status: 'error',
      error: e?.message || 'fetch_failed',
      endpoint: '/api/market/ohlcv/ready',
    };
  }

  // Check news proxy
  try {
    const r3 = await fetch(
      `${apiBase}/proxy/news?query=bitcoin&page_size=3`,
      { signal: AbortSignal.timeout(3000) }
    );
    results.providers.news = {
      status: r3.status,
      ok: r3.ok,
      endpoint: 'news',
    };
  } catch (e: any) {
    results.providers.news = {
      status: 'error',
      error: e?.message || 'fetch_failed',
      endpoint: 'news',
    };
  }

  // Check fear & greed proxy
  try {
    const r4 = await fetch(`${apiBase}/proxy/fear-greed`, {
      signal: AbortSignal.timeout(3000),
    });
    results.providers.fearGreed = {
      status: r4.status,
      ok: r4.ok,
      endpoint: 'fear-greed',
    };
  } catch (e: any) {
    results.providers.fearGreed = {
      status: 'error',
      error: e?.message || 'fetch_failed',
      endpoint: 'fear-greed',
    };
  }

  // Overall health
  const allOk = Object.values(results.providers).every(
    (p: any) => p.ok === true || p.status === 200
  );
  results.overall = allOk ? 'healthy' : 'degraded';

  return res.json(results);
});

export default router;
