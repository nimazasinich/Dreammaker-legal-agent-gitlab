/**
 * System Diagnostics Routes
 * Express routes for connectivity diagnostics and self-healing
 */

import { Router, Request, Response } from 'express';
import { runConnectivityDoctor, autoRemediate } from '../tools/ConnectivityDoctor.js';
import { Logger } from '../core/Logger.js';
import axios from 'axios';
import dns from 'dns';
import https from 'https';

const router = Router();
const logger = Logger.getInstance();

/**
 * Run connectivity diagnostics
 * GET /api/system/diagnostics/run
 */
router.get('/run', async (_req: Request, res: Response) => {
  try {
    logger.info('Running connectivity diagnostics');

    const report = await runConnectivityDoctor();

    res.json({
      success: true,
      report,
    });
  } catch (e: any) {
    logger.error('Diagnostics failed', {}, e);
    res.status(500).json({
      success: false,
      error: e?.message || 'diagnostics_failed',
      message: 'Failed to run connectivity diagnostics',
    });
  }
});

/**
 * Run diagnostics with automatic remediation suggestions
 * GET /api/system/diagnostics/remediate
 */
router.get('/remediate', async (_req: Request, res: Response) => {
  try {
    logger.info('Running connectivity diagnostics with remediation');

    const report = await runConnectivityDoctor();
    const actions = await autoRemediate(report);

    res.json({
      success: true,
      report,
      remediation: {
        actions,
        canAutoFix: false, // Manual action required
        instructions:
          'Review the suggested actions and apply them to your environment configuration',
      },
    });
  } catch (e: any) {
    logger.error('Remediation diagnostics failed', {}, e);
    res.status(500).json({
      success: false,
      error: e?.message || 'remediation_failed',
      message: 'Failed to run remediation diagnostics',
    });
  }
});

/**
 * Network connectivity check - Test critical external API endpoints
 * GET /api/system/diagnostics/netcheck
 */
router.get('/netcheck', async (_req: Request, res: Response) => {
  try {
    logger.info('Running network connectivity check');

    const probes = [
      { name: 'Binance', url: 'https://api.binance.com/api/v3/ping' },
      { name: 'Kraken', url: 'https://api.kraken.com/0/public/Time' },
      { name: 'Bitfinex', url: 'https://api-pub.bitfinex.com/v2/platform/status' },
      { name: 'Fear & Greed', url: 'https://api.alternative.me/fng/' },
      { name: 'NewsAPI', url: 'https://newsapi.org/v2/top-headlines?country=us' }
    ];

    const results = await Promise.allSettled(
      (probes || []).map(async ({ name, url }) => {
        const t0 = Date.now();
        try {
          const response = await axios.get(url, {
            validateStatus: () => true,
            timeout: 5000,
            headers: {
              'X-Api-Key': process.env.NEWS_API_KEY || process.env.NEWSAPI_KEY || ''
            }
          });

          const latency = Date.now() - t0;

          return {
            name,
            url,
            status: response.status,
            latency,
            ok: response.status >= 200 && response.status < 300,
            error: null
          };
        } catch (error: any) {
          const latency = Date.now() - t0;
          return {
            name,
            url,
            status: 0,
            latency,
            ok: false,
            error: error?.message || 'Request failed'
          };
        }
      })
    );

    const formattedResults = (results || []).map((result, index) => {
      if (result.status === 'fulfilled') {
        return result.value;
      } else {
        return {
          name: probes[index].name,
          url: probes[index].url,
          status: 0,
          latency: 0,
          ok: false,
          error: result.reason?.message || 'Unknown error'
        };
      }
    });

    const allOk = formattedResults.every(r => r.ok);

    res.json({
      ok: allOk,
      results: formattedResults,
      summary: {
        total: formattedResults.length,
        successful: formattedResults.filter(r => r.ok).length,
        failed: formattedResults.filter(r => !r.ok).length
      },
      timestamp: new Date().toISOString()
    });
  } catch (e: any) {
    logger.error('Network check failed', {}, e);
    res.status(503).json({
      ok: false,
      error: e?.message || 'netcheck_failed',
      message: 'Failed to perform network connectivity check'
    });
  }
});

/**
 * Health check for diagnostics system
 * GET /api/system/diagnostics/health
 */
router.get('/health', async (_req: Request, res: Response) => {
  try {
    res.json({
      success: true,
      ready: true,
      features: {
        connectivityDoctor: true,
        autoRemediate: true,
        offlineFallback: process.env.OFFLINE_ALLOW === '1',
        hfEnabled: process.env.ENABLE_HF === '1',
      },
    });
  } catch (e: any) {
    res.status(500).json({
      success: false,
      error: e?.message || 'health_check_failed',
    });
  }
});

/**
 * Network check with DNS and SSL probes
 * GET /api/system/diagnostics/netcheck
 * Best-effort diagnostics - always returns 200 with details
 */
router.get('/netcheck', async (_req: Request, res: Response) => {
  const results: any = {
    ok: true,
    timestamp: Date.now(),
    dns: {},
    ssl: {},
    probes: [],
  };

  try {
    // DNS Resolution Time Test
    const dnsHosts = ['newsapi.org', 'pro-api.coinmarketcap.com', 'api.alternative.me'];
    const dnsResults = await Promise.allSettled(
      (dnsHosts || []).map(async (host) => {
        const start = Date.now();
        try {
          const addresses = await Promise.race([
            dns.promises.resolve(host),
            new Promise((_, reject) =>
              setTimeout(() => reject(new Error('DNS_TIMEOUT')), 3000)
            ),
          ]);
          const timeMs = Date.now() - start;
          return { host, ok: true, timeMs, addresses };
        } catch (err: any) {
          const timeMs = Date.now() - start;
          return {
            host,
            ok: false,
            timeMs,
            error: err.message || err.code || 'DNS_FAILED',
          };
        }
      })
    );

    results.dns.tests = (dnsResults || []).map((r) =>
      r.status === 'fulfilled' ? r.value : { ok: false, error: 'Promise rejected' }
    );
    results.dns.summary = {
      total: dnsHosts.length,
      passed: dnsResults.filter((r) => r.status === 'fulfilled' && r.value.ok).length,
    };

    // TLS Handshake Probe
    const tlsHosts = [
      { hostname: 'newsapi.org', port: 443 },
      { hostname: 'pro-api.coinmarketcap.com', port: 443 },
    ];

    const tlsResults = await Promise.allSettled(
      (tlsHosts || []).map(
        (target) =>
          new Promise((resolve, reject) => {
            const start = Date.now();
            const socket = https.request(
              {
                hostname: target.hostname,
                port: target.port,
                method: 'HEAD',
                path: '/',
                timeout: 4000,
              },
              (res) => {
                const timeMs = Date.now() - start;
                socket.destroy();
                resolve({
                  hostname: target.hostname,
                  ok: true,
                  timeMs,
                  statusCode: res.statusCode,
                });
              }
            );

            socket.on('error', (err: any) => {
              const timeMs = Date.now() - start;
              resolve({
                hostname: target.hostname,
                ok: false,
                timeMs,
                error: err.message || err.code || 'TLS_FAILED',
              });
            });

            socket.on('timeout', () => {
              socket.destroy();
              const timeMs = Date.now() - start;
              resolve({
                hostname: target.hostname,
                ok: false,
                timeMs,
                error: 'TLS_TIMEOUT',
              });
            });

            socket.end();
          })
      )
    );

    results.ssl.tests = (tlsResults || []).map((r) =>
      r.status === 'fulfilled' ? r.value : { ok: false, error: 'Promise rejected' }
    );
    results.ssl.summary = {
      total: tlsHosts.length,
      passed: tlsResults.filter((r) => r.status === 'fulfilled' && (r.value as any).ok)
        .length,
    };

    // HTTP Probe for News API (with key if available)
    const newsApiKey = process.env.NEWS_API_KEY || process.env.NEWSAPI_KEY;
    if (newsApiKey && newsApiKey !== 'pub_346789abc123def456789ghi012345jkl') {
      try {
        const axios = (await import('axios')).default;
        const start = Date.now();
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
          params: {
            country: 'us',
            category: 'business',
            pageSize: 1,
          },
          headers: {
            'X-Api-Key': newsApiKey,
          },
          timeout: 5000,
        });
        const timeMs = Date.now() - start;

        results.probes.push({
          name: 'NewsAPI',
          ok: response.status === 200,
          status: response.status,
          timeMs,
          articlesCount: response.data?.articles?.length || 0,
        });
      } catch (err: any) {
        results.probes.push({
          name: 'NewsAPI',
          ok: false,
          error: err.message || 'HTTP_PROBE_FAILED',
          status: err.response?.status,
        });
      }
    } else {
      results.probes.push({
        name: 'NewsAPI',
        ok: false,
        skipped: true,
        reason: 'No valid API key configured',
      });
    }

    // Overall status
    const allDnsOk = results.dns.summary.passed === results.dns.summary.total;
    const allSslOk = results.ssl.summary.passed === results.ssl.summary.total;
    const newsOk = results.probes.find((p: any) => p.name === 'NewsAPI')?.ok || false;

    results.ok = allDnsOk && allSslOk;
    results.summary = {
      dns: allDnsOk ? 'ok' : 'degraded',
      ssl: allSslOk ? 'ok' : 'degraded',
      news: newsOk ? 'ok' : 'unavailable',
    };
  } catch (outerError: any) {
    // Even on catastrophic failure, return 200 with error details
    results.ok = false;
    results.error = outerError.message || 'NETCHECK_FAILED';
    logger.error('Netcheck failed', {}, outerError);
  }

  // Always return 200 (best-effort diagnostics)
  res.status(200).json(results);
});

export default router;
