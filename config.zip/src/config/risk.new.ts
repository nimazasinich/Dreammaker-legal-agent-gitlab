export const REFRESH_BASE_MS = 5000;
export const REFRESH_BACKOFF_MAX_MS = 60000;
export const MIN_OHLC_BARS = 50;
