export declare function fetchOHLCV(symbol: string, timeframe: string, limit?: number): Promise<any>;
export declare function fetchPrices(symbols: string[]): Promise<any>;
export declare function fetchUniverseTopN(n?: number): Promise<any>;
//# sourceMappingURL=RealDataProvider_from_LastChance.d.ts.map