Place `Vazirmatn-VariableFont_wght.ttf` in this directory to enable the local font face declared in `src/index.css`.

Recommended source: https://github.com/fontlinux/vazirmatn/releases
