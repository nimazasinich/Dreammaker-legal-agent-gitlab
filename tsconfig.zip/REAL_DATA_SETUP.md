# راهنمای استفاده از داده‌های واقعی

## ✅ تنظیمات انجام شده

### 1. فایل `.env.local` ایجاد شد

فایل `.env.local` با تنظیمات زیر ایجاد شده است:

```env
VITE_APP_MODE=online
VITE_AUTO_LOAD_DATA=true
VITE_AUTO_REFRESH=false
VITE_REFRESH_INTERVAL=600000
HUGGINGFACE_API_KEY=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
VITE_HUGGINGFACE_API_KEY=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
PORT=3001
NODE_ENV=development
```

### 2. تغییرات در DataContext

- **سیمبل‌ها**: از 5 سیمبل اصلی استفاده می‌شود: BTC, ETH, BNB, SOL, XRP
- **داده‌های واقعی**: تمام داده‌ها از APIهای واقعی دریافت می‌شوند
- **Auto-refresh**: غیرفعال است - برای refresh از دکمه استفاده کنید
- **Cache**: 5 دقیقه برای کاهش درخواست‌های تکراری

## 🚀 راه‌اندازی

```bash
# نصب وابستگی‌ها (اگر نصب نشده)
npm install

# راه‌اندازی سرور توسعه
npm run dev
```

برنامه در آدرس‌های زیر در دسترس خواهد بود:
- Frontend: http://localhost:5173
- Backend API: http://localhost:3001/api
- WebSocket: ws://localhost:3001/ws

## 📊 منابع داده واقعی

برنامه از منابع زیر داده دریافت می‌کند:

### 1. Binance API (رایگان)
- قیمت‌های لحظه‌ای
- داده‌های OHLCV
- محدودیت: 1200 درخواست/دقیقه

### 2. CoinGecko API (رایگان)
- اطلاعات کلی ارزها
- قیمت‌ها و حجم معاملات
- محدودیت: 10-50 درخواست/دقیقه

### 3. Hugging Face API
- تحلیل احساسات
- پیش‌بینی‌های AI
- توکن شما: `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`

## ⚙️ تنظیمات بهینه‌سازی

### کاهش تعداد درخواست‌ها

اگر با محدودیت API مواجه شدید:

```env
# کاهش تعداد سیمبل‌ها
# در src/contexts/DataContext.tsx خط 193:
const priceSymbols = ['BTC', 'ETH']; // فقط 2 سیمبل

# افزایش فاصله refresh
VITE_REFRESH_INTERVAL=1200000  # 20 دقیقه

# افزایش cache
VITE_CACHE_TTL=600000  # 10 دقیقه
```

### فعال کردن Auto-Refresh (اختیاری)

```env
VITE_AUTO_REFRESH=true
VITE_REFRESH_INTERVAL=600000  # هر 10 دقیقه
```

⚠️ **توجه**: فعال کردن auto-refresh باعث مصرف بیشتر API می‌شود.

## 🔍 مانیتورینگ

### بررسی درخواست‌های API

1. باز کردن Developer Tools (F12)
2. رفتن به تب **Network**
3. فیلتر با `api` یا `fetch`
4. مشاهده:
   - تعداد درخواست‌ها
   - زمان پاسخ
   - خطاهای احتمالی

### بررسی Console

در Console می‌توانید لاگ‌های زیر را ببینید:

```
🔄 Loading all data...
✅ Prices loaded: 5
✅ Real data flow initialized
```

## 🛠️ عیب‌یابی

### خطای "Rate limit exceeded"

**راه‌حل 1**: افزایش تاخیر بین درخواست‌ها
```env
VITE_REQUEST_DELAY=3000  # 3 ثانیه
```

**راه‌حل 2**: کاهش تعداد سیمبل‌ها
```typescript
const priceSymbols = ['BTC'];  // فقط بیت‌کوین
```

**راه‌حل 3**: استفاده از cache بیشتر
```env
VITE_CACHE_TTL=900000  # 15 دقیقه
```

### داده‌ها بارگذاری نمی‌شوند

1. بررسی اتصال اینترنت
2. بررسی Console برای خطاها
3. بررسی Network tab برای درخواست‌های ناموفق
4. اطمینان از اجرای backend:
   ```bash
   npm run dev:server
   ```

### خطای Hugging Face API

اگر خطای مربوط به Hugging Face دیدید:

1. بررسی اعتبار توکن در https://huggingface.co/settings/tokens
2. اطمینان از وجود توکن در `.env.local`
3. restart کردن سرور

## 📈 بهترین روش‌ها

### 1. استفاده از Refresh دستی
به جای auto-refresh، از دکمه refresh در UI استفاده کنید.

### 2. Cache هوشمند
برنامه به طور خودکار داده‌ها را cache می‌کند. نیازی به refresh مکرر نیست.

### 3. مانیتورینگ مصرف
هر روز تعداد درخواست‌های خود را چک کنید:
- CoinGecko: حداکثر 50 درخواست/دقیقه
- Binance: حداکثر 1200 درخواست/دقیقه
- Hugging Face: بسته به پلن شما

### 4. استفاده از WebSocket
برای داده‌های real-time، از WebSocket استفاده کنید که کارآمدتر است:

```javascript
const ws = new WebSocket('ws://localhost:3001/ws');
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Real-time data:', data);
};
```

## 🔐 امنیت

⚠️ **مهم**: فایل `.env.local` در `.gitignore` قرار دارد و commit نمی‌شود.

- **هرگز** توکن‌های API را در کد commit نکنید
- **همیشه** از فایل‌های `.env` استفاده کنید
- **منظماً** توکن‌ها را rotate کنید

## 📞 پشتیبانی

در صورت مشکل:

1. بررسی Developer Console
2. بررسی Network tab
3. بررسی لاگ‌های سرور
4. مطالعه `OPTIMIZATION_GUIDE_FA.md`

## 🎯 خلاصه

✅ داده‌های واقعی فعال است
✅ توکن Hugging Face ذخیره شد
✅ Auto-refresh غیرفعال است (برای صرفه‌جویی در API)
✅ Cache فعال است
✅ 5 سیمبل اصلی بارگذاری می‌شوند

برای refresh داده‌ها، از دکمه refresh در UI استفاده کنید! 🔄

