/**
 * ML Training & Backtesting Routes
 * Express proxy routes for ML microservice endpoints
 */
import { Router, Request, Response } from 'express';
import fetch from 'node-fetch';

const router = Router();

// ML service host from environment or default
const ML_HOST = process.env.ML_HOST || 'http://localhost:8765';

/**
 * Generic proxy handler for ML service
 */
async function proxyToML(req: Request, res: Response, endpoint: string, method: string = 'GET') {
  try {
    const url = `${ML_HOST}${endpoint}`;

    const options: any = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
    };

    // Add body for POST requests
    if (method === 'POST' && req.body) {
      options.body = JSON.stringify(req.body);
    }

    const response = await fetch(url, options);
    const data = await response.json();

    if (!response.ok) {
      res.status(response.status).json(data);
      return;
    }

    res.json(data);
  } catch (error: any) {
    console.error('ML proxy error:', error);
    res.status(503).json({
      error: 'ML service unavailable',
      message: error.message,
      hint: 'Ensure ML microservice is running at ' + ML_HOST
    });
  }
}

// Health check
router.get('/health', async (req, res) => {
  try {
    const response = await fetch(`${ML_HOST}/`, { mode: "cors", headers: { "Content-Type": "application/json" } });
    const data = await response.json();
    res.json({ status: 'connected', ml_service: data });
  } catch (error: any) {
    res.status(503).json({
      status: 'disconnected',
      error: error.message,
      ml_host: ML_HOST
    });
  }
});

// Training endpoints
router.post('/train/start', (req, res) => {
  proxyToML(req, res, '/train/start', 'POST');
});

router.get('/train/status', (req, res) => {
  const jobId = req.query.job_id as string;
  if (!jobId) {
    res.status(400).json({ error: 'job_id query parameter required' });
    return;
  }
  proxyToML(req, res, `/train/status?job_id=${jobId}`, 'GET');
});

// Backtesting endpoints
router.post('/backtest/run', (req, res) => {
  proxyToML(req, res, '/backtest/run', 'POST');
});

router.get('/backtest/status', (req, res) => {
  const jobId = req.query.job_id as string;
  if (!jobId) {
    res.status(400).json({ error: 'job_id query parameter required' });
    return;
  }
  proxyToML(req, res, `/backtest/status?job_id=${jobId}`, 'GET');
});

// Model management endpoints
router.get('/models', (req, res) => {
  proxyToML(req, res, '/models', 'GET');
});

router.get('/models/:model_id/metrics', (req, res) => {
  const modelId = req.params.model_id;
  proxyToML(req, res, `/models/${modelId}/metrics`, 'GET');
});

// Artifacts endpoint
router.get('/artifacts', (req, res) => {
  proxyToML(req, res, '/artifacts', 'GET');
});

export default router;
