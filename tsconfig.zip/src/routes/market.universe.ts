/**
 * Market Universe Routes
 * Express routes for fetching top trading pairs by volume
 */
import { Router, Request, Response } from 'express';
import fetch from 'node-fetch';

const router = Router();

// Helper to fetch JSON with timeout
async function getJSON(url: string, opts: any = {}, timeoutMs = 10000): Promise<any> {
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...opts, signal: ctrl.signal });
    if (!res.ok) console.error(`${res.status} ${res.statusText}`);
    return await res.json();
  } finally {
    clearTimeout(id);
  }
}

/**
 * GET /api/market/universe?quote=USDT&limit=300
 * Returns an array of { symbolUI, symbolBinance, base, quote, rank, volume24h }
 * Provider order: Binance (exchangeInfo + tickers) → CoinGecko (fallback)
 */
router.get('/universe', async (req: Request, res: Response) => {
  const quote = (String(req.query.quote || 'USDT')).toUpperCase();
  const limit = Math.min(Number(req.query.limit || 300), 500);

  try {
    // 1) Try Binance
    const [exInfo, tick24h] = await Promise.all([
      getJSON('https://api.binance.com/api/v3/exchangeInfo'),
      getJSON('https://api.binance.com/api/v3/ticker/24hr')
    ]);

    const valid = new Set<string>();
    const usdtSymbols: Array<{ symbolBinance: string; base: string; volume24h: number }> = [];

    for (const s of exInfo.symbols || []) {
      if (s.status !== 'TRADING') continue;
      if (s.quoteAsset !== quote) continue;
      valid.add(s.symbol);
    }

    for (const t of tick24h || []) {
      if (!valid.has(t.symbol)) continue;
      const vol = Number(t.quoteVolume || t.volume || 0);
      const base = t.symbol.replace(quote, '');
      usdtSymbols.push({ symbolBinance: t.symbol, base, volume24h: vol });
    }

    usdtSymbols.sort((a, b) => b.volume24h - a.volume24h);
    const top = usdtSymbols.slice(0, limit).map((r, i) => ({
      rank: i + 1,
      symbolUI: `${r.base}/${quote}`,
      symbolBinance: r.symbolBinance,
      base: r.base,
      quote,
      volume24h: r.volume24h,
    }));

    if ((top?.length || 0) >= Math.min(100, limit)) {
      return res.json({ provider: 'binance', quote, limit, items: top });
    }

    // 2) Fallback: CoinGecko top markets (map to /USDT if available)
    const cg = await getJSON('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=300&page=1');
    const alt = cg.slice(0, limit).map((r: any, i: number) => ({
      rank: i + 1,
      symbolUI: `${(r.symbol || 'btc').toUpperCase()}/${quote}`,
      symbolBinance: `${(r.symbol || 'BTC').toUpperCase()}${quote}`,
      base: (r.symbol || 'BTC').toUpperCase(),
      quote,
      volume24h: Number(r.total_volume || 0)
    }));
    return res.json({ provider: 'coingecko', quote, limit, items: alt });
  } catch (err: any) {
    return res.status(502).json({ error: 'universe_fetch_failed', message: err.message });
  }
});

export default router;
