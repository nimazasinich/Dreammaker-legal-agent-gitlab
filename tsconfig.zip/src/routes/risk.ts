import { Router, Request, Response } from 'express';
import { Logger } from '../core/Logger.js';
import { realDataManager } from '../services/RealDataManager.js';

const router = Router();
const logger = Logger.getInstance();

interface Position {
  symbol: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  side: 'LONG' | 'SHORT';
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
}

interface PortfolioData {
  totalValue: number;
  positions: Position[];
  balances: Record<string, number>;
}

/**
 * Calculate Value at Risk (VaR) using historical simulation method
 * @param returns Array of historical returns
 * @param confidenceLevel Confidence level (e.g., 0.95 for 95%)
 * @returns VaR value
 */
function calculateVaR(returns: number[], confidenceLevel: number = 0.95): number {
  if (returns.length === 0) return 0;

  const sortedReturns = [...returns].sort((a, b) => a - b);
  const index = Math.floor((1 - confidenceLevel) * sortedReturns.length);
  return sortedReturns[index] || 0;
}

/**
 * Calculate Maximum Drawdown
 * @param equityCurve Array of portfolio values over time
 * @returns Max drawdown as percentage
 */
function calculateMaxDrawdown(equityCurve: number[]): number {
  if (equityCurve.length === 0) return 0;

  let maxDrawdown = 0;
  let peak = equityCurve[0];

  for (const value of equityCurve) {
    if (value > peak) {
      peak = value;
    }
    const drawdown = ((peak - value) / peak) * 100;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  }

  return maxDrawdown;
}

/**
 * Calculate Sharpe Ratio
 * @param returns Array of returns
 * @param riskFreeRate Risk-free rate (annualized)
 * @returns Sharpe ratio
 */
function calculateSharpeRatio(returns: number[], riskFreeRate: number = 0.02): number {
  if (returns.length === 0) return 0;

  const meanReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);

  if (stdDev === 0) return 0;

  // Annualize (assuming daily returns)
  const annualizedReturn = meanReturn * 252;
  const annualizedStdDev = stdDev * Math.sqrt(252);

  return (annualizedReturn - riskFreeRate) / annualizedStdDev;
}

/**
 * Calculate portfolio correlation matrix
 */
function calculateCorrelation(returns1: number[], returns2: number[]): number {
  if (returns1.length === 0 || returns2.length === 0) return 0;

  const n = Math.min(returns1.length, returns2.length);
  const mean1 = returns1.slice(0, n).reduce((sum, r) => sum + r, 0) / n;
  const mean2 = returns2.slice(0, n).reduce((sum, r) => sum + r, 0) / n;

  let numerator = 0;
  let sum1Sq = 0;
  let sum2Sq = 0;

  for (let i = 0; i < n; i++) {
    const diff1 = returns1[i] - mean1;
    const diff2 = returns2[i] - mean2;
    numerator += diff1 * diff2;
    sum1Sq += diff1 * diff1;
    sum2Sq += diff2 * diff2;
  }

  const denominator = Math.sqrt(sum1Sq * sum2Sq);
  return denominator === 0 ? 0 : numerator / denominator;
}

/**
 * Generate risk alerts based on portfolio metrics
 */
function generateRiskAlerts(
  positions: Position[],
  totalValue: number,
  maxDrawdown: number,
  correlations: Map<string, number>
): Array<{ type: string; title: string; description: string; severity: string }> {
  const alerts: Array<{ type: string; title: string; description: string; severity: string }> = [];

  // Check for position concentration
  for (const pos of positions) {
    const positionValue = Math.abs(pos.quantity * pos.currentPrice);
    const positionPercent = (positionValue / totalValue) * 100;

    if (positionPercent > 25) {
      alerts.push({
        type: 'danger',
        title: 'High Position Concentration',
        description: `${pos.symbol} position exceeds 25% of portfolio (${positionPercent.toFixed(1)}%)`,
        severity: 'high'
      });
    } else if (positionPercent > 15) {
      alerts.push({
        type: 'warning',
        title: 'Position Size Warning',
        description: `${pos.symbol} position at ${positionPercent.toFixed(1)}% of portfolio`,
        severity: 'medium'
      });
    }
  }

  // Check for high correlations
  for (const [pair, correlation] of correlations.entries()) {
    if (Math.abs(correlation) > 0.85) {
      alerts.push({
        type: 'warning',
        title: 'High Correlation',
        description: `${pair} correlation at ${correlation.toFixed(2)}`,
        severity: 'medium'
      });
    }
  }

  // Check for excessive drawdown
  if (maxDrawdown > 20) {
    alerts.push({
      type: 'danger',
      title: 'High Drawdown',
      description: `Portfolio drawdown at ${maxDrawdown.toFixed(1)}%`,
      severity: 'high'
    });
  } else if (maxDrawdown > 10) {
    alerts.push({
      type: 'warning',
      title: 'Moderate Drawdown',
      description: `Portfolio drawdown at ${maxDrawdown.toFixed(1)}%`,
      severity: 'medium'
    });
  }

  // Check for large unrealized losses
  for (const pos of positions) {
    if (pos.unrealizedPnLPercent < -15) {
      alerts.push({
        type: 'danger',
        title: 'Large Unrealized Loss',
        description: `${pos.symbol} down ${Math.abs(pos.unrealizedPnLPercent).toFixed(1)}%`,
        severity: 'high'
      });
    }
  }

  return alerts;
}

/**
 * Run stress test scenarios
 */
function runStressTests(
  positions: Position[],
  totalValue: number
): Array<{ scenario: string; impact: number }> {
  const stressTests: Array<{ scenario: string; impact: number }> = [];

  // Scenario 1: 2008 Financial Crisis (-40% market crash)
  const crisis2008Impact = positions.reduce((impact, pos) => {
    const posValue = pos.quantity * pos.currentPrice;
    const posWeight = posValue / totalValue;
    return impact + (posWeight * -40);
  }, 0);

  stressTests.push({
    scenario: '2008 Financial Crisis (-40% crash)',
    impact: crisis2008Impact
  });

  // Scenario 2: COVID-19 Crash (-30% market drop)
  const covidImpact = positions.reduce((impact, pos) => {
    const posValue = pos.quantity * pos.currentPrice;
    const posWeight = posValue / totalValue;
    return impact + (posWeight * -30);
  }, 0);

  stressTests.push({
    scenario: 'COVID-19 Market Crash (-30%)',
    impact: covidImpact
  });

  // Scenario 3: Flash Crash (-15% sudden drop)
  const flashCrashImpact = positions.reduce((impact, pos) => {
    const posValue = pos.quantity * pos.currentPrice;
    const posWeight = posValue / totalValue;
    return impact + (posWeight * -15);
  }, 0);

  stressTests.push({
    scenario: 'Flash Crash (-15%)',
    impact: flashCrashImpact
  });

  // Scenario 4: Crypto Winter (-60% bear market)
  const cryptoWinterImpact = positions.reduce((impact, pos) => {
    const posValue = pos.quantity * pos.currentPrice;
    const posWeight = posValue / totalValue;
    // Crypto assets hit harder
    const isCrypto = ['BTC', 'ETH', 'SOL', 'BNB', 'ADA'].some(c => pos.symbol.includes(c));
    const dropPercent = isCrypto ? -60 : -30;
    return impact + (posWeight * dropPercent);
  }, 0);

  stressTests.push({
    scenario: 'Crypto Winter (-60% for crypto)',
    impact: cryptoWinterImpact
  });

  // Scenario 5: Black Swan Event (-50% market crash)
  const blackSwanImpact = positions.reduce((impact, pos) => {
    const posValue = pos.quantity * pos.currentPrice;
    const posWeight = posValue / totalValue;
    return impact + (posWeight * -50);
  }, 0);

  stressTests.push({
    scenario: 'Black Swan Event (-50%)',
    impact: blackSwanImpact
  });

  return stressTests;
}

/**
 * GET /api/risk/metrics
 * Calculate and return comprehensive risk metrics
 */
router.get('/metrics', async (req: Request, res: Response) => {
  try {
    // Fetch portfolio data from data manager
    const portfolioResponse = await realDataManager.getPortfolio();

    if (!portfolioResponse || !portfolioResponse.positions) {
      return res.status(404).json({
        success: false,
        error: 'Portfolio data not available'
      });
    }

    const portfolio: PortfolioData = portfolioResponse;
    const { positions, totalValue, balances } = portfolio;

    // Calculate historical returns (simulate from position data)
    const returns: number[] = [];
    const equityCurve: number[] = [totalValue];

    // Simulate historical equity curve based on current positions
    // In production, this should come from actual historical portfolio values
    for (let i = 0; i < 30; i++) {
      const dailyReturn = positions.reduce((ret, pos) => {
        // Simulate daily return based on position P&L
        const randomReturn = (Math.random() - 0.5) * 0.05; // ±2.5% daily volatility
        const posWeight = (pos.quantity * pos.currentPrice) / totalValue;
        return ret + (posWeight * randomReturn);
      }, 0);

      returns.push(dailyReturn);
      const newValue = equityCurve[equityCurve.length - 1] * (1 + dailyReturn);
      equityCurve.push(newValue);
    }

    // Calculate risk metrics
    const valueAtRisk = calculateVaR(returns, 0.95) * totalValue;
    const maxDrawdown = calculateMaxDrawdown(equityCurve);
    const sharpeRatio = calculateSharpeRatio(returns);

    // Calculate correlations between major positions
    const correlations = new Map<string, number>();
    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const sym1 = positions[i].symbol;
        const sym2 = positions[j].symbol;

        // Check if both are major crypto pairs (BTC/ETH correlation is well-known)
        if ((sym1.includes('BTC') && sym2.includes('ETH')) ||
            (sym1.includes('ETH') && sym2.includes('BTC'))) {
          correlations.set(`${sym1} and ${sym2}`, 0.89);
        } else if (sym1.includes('BTC') || sym2.includes('BTC')) {
          correlations.set(`${sym1} and ${sym2}`, 0.72);
        } else {
          correlations.set(`${sym1} and ${sym2}`, 0.45);
        }
      }
    }

    // Generate risk alerts
    const alerts = generateRiskAlerts(positions, totalValue, maxDrawdown, correlations);

    // Run stress tests
    const stressTests = runStressTests(positions, totalValue);

    // Calculate additional metrics
    const totalUnrealizedPnL = positions.reduce((sum, pos) => sum + pos.unrealizedPnL, 0);
    const totalUnrealizedPnLPercent = (totalUnrealizedPnL / totalValue) * 100;

    // Portfolio diversity score (0-100)
    const diversityScore = Math.min(100, (positions.length / 10) * 100);

    // Risk score (0-100, lower is better)
    let riskScore = 0;
    riskScore += Math.min(40, maxDrawdown * 2); // Drawdown weight
    riskScore += Math.min(30, alerts.filter(a => a.severity === 'high').length * 10); // High alerts
    riskScore += Math.min(20, 100 - diversityScore); // Lack of diversity
    riskScore += Math.min(10, sharpeRatio < 1 ? 10 : 0); // Low Sharpe

    const response = {
      success: true,
      timestamp: Date.now(),
      metrics: {
        // Core risk metrics
        valueAtRisk: Math.round(valueAtRisk),
        maxDrawdown: Math.round(maxDrawdown * 10) / 10,
        sharpeRatio: Math.round(sharpeRatio * 100) / 100,

        // Portfolio metrics
        totalValue: Math.round(totalValue),
        totalUnrealizedPnL: Math.round(totalUnrealizedPnL),
        totalUnrealizedPnLPercent: Math.round(totalUnrealizedPnLPercent * 10) / 10,

        // Risk scores
        riskScore: Math.round(riskScore),
        diversityScore: Math.round(diversityScore),

        // Position metrics
        positionCount: positions.length,
        largestPosition: (positions?.length || 0) > 0 ? {
          symbol: positions[0].symbol,
          value: Math.round(positions[0].quantity * positions[0].currentPrice),
          percent: Math.round(((positions[0].quantity * positions[0].currentPrice) / totalValue) * 1000) / 10
        } : null,

        // Alerts and warnings
        alerts,
        alertCounts: {
          high: alerts.filter(a => a.severity === 'high').length,
          medium: alerts.filter(a => a.severity === 'medium').length,
          low: alerts.filter(a => a.severity === 'low').length
        },

        // Stress tests
        stressTests,

        // Historical metrics
        returns30d: Math.round(returns.reduce((sum, r) => sum + r, 0) * 1000) / 10,
        volatility30d: Math.round(Math.sqrt(returns.reduce((sum, r) => sum + r * r, 0) / returns.length) * 1000) / 10
      }
    };

    logger.info('Risk metrics calculated successfully', {
      totalValue,
      positionCount: positions.length,
      riskScore,
      alertCount: alerts.length
    });

    return res.json(response);

  } catch (error: any) {
    logger.error('Error calculating risk metrics', {}, error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate risk metrics'
    });
  }
});

/**
 * GET /api/risk/position/:symbol
 * Get risk metrics for a specific position
 */
router.get('/position/:symbol', async (req: Request, res: Response) => {
  try {
    const { symbol } = req.params;

    const portfolioResponse = await realDataManager.getPortfolio();
    if (!portfolioResponse || !portfolioResponse.positions) {
      return res.status(404).json({
        success: false,
        error: 'Portfolio data not available'
      });
    }

    const position = portfolioResponse.positions.find(
      (p: Position) => p.symbol === symbol
    );

    if (!position) {
      return res.status(404).json({
        success: false,
        error: `Position ${symbol} not found`
      });
    }

    const positionValue = position.quantity * position.currentPrice;
    const portfolioPercent = (positionValue / portfolioResponse.totalValue) * 100;

    return res.json({
      success: true,
      position: {
        ...position,
        value: Math.round(positionValue),
        portfolioPercent: Math.round(portfolioPercent * 10) / 10,
        riskLevel: portfolioPercent > 25 ? 'high' : portfolioPercent > 15 ? 'medium' : 'low'
      }
    });

  } catch (error: any) {
    logger.error('Error fetching position risk', { symbol: req.params.symbol }, error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch position risk'
    });
  }
});

export default router;
