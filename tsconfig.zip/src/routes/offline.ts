/**
 * Offline Routes
 * Express routes for offline data management and seeding
 */
import { Router, Request, Response } from 'express';
import { FallbackDataProvider } from '../providers/FallbackDataProvider.js';
import { Logger } from '../core/Logger.js';

const router = Router();
const logger = Logger.getInstance();

/**
 * Seed cache with data (supports offline fallback)
 * GET /api/offline/seed?symbol=BTCUSDT&tf=15m&bars=1000
 */
router.get('/seed', async (req: Request, res: Response) => {
  try {
    const symbol = (req.query.symbol as string) || 'BTCUSDT';
    const tf = (req.query.tf as string) || '15m';
    const limit = Number(req.query.bars || 1000);

    logger.info(`Seeding cache for ${symbol} ${tf}`, { limit });

    const bars = await FallbackDataProvider.getOHLCV(symbol, tf, limit);

    res.json({
      success: true,
      symbol,
      timeframe: tf,
      rows: bars.length,
      cached: true,
      message: `Successfully seeded cache with ${bars.length} bars`,
    });
  } catch (e: any) {
    logger.error('Seed endpoint failed', {}, e);
    res.status(500).json({
      success: false,
      error: e?.message || 'seed_failed',
      message: 'Failed to seed cache',
    });
  }
});

/**
 * Get OHLCV data with full cascade fallback
 * GET /api/offline/ohlcv?symbol=BTCUSDT&tf=15m&limit=500
 */
router.get('/ohlcv', async (req: Request, res: Response) => {
  try {
    const symbol = (req.query.symbol as string) || 'BTCUSDT';
    const tf = (req.query.tf as string) || '15m';
    const limit = Number(req.query.limit || 500);

    logger.debug(`OHLCV request for ${symbol} ${tf}`, { limit });

    const bars = await FallbackDataProvider.getOHLCV(symbol, tf, limit);

    res.json({
      success: true,
      symbol,
      timeframe: tf,
      data: bars,
      count: bars.length,
    });
  } catch (e: any) {
    logger.error('OHLCV endpoint failed', {}, e);
    res.status(500).json({
      success: false,
      error: e?.message || 'ohlcv_failed',
    });
  }
});

/**
 * Clear cache
 * DELETE /api/offline/cache?symbol=BTCUSDT&tf=15m
 */
router.delete('/cache', async (req: Request, res: Response) => {
  try {
    const symbol = req.query.symbol as string | undefined;
    const tf = req.query.tf as string | undefined;

    if (symbol && tf) {
      FallbackDataProvider.clearCache(symbol, tf);
      logger.info(`Cache cleared for ${symbol} ${tf}`);
      res.json({
        success: true,
        message: `Cache cleared for ${symbol} ${tf}`,
      });
    } else {
      FallbackDataProvider.clearCache();
      logger.info('All cache cleared');
      res.json({
        success: true,
        message: 'All cache cleared',
      });
    }
  } catch (e: any) {
    logger.error('Cache clear failed', {}, e);
    res.status(500).json({
      success: false,
      error: e?.message || 'clear_failed',
    });
  }
});

/**
 * Health check for offline mode
 * GET /api/offline/health
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
    const offlineAllowed = process.env.OFFLINE_ALLOW === '1';
    const hfEnabled = process.env.ENABLE_HF === '1';

    res.json({
      success: true,
      offlineMode: offlineAllowed,
      hfEnabled,
      ready: true,
    });
  } catch (e: any) {
    res.status(500).json({
      success: false,
      error: e?.message || 'health_check_failed',
    });
  }
});

export default router;
