// Environment configuration (works in both Vite frontend and Node backend)
// Unified env handling for API and WebSocket endpoints

/**
 * Get environment variable (works in both Vite frontend and Node backend)
 */
function getEnv(key: string): string | undefined {
  // Frontend (Vite)
  if (typeof import.meta?.env !== 'undefined') {
    return import.meta.env[key];
  }
  // Backend (Node.js)
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key];
  }
  return undefined;
}

/**
 * API Base URL
 * Priority: VITE_API_BASE > VITE_API_URL/api > http://localhost:3001
 * IMPORTANT: Sanitize to prevent double /api suffix
 */
const rawApiBase = getEnv('VITE_API_BASE')
  ?? (getEnv('VITE_API_URL')?.replace(/\/$/, '') + '/api')
  ?? 'http://localhost:3001';
export const API_BASE = rawApiBase.replace(/\/api\/?$/i, '');

/**
 * Ensure WebSocket endpoint has proper format
 * Converts HTTP URLs to WS URLs WITHOUT /ws path (will be added by dataManager)
 */
function ensureWsEndpoint(raw?: string): string {
  if (!raw) return 'ws://localhost:3001';

  // Already a WebSocket URL - remove /ws suffix if present
  if (raw.startsWith('ws://') || raw.startsWith('wss://')) {
    // Remove trailing /ws or /ws/ to prevent doubling
    return raw.replace(/\/ws\/?$/, '');
  }

  // Convert HTTP URL to WebSocket (without /ws path)
  try {
    const url = new URL(raw);
    const wsProtocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${wsProtocol}//${url.host}`;
  } catch {
    return 'ws://localhost:3001';
  }
}

/**
 * WebSocket Base URL (without /ws path - will be added by dataManager)
 * Priority: VITE_WS_BASE > VITE_WS_URL > ws://localhost:3001
 * IMPORTANT: Returns base URL only, path will be appended by connection manager
 */
const rawWsBase = getEnv('VITE_WS_BASE')
  ?? getEnv('VITE_WS_URL');
export const WS_BASE = ensureWsEndpoint(rawWsBase);

/**
 * Disable polling when WebSocket is connected (WS-first approach)
 */
export const DISABLE_POLL_WHEN_WS = String(getEnv('VITE_DISABLE_POLL_WHEN_WS') || '1') === '1';

// Re-export data policy configuration
// Use these imports from dataPolicy.ts for consistency
export {
  APP_MODE,
  STRICT_REAL_DATA,
  USE_MOCK_DATA,
  ALLOW_FAKE_DATA,
  assertPolicy,
  getDataSourceLabel,
  canUseSyntheticData,
  shouldUseMockFixtures,
  requiresRealData,
} from './dataPolicy';

// Telegram store secret for backend (server-side only, not accessible from frontend)
export const TELEGRAM_STORE_SECRET = process.env.TELEGRAM_STORE_SECRET || '';
