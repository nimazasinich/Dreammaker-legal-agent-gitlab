/**
 * KuCoin Futures Adapter
 * Implements IFuturesExchange for KuCoin Futures API
 * Adapted from Project A's KuCoinFuturesService
 */
import crypto from 'crypto';
import axios, { AxiosInstance, AxiosError } from 'axios';
import { Logger } from '../../core/Logger.js';
import { IFuturesExchange } from './IFuturesExchange.js';
import {
  FuturesPosition,
  FuturesOrder,
  LeverageSettings,
  FundingRate,
  FuturesAccountBalance,
  FuturesOrderbook
} from '../../types/futures.js';

interface KuCoinCredentials {
  apiKey: string;
  apiSecret: string;
  passphrase: string;
}

interface KuCoinResponse<T> {
  code: string;
  data: T;
  msg?: string;
}

export class KucoinFuturesAdapter implements IFuturesExchange {
  private static instance: KucoinFuturesAdapter;
  private logger = Logger.getInstance();
  private readonly baseUrl: string;
  private credentials: KuCoinCredentials | null = null;
  private httpClient: AxiosInstance;

  private constructor() {
    this.baseUrl = process.env.FUTURES_BASE_URL || 'https://api-futures.kucoin.com';
    this.httpClient = axios.create({
      baseURL: this.baseUrl,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.loadCredentials();
  }

  static getInstance(): KucoinFuturesAdapter {
    if (!KucoinFuturesAdapter.instance) {
      KucoinFuturesAdapter.instance = new KucoinFuturesAdapter();
    }
    return KucoinFuturesAdapter.instance;
  }

  private loadCredentials(): void {
    const apiKey = process.env.KUCOIN_FUTURES_KEY;
    const apiSecret = process.env.KUCOIN_FUTURES_SECRET;
    const passphrase = process.env.KUCOIN_FUTURES_PASSPHRASE;

    if (apiKey && apiSecret && passphrase) {
      this.credentials = {
        apiKey,
        apiSecret,
        passphrase
      };
      this.logger.info('KuCoin Futures credentials loaded');
    } else {
      this.logger.warn('KuCoin Futures credentials not configured. Set KUCOIN_FUTURES_KEY, KUCOIN_FUTURES_SECRET, and KUCOIN_FUTURES_PASSPHRASE');
    }
  }

  setCredentials(credentials: KuCoinCredentials): void {
    this.credentials = credentials;
    this.logger.info('KuCoin Futures credentials updated');
  }

  private generateSignature(timestamp: string, method: string, endpoint: string, body = ''): string {
    if (!this.credentials) {
      console.error('KuCoin Futures credentials not configured');
    }

    const strToSign = timestamp + method + endpoint + body;
    return crypto
      .createHmac('sha256', this.credentials.apiSecret)
      .update(strToSign)
      .digest('base64');
  }

  private generateHeaders(method: string, endpoint: string, body = ''): Record<string, string> {
    if (!this.credentials) {
      console.error('KuCoin Futures credentials not configured');
    }

    const timestamp = Date.now().toString();
    const signature = this.generateSignature(timestamp, method, endpoint, body);
    
    const passphrase = crypto
      .createHmac('sha256', this.credentials.apiSecret)
      .update(this.credentials.passphrase)
      .digest('base64');

    return {
      'KC-API-KEY': this.credentials.apiKey,
      'KC-API-SIGN': signature,
      'KC-API-TIMESTAMP': timestamp,
      'KC-API-PASSPHRASE': passphrase,
      'KC-API-KEY-VERSION': '2',
      'Content-Type': 'application/json'
    };
  }

  /**
   * Normalize symbol format for KuCoin Futures API
   * Converts dashed format (BTC-USDTM) to no-dash format (XBTUSDTM)
   * Futures symbols are no-dash per KuCoin API spec
   */
  private normalizeSymbol(symbol: string): string {
    // Remove dashes if present
    let normalized = symbol.replace(/-/g, '');
    
    // Convert BTC to XBT if needed (KuCoin uses XBT for Bitcoin futures)
    if (normalized.startsWith('BTC')) {
      normalized = normalized.replace('BTC', 'XBT');
    }
    
    // Ensure it ends with USDTM for futures
    if (!normalized.endsWith('USDTM') && normalized.endsWith('USDT')) {
      normalized = normalized.replace('USDT', 'USDTM');
    }
    
    return normalized.toUpperCase();
  }

  private async request<T>(
    method: 'GET' | 'POST' | 'DELETE' | 'PUT',
    endpoint: string,
    body?: any
  ): Promise<T> {
    if (!this.credentials) {
      console.error('KuCoin Futures credentials not configured');
    }

    const bodyStr = body ? JSON.stringify(body) : '';
    const headers = this.generateHeaders(method, endpoint, bodyStr);

    try {
      const config: any = {
        method,
        url: endpoint,
        headers
      };

      if (body && (method === 'POST' || method === 'PUT')) {
        config.data = body;
      }

      const response = await this.httpClient.request<KuCoinResponse<T>>(config);

      if (response.data.code !== '200000') {
        console.error(response.data.msg || `KuCoin API error: ${response.data.code}`);
      }

      return response.data.data;
    } catch (error) {
      const axiosError = error as AxiosError<KuCoinResponse<any>>;
      
      if (axiosError.response) {
        const errorMsg = axiosError.response.data?.msg || axiosError.response.data?.code || 'Unknown error';
        this.logger.error('KuCoin Futures API error', {
          endpoint,
          method,
          status: axiosError.response.status,
          error: errorMsg
        });
        console.error(`KuCoin Futures API error: ${errorMsg}`);
      }

      if (axiosError.request) {
        this.logger.error('KuCoin Futures API request failed', { endpoint, method });
        console.error('Network error: Failed to reach KuCoin Futures API');
      }

      this.logger.error('KuCoin Futures API error', { endpoint, method }, error as Error);
      throw error;
    }
  }

  async getPositions(): Promise<FuturesPosition[]> {
    try {
      const data = await this.request<any[]>('GET', '/api/v1/positions');
      
      return (data || []).map((pos: any) => ({
        symbol: pos.symbol, // Keep original symbol format from API
        side: pos.currentQty > 0 ? 'long' : 'short',
        size: Math.abs(pos.currentQty),
        entryPrice: parseFloat(pos.avgEntryPrice || '0'),
        markPrice: parseFloat(pos.markPrice || '0'),
        leverage: parseInt(pos.realLeverage || '1'),
        unrealizedPnl: parseFloat(pos.unrealisedPnl || '0'),
        liquidationPrice: parseFloat(pos.liquidationPrice || '0'),
        marginMode: pos.crossMode ? 'cross' : 'isolated',
        marginUsed: pos.marginUsed ? parseFloat(pos.marginUsed) : undefined,
        marginAvailable: pos.availableMargin ? parseFloat(pos.availableMargin) : undefined
      }));
    } catch (error) {
      this.logger.error('Failed to get positions', {}, error as Error);
      throw error;
    }
  }

  async placeOrder(order: FuturesOrder): Promise<any> {
    try {
      const normalizedSymbol = this.normalizeSymbol(order.symbol);
      
      // Convert side to KuCoin format
      const side = order.side === 'long' ? 'buy' : order.side === 'short' ? 'sell' : order.side;
      
      // Build base order body
      const body: any = {
        clientOid: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        side,
        symbol: normalizedSymbol,
        type: order.type,
        size: order.qty,
        reduceOnly: order.reduceOnly || false
      };

      // Add price for limit orders
      if (order.type === 'limit' && order.price) {
        body.price = String(order.price);
      }

      // Add leverage if specified
      if (order.leverage) {
        body.leverage = order.leverage;
      }

      // Handle stop loss/take profit using KuCoin's stop order format
      // KuCoin expects: stop ('up'|'down'), stopPrice, stopPriceType ('TP'|'IP'|'MP')
      // Note: For dedicated TP/SL orders, consider using TPSL endpoint:
      // POST /api/v1/stopOrder with triggerStopUpPrice/triggerStopDownPrice
      if (order.stopLoss) {
        // Determine stop direction based on side
        // For long positions: stop='down' (stop loss below entry)
        // For short positions: stop='up' (stop loss above entry)
        const stopDirection = (side === 'buy' || order.side === 'long') ? 'down' : 'up';
        body.stop = stopDirection;
        body.stopPrice = String(order.stopLoss);
        body.stopPriceType = 'MP'; // Mark Price (can be TP/IP/MP: Trigger Price/Index Price/Mark Price)
      }

      if (order.takeProfit) {
        // For take profit, direction is opposite of stop loss
        // Note: KuCoin supports separate TP/SL orders via TPSL endpoint
        // POST /api/v1/stopOrder with triggerStopUpPrice/triggerStopDownPrice
        // For now, we include takeProfit in the order body
        // In production, consider using dedicated TPSL endpoint for better control
        body.takeProfit = String(order.takeProfit);
      }

      // Remove undefined fields
      Object.keys(body).forEach(key => {
        if (body[key] === undefined) {
          delete body[key];
        }
      });

      return await this.request('POST', '/api/v1/orders', body);
    } catch (error) {
      this.logger.error('Failed to place order', { order }, error as Error);
      throw error;
    }
  }

  async cancelOrder(orderId: string): Promise<any> {
    try {
      return await this.request('DELETE', `/api/v1/orders/${orderId}`);
    } catch (error) {
      this.logger.error('Failed to cancel order', { orderId }, error as Error);
      throw error;
    }
  }

  async cancelAllOrders(symbol?: string): Promise<any> {
    try {
      const normalizedSymbol = symbol ? this.normalizeSymbol(symbol) : undefined;
      const endpoint = normalizedSymbol 
        ? `/api/v1/orders?symbol=${normalizedSymbol}`
        : '/api/v1/orders';
      
      return await this.request('DELETE', endpoint);
    } catch (error) {
      this.logger.error('Failed to cancel all orders', { symbol }, error as Error);
      throw error;
    }
  }

  async getOpenOrders(symbol?: string): Promise<any[]> {
    try {
      const normalizedSymbol = symbol ? this.normalizeSymbol(symbol) : undefined;
      const endpoint = normalizedSymbol 
        ? `/api/v1/orders?status=active&symbol=${normalizedSymbol}`
        : '/api/v1/orders?status=active';
      
      const response = await this.request<{ items: any[] }>('GET', endpoint);
      return response.items || [];
    } catch (error) {
      this.logger.error('Failed to get open orders', { symbol }, error as Error);
      throw error;
    }
  }

  /**
   * Set leverage for cross margin mode
   * Uses KuCoin API v2 endpoint: POST /api/v2/changeCrossUserLeverage
   */
  async setLeverage(symbol: string, leverage: number, marginMode = 'isolated'): Promise<any> {
    try {
      const normalizedSymbol = this.normalizeSymbol(symbol);
      
      if (marginMode === 'cross') {
        // Cross margin leverage endpoint
        const body = {
          leverage: leverage.toString()
        };
        return await this.request('POST', '/api/v2/changeCrossUserLeverage', body);
      } else {
        // Isolated margin uses risk limit level (not direct leverage)
        // The risk limit level determines max leverage
        const body = {
          symbol: normalizedSymbol,
          level: leverage.toString() // Level maps to max leverage
        };
        return await this.request('POST', '/api/v1/position/risk-limit-level/change', body);
      }
    } catch (error) {
      this.logger.error('Failed to set leverage', { symbol, leverage, marginMode }, error as Error);
      throw error;
    }
  }

  async getAccountBalance(): Promise<FuturesAccountBalance> {
    try {
      const data = await this.request<any>('GET', '/api/v1/account-overview');
      
      return {
        availableBalance: parseFloat(data.availableBalance || '0'),
        accountEquity: parseFloat(data.accountEquity || '0'),
        unrealisedPNL: parseFloat(data.unrealisedPNL || '0'),
        marginBalance: parseFloat(data.marginBalance || '0'),
        positionMargin: data.positionMargin ? parseFloat(data.positionMargin) : undefined,
        orderMargin: data.orderMargin ? parseFloat(data.orderMargin) : undefined
      };
    } catch (error) {
      this.logger.error('Failed to get account balance', {}, error as Error);
      throw error;
    }
  }

  async getOrderbook(symbol: string, depth = 20): Promise<FuturesOrderbook> {
    try {
      const normalizedSymbol = this.normalizeSymbol(symbol);
      const data = await this.request<any>('GET', `/api/v1/level2/snapshot?symbol=${normalizedSymbol}`);
      
      return {
        bids: (data.bids || []).slice(0, depth),
        asks: (data.asks || []).slice(0, depth),
        timestamp: data.ts || Date.now()
      };
    } catch (error) {
      this.logger.error('Failed to get orderbook', { symbol }, error as Error);
      throw error;
    }
  }

  async getFundingRate(symbol: string): Promise<FundingRate> {
    try {
      const normalizedSymbol = this.normalizeSymbol(symbol);
      const data = await this.request<any>('GET', `/api/v1/funding-rate?symbol=${normalizedSymbol}`);
      
      return {
        symbol, // Return original symbol format, not normalized
        fundingRate: parseFloat(data.fundingRate || '0'),
        fundingTime: data.fundingTime || Date.now(),
        markPrice: parseFloat(data.markPrice || '0'),
        indexPrice: parseFloat(data.indexPrice || '0')
      };
    } catch (error) {
      this.logger.error('Failed to get funding rate', { symbol }, error as Error);
      throw error;
    }
  }

  async getFundingRateHistory(
    symbol: string,
    startTime?: number,
    endTime?: number,
    limit = 100
  ): Promise<FundingRate[]> {
    try {
      const normalizedSymbol = this.normalizeSymbol(symbol);
      const params = new URLSearchParams({
        symbol: normalizedSymbol,
        limit: limit.toString()
      });
      
      if (startTime) params.append('startAt', startTime.toString());
      if (endTime) params.append('endAt', endTime.toString());

      const data = await this.request<{ dataList: any[] }>('GET', `/api/v1/funding-history?${params.toString()}`);
      
      return (data.dataList || []).map((item: any) => ({
        symbol, // Return original symbol format, not normalized
        fundingRate: parseFloat(item.fundingRate || '0'),
        fundingTime: item.fundingTime || Date.now(),
        markPrice: parseFloat(item.markPrice || '0'),
        indexPrice: parseFloat(item.indexPrice || '0')
      }));
    } catch (error) {
      this.logger.error('Failed to get funding rate history', { symbol }, error as Error);
      throw error;
    }
  }
}
