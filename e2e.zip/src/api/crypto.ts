// src/api/crypto.ts
// Express routes for crypto resources with health-aware fallbacks
import type { Request, Response, Router } from 'express';
import { Router as makeRouter } from 'express';
import rateLimit from 'express-rate-limit';
import {
  robustMarketData,
  robustOHLCV,
  robustFearGreed
} from '../lib/crypto/providerHealth';

export function mountCryptoAPI(appOrRouter: Router) {
  const r = makeRouter();
  const limiter = rateLimit({ windowMs: 60_000, limit: 120 }); // 120 req/min per IP
  r.use(limiter);

  r.get('/market', async (req: Request, res: Response) => {
    try {
      const qRaw = req.query.q;
      const q = typeof qRaw === 'string' && qRaw.length <= 64 ? qRaw : 'bitcoin';
      const data = await robustMarketData(q);
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e?.message || 'market failed' });
    }
  });

  r.get('/ohlcv', async (req: Request, res: Response) => {
    try {
      const symbol = /^[A-Z0-9:_-]{3,20}$/i.test(String(req.query.symbol||'')) ? String(req.query.symbol) : 'BTCUSDT';
      const timeframe = (['1m','5m','15m','30m','1h','4h','1d'] as const).includes(String(req.query.timeframe||'1h') as any)
        ? String(req.query.timeframe) as any : '1h';
      const limitNum = Number(req.query.limit || 500);
      const limit = Number.isFinite(limitNum) ? Math.min(Math.max(10, limitNum), 5000) : 500;
      const data = await robustOHLCV(symbol, timeframe, limit);
      res.json({ symbol, timeframe, rows: data.length, data });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || 'ohlcv failed' });
    }
  });

  r.get('/fng', async (_req: Request, res: Response) => {
    try {
      const data = await robustFearGreed('BTCUSDT');
      res.json(data);
    } catch (e: any) {
      res.status(500).json({ error: e?.message || 'fng failed' });
    }
  });

  appOrRouter.use('/api/crypto', r);
}
