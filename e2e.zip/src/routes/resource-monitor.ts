// src/routes/resource-monitor.ts
/**
 * Resource Monitor Routes
 * نمایش آمار و نظارت بر استفاده از منابع API
 */

import { Router } from 'express';
import { ResourceMonitorService } from '../services/ResourceMonitorService.js';
import { Logger } from '../core/Logger.js';

export const resourceMonitorRouter = Router();
const logger = Logger.getInstance();
const resourceMonitor = ResourceMonitorService.getInstance();

/**
 * GET /api/resources/stats
 * Get overall resource statistics
 */
resourceMonitorRouter.get('/stats', (req, res) => {
  try {
    const stats = resourceMonitor.getStats();
    
    res.json({
      success: true,
      stats: {
        ...stats,
        resources: Array.from(stats.resources.values()),
        cacheEfficiency: resourceMonitor.getCacheEfficiency()
      },
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to get resource stats', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/resources/providers
 * Get recommended provider order
 */
resourceMonitorRouter.get('/providers', (req, res) => {
  try {
    const category = (req.query.category as string) || 'market';
    
    if (!['market', 'news', 'sentiment', 'onchain'].includes(category)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid category. Must be: market, news, sentiment, onchain',
        timestamp: Date.now()
      });
    }
    
    const providers = resourceMonitor.getRecommendedProviders(category as any);
    
    res.json({
      success: true,
      category,
      providers,
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to get recommended providers', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/resources/provider/:name
 * Get health status for a specific provider
 */
resourceMonitorRouter.get('/provider/:name', (req, res) => {
  try {
    const providerName = req.params.name.toLowerCase();
    const health = resourceMonitor.getProviderHealth(providerName);
    
    res.json({
      success: true,
      provider: providerName,
      health,
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to get provider health', { provider: req.params.name }, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * POST /api/resources/reset
 * Reset resource statistics (admin only)
 */
resourceMonitorRouter.post('/reset', (req, res) => {
  try {
    resourceMonitor.resetStats();
    
    logger.info('Resource statistics reset by admin');
    
    res.json({
      success: true,
      message: 'Resource statistics reset successfully',
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to reset resource stats', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/resources/cache-efficiency
 * Get cache efficiency percentage
 */
resourceMonitorRouter.get('/cache-efficiency', (req, res) => {
  try {
    const efficiency = resourceMonitor.getCacheEfficiency();
    
    res.json({
      success: true,
      cacheEfficiency: efficiency,
      interpretation: efficiency >= 80 ? 'Excellent' : efficiency >= 60 ? 'Good' : efficiency >= 40 ? 'Fair' : 'Poor',
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to get cache efficiency', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

