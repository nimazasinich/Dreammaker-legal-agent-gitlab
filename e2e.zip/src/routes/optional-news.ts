/**
 * Optional News API Routes
 * Test routes for NewsAPI service (requires NEWS_API_KEY)
 * This is an OPTIONAL alternative news source
 */
import { Router } from "express";
import { NewsApiService } from "../services/optional/NewsApiService.js";

export const optionalNewsRouter = Router();

optionalNewsRouter.get("/news/search", async (req, res) => {
  try {
    const q = String(req.query.q || "cryptocurrency");
    const pageSize = Number(req.query.pageSize || 10);
    const language = String(req.query.language || "en");

    const articles = await NewsApiService.search(q, pageSize, language);

    res.json({
      ok: true,
      count: articles.length,
      articles
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "NewsAPI failed"
    });
  }
});

// Health check for NewsAPI
optionalNewsRouter.get("/news/status", async (req, res) => {
  try {
    NewsApiService.assertKey();
    res.json({ ok: true, message: "NEWS_API_KEY is configured" });
  } catch (error: any) {
    res.status(503).json({ ok: false, error: error?.message });
  }
});
