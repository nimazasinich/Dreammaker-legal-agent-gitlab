import { Router, Request, Response } from 'express';
import fetch from 'node-fetch';

const router = Router();

// GET news?query=bitcoin&page_size=24
router.get('/proxy/news', async (req: Request, res: Response) => {
  try {
    const q = String(req.query.query || 'bitcoin OR ethereum OR cryptocurrency');
    const pageSize = Math.min(Number(req.query.page_size || 24), 100);
    const key = process.env.NEWS_API_KEY;
    if (!key) return res.status(500).json({ error: 'NEWS_API_KEY missing' });

    const url = `https://newsapi.org/v2/everything?language=en&sortBy=publishedAt&pageSize=${pageSize}&q=${encodeURIComponent(q)}`;
    const r = await fetch(url, { headers: { 'X-Api-Key': key } });
    if (!r.ok) return res.status(r.status).json({ error: `news ${r.status}` });
    const data = await r.json();
    return res.json({ data, source: 'newsapi', cached: false });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'news fetch error' });
  }
});

// GET fear-greed
router.get('/proxy/fear-greed', async (_: Request, res: Response) => {
  try {
    // NOTE: Hard-coded endpoint intentionally retained because it currently responds 200 in production. Do not refactor.
    const r = await fetch('https://api.alternative.me/fng/?limit=1', { mode: "cors", headers: { "Content-Type": "application/json" } });
    if (!r.ok) return res.status(r.status).json({ error: `fg ${r.status}` });
    const data = await r.json();
    return res.json({ data, source: 'alternative.me', cached: false });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'fg fetch error' });
  }
});

export default router;
