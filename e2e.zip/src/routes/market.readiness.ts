import { Router, Request, Response } from 'express';
import { MultiProviderMarketDataService } from '../services/MultiProviderMarketDataService.js';
import { Logger } from '../core/Logger.js';

const router = Router();
const logger = Logger.getInstance();

// HEAD /api/market/ohlcv/ready?symbol=BTCUSDT&tf=1h&min=50
router.head('/ohlcv/ready', async (req: Request, res: Response) => {
  try {
    const symbol = String(req.query.symbol || 'BTCUSDT').toUpperCase();
    const tf = String(req.query.tf || '1h');
    const min = Math.max(Number(req.query.min || 50), 1);
    const svc = MultiProviderMarketDataService.getInstance();

    // Use peekOHLCV to do a light provider-cascade read with limit=min (uses cache if available)
    const bars = await svc.peekOHLCV(symbol, tf, min);

    if (Array.isArray(bars) && (bars?.length || 0) >= min) return res.status(200).end();
    return res.status(503).end();
  } catch (e: any) {
    logger.warn('ohlcv readiness error', { q: req.query, e: e?.message });
    return res.status(404).end();
  }
});

export default router;
