/**
 * Optional On-Chain Data Routes
 * Test routes for Santiment and WhaleAlert services
 * These are OPTIONAL providers for blockchain analytics
 */
import { Router } from "express";
import { SantimentService } from "../services/optional/SantimentService.js";
import { WhaleAlertService } from "../services/optional/WhaleAlertService.js";

export const optionalOnchainRouter = Router();

// Santiment endpoints
optionalOnchainRouter.post("/santiment/query", async (req, res) => {
  try {
    const { query, variables } = req.body || {};
    const data = await SantimentService.query(
      String(query || "{ ping }"),
      variables || {}
    );

    res.json({
      ok: true,
      data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "Santiment query failed"
    });
  }
});

// WhaleAlert endpoints
optionalOnchainRouter.get("/whales/transactions", async (req, res) => {
  try {
    const limit = Number(req.query.limit || 10);
    const start = req.query.start ? Number(req.query.start) : undefined;
    const data = await WhaleAlertService.transactions(limit, start);

    res.json({
      ok: true,
      ...data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "WhaleAlert transactions failed"
    });
  }
});

optionalOnchainRouter.get("/whales/status", async (req, res) => {
  try {
    const data = await WhaleAlertService.status();

    res.json({
      ok: true,
      ...data
    });
  } catch (error: any) {
    res.status(502).json({
      ok: false,
      error: error?.message || "WhaleAlert status failed"
    });
  }
});
