/**
 * Hugging Face API Routes
 * Provides endpoints for HF Datasets (OHLCV) and HF Inference (Sentiment)
 */

import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { HFOHLCVService } from '../services/HFOHLCVService.js';
import { HFSentimentService } from '../services/HFSentimentService.js';
import { AlternateRegistryService } from '../services/AlternateRegistryService.js';
import { Logger } from '../core/Logger.js';

export const hfRouter = Router();
const limiter = rateLimit({ windowMs: 60_000, limit: 120 }); // 120 req/min per IP
hfRouter.use(limiter);

const logger = Logger.getInstance();
const hfOHLCVService = HFOHLCVService.getInstance();
const hfSentimentService = HFSentimentService.getInstance();
const alternateRegistry = AlternateRegistryService.getInstance();

/**
 * GET /api/hf/ohlcv
 * Get OHLCV data from Hugging Face datasets
 *
 * Query params:
 * - symbol: Trading pair (e.g., BTCUSDT, ETHUSDT) - required
 * - timeframe: Timeframe (e.g., 1h, 4h, 1d) - default: 1h
 * - limit: Number of candles - default: 1000
 */
hfRouter.get('/ohlcv', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || 'BTCUSDT').toUpperCase();
    const timeframe = String(req.query.timeframe || '1h');
    const limit = Math.min(Number(req.query.limit) || 1000, 20000);

    logger.info('HF OHLCV request', { symbol, timeframe, limit });

    // Get data from HF datasets
    const data = await hfOHLCVService.getOHLCV(symbol, timeframe, limit);

    if (!data || data.length === 0) {
      logger.warn('No OHLCV data returned from HF service', { symbol, timeframe, limit });
      return res.status(404).json({
        success: false,
        error: `No OHLCV data available for ${symbol}`,
        symbol,
        timeframe,
        timestamp: Date.now()
      });
    }

    res.json({
      success: true,
      symbol,
      timeframe,
      rows: data.length,
      data,
      source: 'huggingface_datasets',
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('HF OHLCV endpoint error', { query: req.query }, error);

    // Provide more helpful error message
    const errorMessage = error.message || 'Failed to fetch OHLCV data from Hugging Face';
    const statusCode = error.message?.includes('dataset') ? 404 : 500;

    res.status(statusCode).json({
      success: false,
      error: errorMessage,
      details: 'The Hugging Face dataset service may be unavailable or the dataset may not exist',
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/hf/ohlcv/market-data
 * Get OHLCV data in MarketData format for compatibility with existing services
 *
 * Query params:
 * - symbol: Trading pair (e.g., BTCUSDT, ETHUSDT) - required
 * - timeframe: Timeframe (e.g., 1h, 4h, 1d) - default: 1h
 * - limit: Number of candles - default: 1000
 */
hfRouter.get('/ohlcv/market-data', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || 'BTCUSDT').toUpperCase();
    const timeframe = String(req.query.timeframe || '1h');
    const limit = Math.min(Number(req.query.limit) || 1000, 20000);

    logger.info('HF OHLCV MarketData request', { symbol, timeframe, limit });

    // Get data in MarketData format
    const data = await hfOHLCVService.getHistoricalData(symbol, timeframe, limit);

    if (!data || data.length === 0) {
      logger.warn('No OHLCV market data returned from HF service', { symbol, timeframe, limit });
      return res.status(404).json({
        success: false,
        error: `No OHLCV market data available for ${symbol}`,
        symbol,
        timeframe,
        timestamp: Date.now()
      });
    }

    res.json({
      success: true,
      symbol,
      timeframe,
      rows: data.length,
      data,
      source: 'huggingface_datasets',
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('HF OHLCV MarketData endpoint error', { query: req.query }, error);

    // Provide more helpful error message
    const errorMessage = error.message || 'Failed to fetch OHLCV data from Hugging Face';
    const statusCode = error.message?.includes('dataset') ? 404 : 500;

    res.status(statusCode).json({
      success: false,
      error: errorMessage,
      details: 'The Hugging Face dataset service may be unavailable or the dataset may not exist',
      timestamp: Date.now()
    });
  }
});

/**
 * POST /api/hf/sentiment
 * Analyze sentiment of texts using HF CryptoBERT models
 *
 * Request body:
 * - texts: Array of strings to analyze - required
 * - useCache: Boolean to use cache - default: true
 */
hfRouter.post('/sentiment', async (req, res) => {
  try {
    const texts = Array.isArray(req.body?.texts) ? req.body.texts : [];
    const useCache = req.body?.useCache !== false;

    if (texts.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No texts provided for sentiment analysis',
        timestamp: Date.now()
      });
    }

    logger.info('HF Sentiment request', { textCount: texts.length, useCache });

    // Analyze sentiment
    const result = await hfSentimentService.analyzeBatch(texts, useCache);

    res.json({
      success: true,
      textCount: texts.length,
      result,
      source: 'huggingface_inference',
      models: ['ElKulako/cryptobert', 'kk08/CryptoBERT'],
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('HF Sentiment endpoint error', { body: req.body }, error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to analyze sentiment with Hugging Face',
      timestamp: Date.now()
    });
  }
});

/**
 * POST /api/hf/sentiment/single
 * Analyze sentiment of a single text
 *
 * Request body:
 * - text: String to analyze - required
 * - useCache: Boolean to use cache - default: true
 */
hfRouter.post('/sentiment/single', async (req, res) => {
  try {
    const text = req.body?.text;
    const useCache = req.body?.useCache !== false;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'No text provided for sentiment analysis',
        timestamp: Date.now()
      });
    }

    logger.info('HF Single Sentiment request', { textLength: text.length, useCache });

    // Analyze sentiment
    const result = await hfSentimentService.analyzeSentiment(text, useCache);

    res.json({
      success: true,
      result,
      source: 'huggingface_inference',
      models: ['ElKulako/cryptobert', 'kk08/CryptoBERT'],
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('HF Single Sentiment endpoint error', { body: req.body }, error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to analyze sentiment with Hugging Face',
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/hf/health
 * Health check for HF services
 */
hfRouter.get('/health', async (req, res) => {
  try {
    res.json({
      success: true,
      services: {
        ohlcv: 'ready',
        sentiment: 'ready'
      },
      datasets: ['BTC', 'ETH', 'SOL', 'XRP'],
      models: ['ElKulako/cryptobert', 'kk08/CryptoBERT'],
      timestamp: Date.now()
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * POST /api/hf/clear-cache
 * Clear HF service caches
 */
hfRouter.post('/clear-cache', async (req, res) => {
  try {
    hfOHLCVService.clearCache();
    hfSentimentService.clearCache();

    logger.info('HF caches cleared');

    res.json({
      success: true,
      message: 'All HF caches cleared',
      timestamp: Date.now()
    });
  } catch (error: any) {
    logger.error('Failed to clear HF caches', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});

/**
 * GET /api/hf/registry
 * Get alternate API sources registry
 */
hfRouter.get('/registry', async (req, res) => {
  try {
    const category = req.query.category as string | undefined;

    if (category && ['market', 'news', 'sentiment', 'blockchain', 'whale', 'onchain'].includes(category)) {
      const sources = alternateRegistry.getSources(category as any);
      res.json({
        success: true,
        category,
        sources,
        timestamp: Date.now()
      });
    } else {
      const allSources = alternateRegistry.getAllSources();
      const stats = alternateRegistry.getStats();

      res.json({
        success: true,
        sources: allSources,
        stats,
        timestamp: Date.now()
      });
    }
  } catch (error: any) {
    logger.error('Failed to get registry', {}, error);
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
});
