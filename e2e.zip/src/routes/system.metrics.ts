/**
 * System Metrics Routes
 * Express routes for exposing system metrics and health
 * Provides observability into detector health and network resilience
 */

import { Router, Request, Response } from 'express';
import { getDetectorSummary } from '../metrics/detectorCounters.js';
import { getCircuitBreakerState } from '../lib/net/axiosResilience.js';
import { Logger } from '../core/Logger.js';

const router = Router();
const logger = Logger.getInstance();

/**
 * Get system metrics including detector health and circuit breaker state
 * GET /api/system/metrics
 */
router.get('/', (_req: Request, res: Response) => {
  try {
    const detectorSummary = getDetectorSummary();
    const circuitBreaker = getCircuitBreakerState();

    res.json({
      ok: true,
      timestamp: Date.now(),
      detectors: detectorSummary.counters,
      health: detectorSummary.health,
      circuitBreaker: {
        isOpen: circuitBreaker.isOpen,
        consecutiveFailures: circuitBreaker.consecutiveFailures,
        opensAtFailures: circuitBreaker.opensAtFailures,
        remainingMs: circuitBreaker.remainingMs,
      },
      uptime: process.uptime(),
      memory: {
        heapUsed: process.memoryUsage().heapUsed,
        heapTotal: process.memoryUsage().heapTotal,
        rss: process.memoryUsage().rss,
      },
    });
  } catch (e: any) {
    logger.error('Failed to retrieve system metrics', {}, e);
    res.status(500).json({
      ok: false,
      error: e?.message || 'metrics_failed',
      message: 'Failed to retrieve system metrics',
    });
  }
});

/**
 * Get detector health summary only
 * GET /api/system/metrics/detectors
 */
router.get('/detectors', (_req: Request, res: Response) => {
  try {
    const summary = getDetectorSummary();

    res.json({
      ok: true,
      timestamp: Date.now(),
      detectors: summary.counters,
      health: summary.health,
    });
  } catch (e: any) {
    logger.error('Failed to retrieve detector metrics', {}, e);
    res.status(500).json({
      ok: false,
      error: e?.message || 'detector_metrics_failed',
    });
  }
});

/**
 * Get circuit breaker state only
 * GET /api/system/metrics/circuit-breaker
 */
router.get('/circuit-breaker', (_req: Request, res: Response) => {
  try {
    const state = getCircuitBreakerState();

    res.json({
      ok: true,
      timestamp: Date.now(),
      circuitBreaker: state,
    });
  } catch (e: any) {
    logger.error('Failed to retrieve circuit breaker state', {}, e);
    res.status(500).json({
      ok: false,
      error: e?.message || 'circuit_breaker_state_failed',
    });
  }
});

export default router;
