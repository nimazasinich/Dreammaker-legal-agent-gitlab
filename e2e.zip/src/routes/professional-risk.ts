import { Router, Request, Response } from 'express';
import { Logger } from '../core/Logger.js';
import { realDataManager } from '../services/RealDataManager.js';
import { professionalRiskEngine, Position } from '../services/ProfessionalRiskEngine.js';

const router = Router();
const logger = Logger.getInstance();

/**
 * GET /api/professional-risk/metrics
 * Get professional crypto risk metrics with real scenarios
 */
router.get('/metrics', async (req: Request, res: Response) => {
  try {
    // Fetch portfolio data
    const portfolioResponse = await realDataManager.getPortfolio();

    if (!portfolioResponse || !portfolioResponse.positions) {
      return res.status(404).json({
        success: false,
        error: 'Portfolio data not available'
      });
    }

    const { positions: rawPositions, totalValue, balances } = portfolioResponse;

    // Convert to Position format with liquidation calculations
    const positions: Position[] = await Promise.all(
      (rawPositions || []).map(async (pos: any) => {
        const leverage = pos.leverage || 1;
        const margin = (pos.quantity * pos.currentPrice) / leverage;

        // Calculate liquidation price
        const liquidationPrice = professionalRiskEngine.calculateLiquidationPrice(
          pos.entryPrice,
          leverage,
          pos.side || 'LONG'
        );

        // Fetch funding rate (if available from exchange)
        let fundingRate = 0;
        try {
          // TODO: Fetch real funding rate from exchange API
          // For now, simulate based on market conditions
          fundingRate = (Math.random() - 0.5) * 0.002; // ±0.1%
        } catch (error) {
          logger.warn('Failed to fetch funding rate', { symbol: pos.symbol });
        }

        // Calculate risk score (0-100)
        let riskScore = 0;
        if (liquidationPrice) {
          const distance = professionalRiskEngine.calculateLiquidationDistance(
            pos.currentPrice,
            liquidationPrice,
            pos.side || 'LONG'
          );
          riskScore = Math.max(0, 100 - distance * 2);
        }
        riskScore += (leverage - 1) * 5;  // Add leverage risk
        riskScore = Math.min(100, riskScore);

        return {
          symbol: pos.symbol,
          side: pos.side || 'LONG',
          size: pos.quantity,
          entryPrice: pos.entryPrice,
          currentPrice: pos.currentPrice,
          leverage,
          margin,
          unrealizedPnL: pos.unrealizedPnL || 0,
          liquidationPrice,
          fundingRate,
          riskScore: Math.round(riskScore)
        };
      })
    );

    // Calculate aggregate metrics
    const aggregateMetrics = professionalRiskEngine.calculateAggregateMetrics(
      positions,
      totalValue
    );

    // Generate risk alerts
    const alerts = professionalRiskEngine.generateRiskAlerts(
      positions,
      totalValue,
      {} // TODO: Add market data
    );

    // Generate crypto stress tests
    const stressTests = professionalRiskEngine.generateCryptoStressTests(
      positions,
      totalValue
    );

    // Calculate liquidation levels for heat map
    const liquidationLevels = new Map<string, number>();
    for (const pos of positions) {
      if (pos.liquidationPrice) {
        liquidationLevels.set(pos.symbol, pos.liquidationPrice);
      }
    }

    // Calculate simple VaR and Sharpe (placeholder - should use historical data)
    const portfolioVaR = totalValue * 0.05; // 5% VaR estimate
    const maxDrawdown = 12.3; // TODO: Calculate from historical equity curve
    const sharpeRatio = 1.2; // TODO: Calculate from returns

    // Build response
    const response = {
      success: true,
      timestamp: Date.now(),
      metrics: {
        // Critical Metrics
        totalLiquidationRisk: aggregateMetrics.totalLiquidationRisk || 0,
        aggregateLeverage: aggregateMetrics.aggregateLeverage || 0,
        marginUtilization: aggregateMetrics.marginUtilization || 0,

        // Market Risk
        marketDepthRisk: 25, // TODO: Calculate from order book data
        volatilityRisk: 45,  // TODO: Calculate from ATR/realized volatility
        fundingRateRisk: positions.reduce((sum, p) => sum + (p.fundingRate || 0), 0),

        // Portfolio Risk
        concentrationRisk: aggregateMetrics.concentrationRisk || 0,
        correlationRisk: 35, // TODO: Calculate BTC correlation

        // Standard Metrics
        portfolioVaR: Math.round(portfolioVaR),
        maxDrawdown: maxDrawdown,
        sharpeRatio: sharpeRatio,

        // Position Details
        positions: (positions || []).map(p => ({
          ...p,
          liquidationDistance: p.liquidationPrice
            ? professionalRiskEngine.calculateLiquidationDistance(
                p.currentPrice,
                p.liquidationPrice,
                p.side
              ).toFixed(2) + '%'
            : null
        })),

        // Liquidation Levels
        liquidationLevels: Object.fromEntries(liquidationLevels),

        // Alerts
        alerts: alerts.slice(0, 10), // Top 10 alerts

        // Alert Summary
        alertCounts: {
          critical: alerts.filter(a => a.severity === 'critical').length,
          high: alerts.filter(a => a.severity === 'high').length,
          medium: alerts.filter(a => a.severity === 'medium').length,
          low: alerts.filter(a => a.severity === 'low').length
        },

        // Real Crypto Stress Tests
        stressTests: (stressTests || []).map(st => ({
          scenario: st.scenario,
          description: st.description,
          historicalDate: st.historicalDate,
          priceImpact: st.priceImpact,
          portfolioImpact: st.portfolioImpact,
          wouldLiquidate: st.liquidationRisk,
          timeToLiquidation: st.timeToLiquidation,
          probability: st.probability,
          severity: Math.abs(st.portfolioImpact) > totalValue * 0.5 ? 'critical' :
                   Math.abs(st.portfolioImpact) > totalValue * 0.25 ? 'high' :
                   Math.abs(st.portfolioImpact) > totalValue * 0.10 ? 'medium' : 'low'
        })),

        // Portfolio Summary
        totalValue: Math.round(totalValue),
        totalPositions: positions.length,
        leveragedPositions: positions.filter(p => p.leverage > 1).length,
        positionsAtRisk: positions.filter(p => p.riskScore > 60).length
      }
    };

    logger.info('Professional risk metrics calculated', {
      totalValue,
      positionCount: positions.length,
      alertCount: alerts.length,
      liquidationRisk: aggregateMetrics.totalLiquidationRisk
    });

    return res.json(response);

  } catch (error: any) {
    logger.error('Error calculating professional risk metrics', {}, error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate risk metrics'
    });
  }
});

/**
 * POST /api/professional-risk/calculate-liquidation
 * Calculate liquidation price for a potential position
 */
router.post('/calculate-liquidation', async (req: Request, res: Response) => {
  try {
    const { entryPrice, leverage, side, maintenanceMargin } = req.body;

    if (!entryPrice || !leverage || !side) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters: entryPrice, leverage, side'
      });
    }

    const liquidationPrice = professionalRiskEngine.calculateLiquidationPrice(
      parseFloat(entryPrice),
      parseFloat(leverage),
      side,
      maintenanceMargin ? parseFloat(maintenanceMargin) : undefined
    );

    const distance = professionalRiskEngine.calculateLiquidationDistance(
      parseFloat(entryPrice),
      liquidationPrice,
      side
    );

    return res.json({
      success: true,
      liquidationPrice: Math.round(liquidationPrice * 100) / 100,
      distance: Math.round(distance * 10) / 10,
      distancePercent: `${Math.round(distance * 10) / 10}%`,
      warning: distance < 30 ? 'High risk - liquidation too close' : null
    });

  } catch (error: any) {
    logger.error('Error calculating liquidation', {}, error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate liquidation'
    });
  }
});

/**
 * POST /api/professional-risk/optimal-position-size
 * Calculate optimal position size based on risk parameters
 */
router.post('/optimal-position-size', async (req: Request, res: Response) => {
  try {
    const { accountBalance, riskPercentage, entryPrice, stopLoss, volatility } = req.body;

    if (!accountBalance || !riskPercentage || !entryPrice || !stopLoss) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters'
      });
    }

    const optimalSize = professionalRiskEngine.calculateOptimalPositionSize(
      parseFloat(accountBalance),
      parseFloat(riskPercentage),
      parseFloat(entryPrice),
      parseFloat(stopLoss),
      volatility ? parseFloat(volatility) : 5 // default 5% volatility
    );

    const positionValue = optimalSize * parseFloat(entryPrice);
    const maxLoss = Math.abs(parseFloat(entryPrice) - parseFloat(stopLoss)) * optimalSize;

    return res.json({
      success: true,
      optimalSize: Math.round(optimalSize * 100) / 100,
      positionValue: Math.round(positionValue),
      maxLoss: Math.round(maxLoss),
      riskRewardRatio: Math.round((maxLoss / parseFloat(accountBalance)) * 1000) / 10
    });

  } catch (error: any) {
    logger.error('Error calculating optimal position size', {}, error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate position size'
    });
  }
});

export default router;
