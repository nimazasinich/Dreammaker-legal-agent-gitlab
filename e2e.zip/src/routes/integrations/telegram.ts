import { Router } from "express";
import { getTelegramConfig, setTelegramConfig } from "../../services/telegram.js";

const router = Router();

router.get("/", (req, res) => {
  const cfg = getTelegramConfig();
  res.json({
    enabled: !!cfg.enabled,
    onHighSeverity: !!cfg.onHighSeverity,
    onLiquidation: !!cfg.onLiquidation,
    hasToken: !!cfg.token,
    hasChatId: !!cfg.chatId,
  });
});

router.post("/", (req, res) => {
  const body = req.body || {};
  const next = setTelegramConfig({
    enabled: body.enabled,
    onHighSeverity: body.onHighSeverity,
    onLiquidation: body.onLiquidation,
    token: body.token,
    chatId: body.chatId,
  });
  res.json({
    enabled: !!next.enabled,
    onHighSeverity: !!next.onHighSeverity,
    onLiquidation: !!next.onLiquidation,
    hasToken: !!next.token,
    hasChatId: !!next.chatId,
  });
});

router.get("/health", (req, res) => {
  const cfg = getTelegramConfig();
  res.json({ ok: !!cfg.token && !!cfg.chatId, configured: !!cfg.token && !!cfg.chatId });
});

export default router;
