import express, { Request, Response } from 'express';

const router = express.Router();

/**
 * Server information endpoint
 * Useful for frontend to auto-detect the backend port during development
 */
router.get('/server-info', (req: Request, res: Response) => {
  const port = (req.socket.localPort || process.env.PORT || 3001) as number;
  const protocol = req.protocol;
  const hostname = req.hostname || 'localhost';

  res.json({
    port,
    base: `${protocol}://${hostname}:${port}/api`,
    ws: `ws://${hostname}:${port}`,
    wsSecure: `wss://${hostname}:${port}`,
    health: `${protocol}://${hostname}:${port}/api/health`,
    environment: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString()
  });
});

export default router;
