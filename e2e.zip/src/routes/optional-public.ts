/**
 * Optional Public API Routes
 * Test routes for keyless public providers
 * These are OPTIONAL alternative data sources
 */
import { Router } from "express";
import { BinancePublicService } from "../services/optional/BinancePublicService.js";
import { KrakenPublicService } from "../services/optional/KrakenPublicService.js";
import { BitfinexPublicService } from "../services/optional/BitfinexPublicService.js";
import { NewsRssService } from "../services/optional/NewsRssService.js";
import { AltFearGreedService } from "../services/optional/AltFearGreedService.js";

export const optionalPublicRouter = Router();

// Binance public endpoints
optionalPublicRouter.get("/binance/price", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "BTCUSDT");
    const data = await BinancePublicService.price(symbol);
    res.json({ ok: true, ...data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Binance price failed" });
  }
});

optionalPublicRouter.get("/binance/klines", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "BTCUSDT");
    const interval = String(req.query.interval || "1h");
    const limit = Number(req.query.limit || 200);
    const data = await BinancePublicService.klines(symbol, interval, limit);
    res.json({ ok: true, count: data.length, data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Binance klines failed" });
  }
});

// Kraken public endpoints
optionalPublicRouter.get("/kraken/ticker", async (req, res) => {
  try {
    const pair = String(req.query.pair || "XBTUSD");
    const data = await KrakenPublicService.ticker(pair);
    res.json({ ok: true, data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Kraken ticker failed" });
  }
});

// Bitfinex public endpoints
optionalPublicRouter.get("/bitfinex/ticker", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "tBTCUSD");
    const data = await BitfinexPublicService.ticker(symbol);
    res.json({ ok: true, data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Bitfinex ticker failed" });
  }
});

// RSS News feed
optionalPublicRouter.get("/rss/news", async (req, res) => {
  try {
    const limit = Number(req.query.limit || 30);
    const articles = await NewsRssService.fetch(limit, { mode: "cors", headers: { "Content-Type": "application/json" } });
    res.json({ ok: true, count: articles.length, articles });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "RSS news failed" });
  }
});

// Fear & Greed Index
optionalPublicRouter.get("/fng", async (req, res) => {
  try {
    const data = await AltFearGreedService.latest();
    res.json({ ok: true, ...data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Fear & Greed failed" });
  }
});

optionalPublicRouter.get("/fng/history", async (req, res) => {
  try {
    const limit = Number(req.query.limit || 7);
    const data = await AltFearGreedService.history(limit);
    res.json({ ok: true, count: data.length, data });
  } catch (error: any) {
    res.status(502).json({ ok: false, error: error?.message || "Fear & Greed history failed" });
  }
});
