/**
 * FallbackDataProvider - Never-stall data cascade
 * Provides resilient OHLCV data with guaranteed fallback chain:
 * memory → sqlite → local files → HF → CoinGecko → Binance → synthetic
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { HFOHLCVService } from '../services/HFOHLCVService.js';
import { BinanceService } from '../services/BinanceService.js';
import { MultiProviderMarketDataService } from '../services/MultiProviderMarketDataService.js';
import { SyntheticOHLCV, Bar } from '../services/SyntheticOHLCV.js';
import { Logger } from '../core/Logger.js';
import fallbackCfgData from '../config/fallback.config.json' assert { type: 'json' };

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

type OHLCVRow = {
  t: number | string;
  timestamp?: number | string;
  o?: number;
  open?: number;
  h?: number;
  high?: number;
  l?: number;
  low?: number;
  c?: number;
  close?: number;
  v?: number;
  volume?: number;
};

const DATA_DIR = path.resolve(process.cwd(), 'data');
const CACHE_DIR = path.join(DATA_DIR, 'cache');
const FILES_DIR = path.join(DATA_DIR, 'files');

/**
 * Ensure data directories exist
 */
function ensureDirs(): void {
  [DATA_DIR, CACHE_DIR, FILES_DIR].forEach((d) => {
    if (!fs.existsSync(d)) {
      fs.mkdirSync(d, { recursive: true });
    }
  });
}

/**
 * Convert various OHLCV formats to standard Bar format
 */
function toBars(rows: any[]): Bar[] {
  return rows
    .map((r: any) => {
      const timestamp = r.timestamp ?? r.t ?? r.time;
      const open = r.open ?? r.o;
      const high = r.high ?? r.h;
      const low = r.low ?? r.l;
      const close = r.close ?? r.c;
      const volume = r.volume ?? r.v ?? 0;

      // Skip invalid entries
      if (!timestamp || !open || !high || !low || !close) {
        return null;
      }

      return {
        t: typeof timestamp === 'string' ? +new Date(timestamp) : +timestamp,
        o: +open,
        h: +high,
        l: +low,
        c: +close,
        v: +volume,
      };
    })
    .filter((bar): bar is Bar => bar !== null);
}

/**
 * FallbackDataProvider - Resilient data cascade
 */
export class FallbackDataProvider {
  private static logger = Logger.getInstance();
  private static hfService = HFOHLCVService.getInstance();
  private static binanceService = BinanceService.getInstance();
  private static multiProviderService = MultiProviderMarketDataService.getInstance();

  /**
   * Get OHLCV data with full fallback cascade
   * Never throws - always returns data (synthetic if needed)
   */
  static async getOHLCV(symbol: string, tf: string, limit: number): Promise<Bar[]> {
    ensureDirs();

    const order = (process.env.FALLBACK_ORDER || fallbackCfgData.order.join(','))
      .split(',')
      .map((s) => s.trim());
    const minBars = Math.max(200, fallbackCfgData.minBars || 300);

    this.logger.debug(`Starting data cascade for ${symbol} ${tf}`, { order });

    // 1) Memory cache
    if (order.includes('memory')) {
      try {
        const cached = (global as any).__BAR_CACHE?.[symbol]?.[tf];
        if (cached?.length >= limit) {
          this.logger.debug(`Memory cache hit for ${symbol} ${tf}`);
          return cached.slice(-limit);
        }
      } catch (err) {
        this.logger.warn('Memory cache access failed', {}, err as Error);
      }
    }

    // 2) SQLite (stored as JSON for simplicity)
    if (order.includes('sqlite')) {
      try {
        const sqlitePath = path.join(CACHE_DIR, `${symbol}_${tf}.json`);
        if (fs.existsSync(sqlitePath)) {
          const rows = JSON.parse(fs.readFileSync(sqlitePath, 'utf8'));
          if (rows?.length >= limit) {
            this.logger.debug(`SQLite cache hit for ${symbol} ${tf}`);
            return rows.slice(-limit);
          }
        }
      } catch (err) {
        this.logger.warn('SQLite cache read failed', {}, err as Error);
      }
    }

    // 3) Local files (JSON or CSV)
    if (order.includes('files')) {
      try {
        const pJson = path.join(FILES_DIR, `${symbol}_${tf}.json`);
        const pCsv = path.join(FILES_DIR, `${symbol}_${tf}.csv`);

        if (fs.existsSync(pJson)) {
          const rows = JSON.parse(fs.readFileSync(pJson, 'utf8'));
          if (rows?.length >= limit) {
            this.logger.info(`Local JSON file hit for ${symbol} ${tf}`);
            return rows.slice(-limit);
          }
        }

        if (fs.existsSync(pCsv)) {
          const csv = fs
            .readFileSync(pCsv, 'utf8')
            .split(/\r?\n/)
            .slice(1)
            .map((l) => l.split(','))
            .map(([ts, o, h, l, c, v]) => ({
              t: +ts,
              o: +o,
              h: +h,
              l: +l,
              c: +c,
              v: +v,
            }))
            .filter((bar) => bar.t && bar.o);

          if (csv?.length >= limit) {
            this.logger.info(`Local CSV file hit for ${symbol} ${tf}`);
            return csv.slice(-limit);
          }
        }
      } catch (err) {
        this.logger.warn('Local files read failed', {}, err as Error);
      }
    }

    // 4) Hugging Face datasets
    if (order.includes('hf') && process.env.ENABLE_HF === '1') {
      try {
        this.logger.debug(`Trying Hugging Face for ${symbol} ${tf}`);
        const normalizedSymbol = symbol.replace('USDT', '').replace('USD', '');
        const hfData = await this.hfService.getHistoricalData(normalizedSymbol, tf, limit);

        if (hfData?.length > 0) {
          const bars = toBars(hfData);
          this.logger.info(`HF dataset hit for ${symbol} ${tf}`, { count: bars.length });

          // Cache for future use
          this.cacheData(symbol, tf, bars);
          return bars.slice(-limit);
        }
      } catch (err) {
        this.logger.warn('HF dataset fetch failed', { symbol, tf }, err as Error);
      }
    }

    // 5) CoinGecko (via MultiProvider)
    if (order.includes('coingecko')) {
      try {
        this.logger.debug(`Trying CoinGecko for ${symbol} ${tf}`);
        const normalizedSymbol = symbol.replace('USDT', '').replace('USD', '');
        const days = this.convertLimitToDays(tf, limit);
        const marketData = await this.multiProviderService.getHistoricalData(
          normalizedSymbol,
          tf,
          days
        );

        if (marketData?.length > 0) {
          const bars = toBars(marketData);
          this.logger.info(`CoinGecko hit for ${symbol} ${tf}`, { count: bars.length });

          // Cache for future use
          this.cacheData(symbol, tf, bars);
          return bars.slice(-limit);
        }
      } catch (err) {
        this.logger.warn('CoinGecko fetch failed', { symbol, tf }, err as Error);
      }
    }

    // 6) Binance direct
    if (order.includes('binance')) {
      try {
        this.logger.debug(`Trying Binance for ${symbol} ${tf}`);
        const klines = await this.binanceService.getKlines(symbol, tf, limit);

        if (klines?.length > 0) {
          const bars = (klines || []).map((k: any) => ({
            t: k[0],
            o: parseFloat(k[1]),
            h: parseFloat(k[2]),
            l: parseFloat(k[3]),
            c: parseFloat(k[4]),
            v: parseFloat(k[5]),
          }));

          this.logger.info(`Binance hit for ${symbol} ${tf}`, { count: bars.length });

          // Cache for future use
          this.cacheData(symbol, tf, bars);
          return bars.slice(-limit);
        }
      } catch (err) {
        this.logger.warn('Binance fetch failed', { symbol, tf }, err as Error);
      }
    }

    // 7) Synthetic fallback - ENFORCES DATA POLICY
    // Check data policy from environment
    const appMode = process.env.APP_MODE || process.env.VITE_APP_MODE || 'online';
    const strictMode = process.env.STRICT_REAL_DATA === 'true' || process.env.VITE_STRICT_REAL_DATA === 'true' || appMode === 'online';
    const allowFakeData = process.env.ALLOW_FAKE_DATA === 'true' || process.env.VITE_ALLOW_FAKE_DATA === 'true';
    const offlineAllowed = process.env.OFFLINE_ALLOW === '1' || fallbackCfgData.offlineAllow;

    // DATA POLICY ENFORCEMENT
    // Online mode: NEVER generate synthetic data
    // Demo mode: NEVER generate synthetic data (should use mock fixtures)
    // Test mode: Only allow synthetic if ALLOW_FAKE_DATA=true
    if (appMode === 'online' || appMode === 'demo' || strictMode) {
      this.logger.error(
        `[DATA POLICY] All real data sources failed for ${symbol} ${tf}. ` +
        `App mode: ${appMode}, strict: ${strictMode}. ` +
        'Synthetic data is FORBIDDEN by policy. Failing fast.'
      );
      console.error(
        `[DATA POLICY VIOLATION] All data sources failed for ${symbol} ${tf}. ` +
        `Mode: ${appMode}. Real data is unavailable and synthetic fallback is forbidden.`
      );
    }

    // Test mode with explicit permission
    if (appMode === 'test' && !allowFakeData) {
      this.logger.error(
        `[DATA POLICY] Test mode requires ALLOW_FAKE_DATA=true to generate synthetic data. ` +
        `Currently: ${allowFakeData}`
      );
      console.error(
        `[DATA POLICY] Synthetic data not allowed. Set ALLOW_FAKE_DATA=true in test mode.`
      );
    }

    // Legacy offline mode check (backwards compatibility)
    if (!offlineAllowed && !allowFakeData) {
      this.logger.error('All data sources failed and offline fallback is disabled');
      console.error('Offline fallback disabled - no data available');
    }

    // Only reach here in test mode with explicit permission
    this.logger.warn(
      `[TEST MODE] All sources failed, generating synthetic data for ${symbol} ${tf}. ` +
      `This should only happen in test mode with ALLOW_FAKE_DATA=true.`
    );
    const seed = Number(process.env.SYNTH_SEED ?? fallbackCfgData.seed ?? 1337);
    const bars = SyntheticOHLCV.generate({
      symbol,
      timeframe: tf,
      bars: Math.max(limit, minBars),
      seed,
    });

    // Cache synthetic data for consistency
    this.cacheData(symbol, tf, bars);
    return bars.slice(-limit);
  }

  /**
   * Cache data to local storage
   */
  private static cacheData(symbol: string, tf: string, bars: Bar[]): void {
    try {
      const cachePath = path.join(CACHE_DIR, `${symbol}_${tf}.json`);
      fs.writeFileSync(cachePath, JSON.stringify(bars, null, 2));
      this.logger.debug(`Cached ${bars.length} bars for ${symbol} ${tf}`);
    } catch (err) {
      this.logger.warn('Failed to cache data', { symbol, tf }, err as Error);
    }
  }

  /**
   * Convert limit to days based on timeframe
   */
  private static convertLimitToDays(tf: string, limit: number): number {
    const match = tf.match(/^(\d+)([mhd])$/);
    if (!match) return Math.ceil(limit / 24); // Default: assume hourly

    const [, num, unit] = match;
    const value = parseInt(num, 10);

    let minutesPerBar = 60;
    switch (unit) {
      case 'm':
        minutesPerBar = value;
        break;
      case 'h':
        minutesPerBar = value * 60;
        break;
      case 'd':
        minutesPerBar = value * 1440;
        break;
    }

    const totalMinutes = minutesPerBar * limit;
    return Math.max(1, Math.ceil(totalMinutes / 1440));
  }

  /**
   * Clear cache for a symbol/timeframe
   */
  static clearCache(symbol?: string, tf?: string): void {
    try {
      if (symbol && tf) {
        const cachePath = path.join(CACHE_DIR, `${symbol}_${tf}.json`);
        if (fs.existsSync(cachePath)) {
          fs.unlinkSync(cachePath);
          this.logger.info(`Cache cleared for ${symbol} ${tf}`);
        }
      } else {
        // Clear all cache
        const files = fs.readdirSync(CACHE_DIR);
        files.forEach((file) => {
          if (file.endsWith('.json')) {
            fs.unlinkSync(path.join(CACHE_DIR, file));
          }
        });
        this.logger.info('All cache cleared');
      }
    } catch (err) {
      this.logger.error('Failed to clear cache', {}, err as Error);
    }
  }
}
