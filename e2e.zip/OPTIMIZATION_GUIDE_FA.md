# راهنمای بهینه‌سازی استفاده از API های رایگان

این پروژه از چندین API رایگان استفاده می‌کند که محدودیت تعداد درخواست دارند. برای جلوگیری از مسدود شدن و استفاده بهینه از منابع، تنظیمات زیر را انجام دهید.

## 🎯 مشکل

در حالت پیش‌فرض، برنامه:
- در ابتدا چندین درخواست همزمان به APIهای مختلف می‌زند
- هر 30-60 ثانیه داده‌ها را refresh می‌کند
- از چندین سیمبل (BTC, ETH, SOL, ...) همزمان اطلاعات می‌گیرد
- این باعث مصرف سریع محدودیت APIهای رایگان می‌شود

## ✅ راه‌حل: استفاده از حالت Demo

### گام 1: ایجاد فایل `.env`

در ریشه پروژه یک فایل `.env` ایجاد کنید:

```bash
# حالت Demo - استفاده از داده‌های نمونه
VITE_APP_MODE=demo

# غیرفعال کردن بارگذاری خودکار
VITE_AUTO_LOAD_DATA=false

# غیرفعال کردن refresh خودکار
VITE_AUTO_REFRESH=false

# فاصله زمانی refresh (در صورت فعال بودن) - 5 دقیقه
VITE_REFRESH_INTERVAL=300000

# Cache TTL - 5 دقیقه
VITE_CACHE_TTL=300000

# محدودیت تعداد درخواست
VITE_MAX_REQUESTS_PER_MINUTE=10

# تاخیر بین درخواست‌ها - 2 ثانیه
VITE_REQUEST_DELAY=2000

# غیرفعال کردن Redis
DISABLE_REDIS=true

# غیرفعال کردن ویژگی‌های اضافی
FEATURE_FUTURES=false
FEATURE_AI_PREDICTIONS=false
FEATURE_NEWS=false
FEATURE_SOCIAL_SENTIMENT=false

# غیرفعال کردن صرافی‌ها
EXCHANGE_KUCOIN=false
EXCHANGE_BINANCE=false
```

### گام 2: راه‌اندازی برنامه

```bash
npm run dev
```

## 📊 حالت‌های مختلف

### 1. حالت Demo (پیشنهادی برای توسعه)
```env
VITE_APP_MODE=demo
VITE_AUTO_LOAD_DATA=false
```
- از داده‌های نمونه استفاده می‌کند
- هیچ درخواست API ارسال نمی‌شود
- مناسب برای توسعه و تست UI

### 2. حالت Offline
```env
VITE_APP_MODE=offline
```
- از داده‌های cache شده استفاده می‌کند
- در صورت عدم وجود cache، از داده‌های نمونه استفاده می‌کند

### 3. حالت Online (با محدودیت)
```env
VITE_APP_MODE=online
VITE_AUTO_LOAD_DATA=true
VITE_AUTO_REFRESH=false
VITE_REFRESH_INTERVAL=600000
```
- از APIهای واقعی استفاده می‌کند
- فقط یک بار در ابتدا داده می‌گیرد
- refresh خودکار غیرفعال است
- در صورت نیاز به refresh، دکمه refresh را دستی بزنید

## 🔧 تنظیمات پیشرفته

### کاهش تعداد سیمبل‌ها

در فایل `src/contexts/DataContext.tsx`:

```typescript
// فقط یک سیمبل
const priceSymbols = ['BTC'];

// یا چند سیمبل مهم
const priceSymbols = ['BTC', 'ETH'];
```

### افزایش زمان Cache

```env
# 10 دقیقه
VITE_CACHE_TTL=600000

# 30 دقیقه
VITE_CACHE_TTL=1800000
```

### محدود کردن درخواست‌ها

```env
# حداکثر 5 درخواست در دقیقه
VITE_MAX_REQUESTS_PER_MINUTE=5

# 5 ثانیه تاخیر بین درخواست‌ها
VITE_REQUEST_DELAY=5000
```

## 📈 مانیتورینگ استفاده از API

برای مشاهده تعداد درخواست‌ها:

1. باز کردن Developer Tools (F12)
2. رفتن به تب Network
3. فیلتر کردن با `api` یا `fetch`
4. مشاهده تعداد و نوع درخواست‌ها

## ⚠️ محدودیت‌های APIهای رایگان

| API | محدودیت رایگان |
|-----|----------------|
| CoinGecko | 10-50 درخواست/دقیقه |
| CryptoCompare | 100,000 درخواست/ماه |
| Binance | 1200 درخواست/دقیقه (وزن‌دار) |
| NewsAPI | 100 درخواست/روز |

## 💡 نکات مهم

1. **در حالت توسعه**: همیشه از حالت `demo` استفاده کنید
2. **برای تست API**: موقتاً `online` کنید و بعد برگردانید به `demo`
3. **Refresh دستی**: در حالت online، از دکمه refresh استفاده کنید نه auto-refresh
4. **Cache**: همیشه cache را فعال نگه دارید
5. **Log Level**: در production از `warn` یا `error` استفاده کنید

## 🚀 استفاده بهینه

```env
# برای توسعه روزانه
VITE_APP_MODE=demo
VITE_AUTO_LOAD_DATA=false
VITE_AUTO_REFRESH=false

# برای تست با API واقعی (محدود)
VITE_APP_MODE=online
VITE_AUTO_LOAD_DATA=true
VITE_AUTO_REFRESH=false
VITE_CACHE_TTL=600000

# برای production (با API key)
VITE_APP_MODE=online
VITE_AUTO_LOAD_DATA=true
VITE_AUTO_REFRESH=true
VITE_REFRESH_INTERVAL=300000
CMC_API_KEY=your_key_here
CRYPTOCOMPARE_KEY=your_key_here
```

## 🔍 عیب‌یابی

### خطای "Rate limit exceeded"
- حالت را به `demo` تغییر دهید
- `VITE_REQUEST_DELAY` را افزایش دهید
- تعداد سیمبل‌ها را کاهش دهید

### داده‌ها بارگذاری نمی‌شوند
- `VITE_AUTO_LOAD_DATA=true` کنید
- یا دکمه refresh را بزنید
- Developer Console را چک کنید

### برنامه کند است
- Cache را فعال کنید
- تعداد سیمبل‌ها را کاهش دهید
- `VITE_LAZY_LOAD=true` کنید

## 📞 پشتیبانی

در صورت مشکل:
1. Developer Console را چک کنید
2. Network tab را بررسی کنید
3. فایل `.env` را با تنظیمات پیشنهادی مقایسه کنید

