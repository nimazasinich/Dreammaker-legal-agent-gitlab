"""ML core modules for training and backtesting."""
