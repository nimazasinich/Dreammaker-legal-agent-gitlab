# v1.0.0 Release Deployment Checklist

## ✅ Pre-flight (one-time setup)

### 1. GitHub Permissions
- [ ] **Settings → Actions → General → Workflow permissions** → **Read and write permissions**
- [ ] No tag protection rules blocking `v*` tags
- [ ] Branch protection on `main` is fine (we tag commits, not push to branch)

### 2. Required Secrets (Settings → Secrets → Actions)
- [ ] `SSH_HOST` - Production server IP/hostname
- [ ] `SSH_USER` - SSH username for deployment
- [ ] `SSH_KEY` - Private SSH key for authentication
- [ ] `SSH_PORT` - (Optional, defaults to 22)
- [ ] `HUGGINGFACE_API_KEY` - Free HF token for models
- [ ] `TELEGRAM_BOT_TOKEN` - (Optional) For notifications
- [ ] `TELEGRAM_CHAT_ID` - (Optional) For notifications
- [ ] `REDIS_URL` - (Optional) External Redis if not using Docker

### 3. Files Ready
- [x] `.release/version` = `v1.0.0`
- [x] `.release/notes.md` = Release notes
- [x] `.github/workflows/release_bootstrap.yml` = Tag creator
- [x] `.github/workflows/cd.yml` = Build + deploy
- [x] `.github/workflows/release.yml` = GitHub release

---

## ▶️ Trigger Release Chain

**Current state:** Branch `claude/release-deployment-checklist-011CUypb5SEPoJo2BB61jTmv` ready

**Next step:** Push this branch to trigger the chain:

```bash
git push -u origin claude/release-deployment-checklist-011CUypb5SEPoJo2BB61jTmv
```

**What happens:**

1. **Release Bootstrap** workflow detects `.release/version` change
2. Creates annotated tag `v1.0.0` on `origin/main@95abe85`
3. **CD** workflow triggers on tag push
4. Builds + pushes Docker images to GHCR
5. SSHs to production server and deploys
6. **Release** workflow creates GitHub Release

**Idempotent:** If `v1.0.0` already exists, bootstrap no-ops safely.

---

## 🔎 Post-Deploy Verification

Run these commands on production server or via tunneling:

```bash
# 1) Health check (expect 200 OK)
curl -sf http://localhost:8000/status/health && echo "✓ Health OK"

# 2) Version verification
curl -s http://localhost:8000/api/system/status | jq '.version'
# Expected: "1.0.0"

# 3) HuggingFace OHLCV (test data fetch)
curl -s "http://localhost:8000/api/hf/ohlcv?symbol=BTCUSDT&timeframe=1h&limit=120" | jq '.rows'
# Expected: 120

# 4) HuggingFace Sentiment (test model inference)
curl -s -X POST "http://localhost:8000/api/hf/sentiment" \
  -H "content-type: application/json" \
  -d '{"texts":["BTC to the moon"]}' | jq '{vote,models:(.models|keys)}'
# Expected: vote in [-1,1], models array

# Quick sentiment label
curl -s -X POST "http://localhost:8000/api/hf/sentiment" \
  -H "content-type: application/json" \
  -d '{"texts":["Crypto looks bullish today"]}' \
| jq -r 'if .vote>0.2 then "bullish" elif .vote<-0.2 then "bearish" else "neutral" end'

# 5) Prometheus metrics
curl -s http://localhost:8000/metrics | head -40

# 6) Container status
docker compose -f deploy/docker-compose.prod.yml ps

# 7) Live logs
docker compose -f deploy/docker-compose.prod.yml logs --tail=200 -f
```

---

## 🧯 Troubleshooting

### A. Bootstrap fails to create tag

**Symptoms:** Workflow completes but no tag appears

**Checks:**
```bash
# Verify version format
cat .release/version
# Must match: ^v\d+\.\d+\.\d+(-rc\.\d+)?$

# Check workflow permissions
# Settings → Actions → General → Workflow permissions = Read and write
```

**Fix:** Re-run via workflow_dispatch:
- Go to Actions → Release Bootstrap
- Click "Run workflow"
- Inputs: `version: v1.0.0`, `ref: origin/main`

### B. CD fails during build/push

**Symptoms:** Docker build fails or GHCR push denied

**Checks:**
```bash
# Verify GHCR permissions
# workflow has: permissions.packages: write ✓
# Organization policy may override - check org settings
```

**Fix:** Re-run workflow (build cache makes retry fast)

### C. Deploy step fails (SSH)

**Symptoms:** "Permission denied" or "Connection refused"

**Checks:**
```bash
# On production server
docker compose -f deploy/docker-compose.prod.yml pull
docker compose -f deploy/docker-compose.prod.yml up -d
docker compose -f deploy/docker-compose.prod.yml logs --tail=200
```

**Fix:** Verify secrets:
- `SSH_HOST` = correct IP/hostname
- `SSH_USER` = user with docker permissions
- `SSH_KEY` = private key matching authorized_keys
- `SSH_PORT` = 22 or custom (if using non-standard)

### D. HuggingFace endpoints rate-limit

**Symptoms:** 429 errors or slow responses

**Checks:**
```bash
# Verify env var passed to container
docker compose -f deploy/docker-compose.prod.yml exec server env | grep HUGGING
```

**Fix:** Ensure `HUGGINGFACE_API_KEY` in:
- GitHub Secrets (for CD workflow)
- Production `.env` or docker-compose environment

---

## 🧨 Rollback Strategies

### Option 1: New rollback tag (automated)

```bash
# From local machine with push access
git tag -a v1.0.0-rollback -m "Rollback to pre-v1.0.0" <previous-good-commit>
git push origin v1.0.0-rollback
# Triggers CD workflow with rollback images
```

### Option 2: Manual version pin

Edit `deploy/docker-compose.prod.yml` on production:

```yaml
services:
  server:
    image: ghcr.io/<owner>/dcs-server:v0.9.9  # Pin to previous tag
  client:
    image: ghcr.io/<owner>/dcs-client:v0.9.9
```

Then:
```bash
docker compose -f deploy/docker-compose.prod.yml pull
docker compose -f deploy/docker-compose.prod.yml up -d
```

---

## ✅ Success Criteria

- [ ] Tag `v1.0.0` visible under **Releases** tab
- [ ] GHCR images published:
  - `ghcr.io/<owner>/dcs-server:v1.0.0`
  - `ghcr.io/<owner>/dcs-client:v1.0.0`
- [ ] Health endpoint returns 200 OK
- [ ] Version endpoint returns `"version": "1.0.0"`
- [ ] HF OHLCV returns 120 rows
- [ ] HF Sentiment returns vote in [-1, 1]
- [ ] Metrics endpoint emits Prometheus format
- [ ] All containers running: `redis`, `nginx`, `server`, `client`

---

## 📊 Monitoring Commands

```bash
# Watch deployment progress
watch -n 2 'docker compose -f deploy/docker-compose.prod.yml ps'

# Stream logs
docker compose -f deploy/docker-compose.prod.yml logs -f server

# Check resource usage
docker stats

# Network connectivity
docker compose -f deploy/docker-compose.prod.yml exec server curl -s http://localhost:8000/status/health

# Redis connectivity
docker compose -f deploy/docker-compose.prod.yml exec redis redis-cli ping
```

---

## 🔗 Quick Links

- **Workflows:** https://github.com/<owner>/<repo>/actions
- **Releases:** https://github.com/<owner>/<repo>/releases
- **GHCR Packages:** https://github.com/<owner>/<repo>/pkgs/container/dcs-server
- **HuggingFace:** https://huggingface.co/settings/tokens

---

## 📝 Notes

- **Bootstrap is idempotent:** Safe to re-trigger if tag already exists
- **CD retries:** Build cache makes re-runs fast (~2min vs 8min cold)
- **Tag protection:** Don't enable for `v*` or CI can't push tags
- **Main branch:** Can stay protected; we tag commits, not push to branch
- **Commit SHA:** Tag created on `95abe85` (latest main) unless specified

---

**Created:** 2025-11-10
**Version:** v1.0.0
**Status:** Ready to trigger
